// ===============================
// Fabricio Solano Rojas B77447
// ===============================

#include <cmath>
#include <iostream>
#include "metodoh.h"

using namespace std;

// Se define el constructor de la clase padre
_base::_base(float valxi,float valxi_xi)
{
  xi = valxi;
  error_aceptado = valxi_xi;
  xi_xi = 0;
  iterador = 0;
  ultimo_xi = 0;
}//______________________________________________

//------------------------------------------------------------------------------------
// Se define el constructor y funciones de la clase hija _polinomio
// Se define el constructor
_polinomio::_polinomio(float valxi,float valxi_xi) :_base(valxi, valxi_xi)
{
};//______________________________________________
// Se define la funci�n con la ecuaci�n
float _polinomio::resolverEcuacionP(float valor)
{
    // Con la ecuaci�n: x^3 + 4x^2 -10
    return pow(valor, 3) + 4 * pow(valor, 2) - 10;
}//______________________________________________
// Se define la funci�n con la derivada de la ecuaci�n
float _polinomio::resolverDerivadaP(float valor)
{
    // Con la ecuaci�n: 3x^2 + 8x
    return pow((3 * valor), 2) + 8 * valor;
}//______________________________________________
// Se define la funci�n que resuelve el m�todo de Newton
void _polinomio::metodoNewton(void)
{
    printf("Ecuacion: x^3 + 4x^2 -10\n");
    printf("Derivada: 3x^2 + 8x\n");
    printf("+----+-------------+-------------+-------------+-------------+-------"
            "-----+\n");
    printf("+ i  |      xi     |    f(xi)    |    f'(xi)   |    xi + 1   |    "
            "xi_xi   |\n");
    printf("+----+-------------+-------------+-------------+-------------+-------"
            "-----+\n");
    while (1) {
        fxi = resolverEcuacionP(xi);
        _fxi = resolverDerivadaP(xi);
        xi_1 = xi - (fxi / _fxi);
        printf("|%3d |%12.8f |%12.8f |%12.8f |%12.8f |%12.8f|\n", iterador, xi, fxi,
                _fxi, xi_1, xi_xi);
        iterador++;
        ultimo_xi = xi;
        xi = xi_1;
        xi_xi = abs(xi - ultimo_xi);
        if (xi_xi <= error_aceptado || iterador > 400) {
        printf("+----+-------------+-------------+-------------+-------------+---"
                "---------+\n\n");
        break;
        }
    }
}//______________________________________________
//------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------
// Se define el constructor y funciones de la clase hija _exponencial
// Se define el constructor
_exponencial::_exponencial(float valxi,float valxi_xi) :_base(valxi, valxi_xi)
{
};//______________________________________________
// Se define la funci�n con la ecuaci�n
float _exponencial::resolverEcuacionE(float valor)
{
    // Con la ecuaci�n: x*e^(cos(x)/1.5 - 1
    return valor * exp(cos(valor)) / 1.5 - 1;
}//______________________________________________
// Se define la funci�n con la derivada de la ecuaci�n
float _exponencial::resolverDerivadaE(float valor)
{
    // Con la ecuaci�n: e^(cos(x))*(1 - x*sin(x))/1.5
    return exp(cos(valor)) * (1 - valor * sin(valor)) / 1.5;
}//______________________________________________
// Se define la funci�n que resuelve el m�todo de Newton
void _exponencial::metodoNewton(void)
{
    printf("Ecuacion: x*e^(cos(x)/1.5 - 1\n");
    printf("Derivada: e^(cos(x))*(1 - x*sin(x))/1.5\n");
    printf("+----+-------------+-------------+-------------+-------------+-------"
            "-----+\n");
    printf("+ i  |      xi     |    f(xi)    |    f'(xi)   |    xi + 1   |    "
            "xi_xi   |\n");
    printf("+----+-------------+-------------+-------------+-------------+-------"
            "-----+\n");
    while (1) {
        fxi = resolverEcuacionE(xi);
        _fxi = resolverDerivadaE(xi);
        xi_1 = xi - (fxi / _fxi);
        printf("|%3d |%12.8f |%12.8f |%12.8f |%12.8f |%12.8f|\n", iterador, xi, fxi,
                _fxi, xi_1, xi_xi);
        iterador++;
        ultimo_xi = xi;
        xi = xi_1;
        xi_xi = abs(xi - ultimo_xi);
        if (xi_xi <= error_aceptado || iterador > 400) {
        printf("+----+-------------+-------------+-------------+-------------+---"
                "---------+\n\n");
        break;
        }
    }
}//______________________________________________
//------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------
// Se define el constructor y funciones de la clase hija _exponencial
// Se define el constructor
_seno::_seno(float valxi,float valxi_xi) :_base(valxi, valxi_xi)
{
};//______________________________________________
// Se define la funci�n con la ecuaci�n
float _seno::resolverEcuacionS(float valor)
{
    // Con la ecuaci�n: sin(x)
    return sin(valor); //- log(valor);
}//______________________________________________
// Se define la funci�n con la derivada de la ecuaci�n
float _seno::resolverDerivadaS(float valor)
{
    // Con la ecuaci�n: cos(x)
    return cos(valor);
}//______________________________________________
// Se define la funci�n que resuelve el m�todo de Newton
void _seno::metodoNewton(void)
{
    printf("Ecuacion: sin(x)\n");
    printf("Derivada: cos(x)\n");
    printf("+----+-------------+-------------+-------------+-------------+-------"
            "-----+\n");
    printf("+ i  |      xi     |    f(xi)    |    f'(xi)   |    xi + 1   |    "
            "xi_xi   |\n");
    printf("+----+-------------+-------------+-------------+-------------+-------"
            "-----+\n");
    while (1) {
        fxi = resolverEcuacionS(xi);
        _fxi = resolverDerivadaS(xi);
        xi_1 = xi - (fxi / _fxi);
        printf("|%3d |%12.8f |%12.8f |%12.8f |%12.8f |%12.8f|\n", iterador, xi, fxi,
                _fxi, xi_1, xi_xi);
        iterador++;
        ultimo_xi = xi;
        xi = xi_1;
        xi_xi = abs(xi - ultimo_xi);
        if (xi_xi <= error_aceptado || iterador > 400) {
        printf("+----+-------------+-------------+-------------+-------------+---"
                "---------+\n\n");
        break;
        }
    }
}//______________________________________________
//------------------------------------------------------------------------------------
