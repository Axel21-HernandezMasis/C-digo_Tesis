# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import pandas as pd
import glob
import numpy as np
import random
import matplotlib.pyplot as plt
pd.options.display.max_rows = 9999

#******************************************************************************************

#Edificio A
#ICE

column_names = pd.Series(['Time', 'Longitude', 'Latitude', 'Operador',"Network" , 'NetworkTech', 'Level', "Speed"])

Piso_Cuatro_ICE = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_ICE\Edificio_A4\ICE_2023.11.04_13.40.07\ICE_2023.11.04_13.40.07.txt", sep=';', decimal=',') 
Piso_Cuatro_ICE.fillna(0, inplace = True)

Piso_Tres_ICE = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_ICE\Edificio_A3\ICE_2023.11.04_13.43.10\ICE_2023.11.04_13.43.10.txt", sep=';', decimal=',')
Piso_Tres_ICE.fillna(0, inplace = True)

Piso_Dos_ICE = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_ICE\Edificio_A2\ICE_2023.11.04_13.46.26\ICE_2023.11.04_13.46.26.txt", sep=';', decimal=',') 
Piso_Dos_ICE.fillna(0, inplace = True)

Piso_Uno_ICE = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_ICE\Edificio_A1\ICE_2023.11.04_13.37.40\ICE_2023.11.04_13.37.40.txt", sep=';', decimal=',')  
Piso_Uno_ICE.fillna(0, inplace = True)

#Claro

Piso_Cuatro_CLARO = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_A4\Claro_2023.11.04_15.40.59\Claro_2023.11.04_15.40.59.txt", sep=';', decimal=',') 
Piso_Cuatro_CLARO.fillna(0, inplace = True)

Piso_Tres_CLARO = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_A3\Claro_2023.11.04_15.43.18\Claro_2023.11.04_15.43.18.txt", sep=';', decimal=',') 
Piso_Tres_CLARO.fillna(0, inplace = True)

Piso_Dos_CLARO = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_A2\Claro_2023.11.04_15.45.25\Claro_2023.11.04_15.45.25.txt", sep=';', decimal=',') 
Piso_Dos_CLARO.fillna(0, inplace = True)

Piso_Uno_CLARO = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_A1\Claro_2023.11.04_15.47.30\Claro_2023.11.04_15.47.30.txt", sep=';', decimal=',') 
Piso_Uno_CLARO.fillna(0, inplace = True)

#Liberty

Piso_Cuatro_Liberty = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Liberty\Edificio_A4\LIBERTY_2023.11.04_13.39.58\LIBERTY_2023.11.04_13.39.58.txt", sep=';', decimal=',') 
Piso_Cuatro_Liberty.fillna(0, inplace = True)

Piso_Tres_Liberty = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Liberty\Edificio_A3\LIBERTY_2023.11.04_13.43.12\LIBERTY_2023.11.04_13.43.12.txt", sep=';', decimal=',') 
Piso_Tres_Liberty.fillna(0, inplace = True)

Piso_Dos_Liberty = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Liberty\Edificio_A2\LIBERTY_2023.11.04_13.46.23\LIBERTY_2023.11.04_13.46.23.txt", sep=';', decimal=',') 
Piso_Dos_Liberty.fillna(0, inplace = True)

Piso_Uno_Liberty = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Liberty\Edificio_A1\LIBERTY_2023.11.04_13.37.33\LIBERTY_2023.11.04_13.37.33.txt", sep=';', decimal=',') 
Piso_Uno_Liberty.fillna(0, inplace = True)
#******************************************************************************************

#Edificio B/C

Piso_Claro_B = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_B\Claro_2023.11.04_15.56.11\Claro_2023.11.04_15.56.11.txt", sep=';', decimal=',')
Piso_Claro_B.fillna(0, inplace = True)

Piso_Kolbi_B_C = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_ICE\Edificio_B_C\ICE_2023.11.04_13.21.18\ICE_2023.11.04_13.21.18.txt", sep=';', decimal=',')
Piso_Kolbi_B_C.fillna(0, inplace = True)

Piso_Liberty_B_C = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Liberty\Edificio_B_C\LIBERTY_2023.11.04_13.21.14\LIBERTY_2023.11.04_13.21.14.txt", sep=';', decimal=',')
Piso_Liberty_B_C.fillna(0, inplace = True)

#******************************************************************************************
#Edificio C
Piso_Claro_C = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_C\Claro_2023.11.04_15.53.27\Claro_2023.11.04_15.53.27.txt", sep=';', decimal=',')
Piso_Claro_C.fillna(0, inplace = True)

#******************************************************************************************
#Edificio D


#Piso D0 E0
Piso_Claro_D_0_E_0 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_D0_E0\Claro_2023.11.04_15.09.24\Claro_2023.11.04_15.09.24.txt", sep=';', decimal=',')
Piso_Claro_D_0_E_0.fillna(0, inplace = True)

#Piso 1
Piso_Claro_D_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_D1\Claro_2023.11.04_15.49.54\Claro_2023.11.04_15.49.54.txt", sep=';', decimal=',')
Piso_Claro_D_1.fillna(0, inplace = True)

#Piso 2
Piso_Claro_D_2 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_D2\Claro_2023.11.04_15.22.44\Claro_2023.11.04_15.22.44.txt", sep=';', decimal=',')
Piso_Claro_D_2.fillna(0, inplace = True)

#Piso 3
Piso_Claro_D_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_D3\Claro_2023.11.04_15.28.50\Claro_2023.11.04_15.28.50.txt", sep=';', decimal=',')
Piso_Claro_D_3.fillna(0, inplace = True)

#Piso 4
Piso_Claro_D_4 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_D4\Claro_2023.11.04_15.37.59\Claro_2023.11.04_15.37.59.txt", sep=';', decimal=',')
Piso_Claro_D_4.fillna(0, inplace = True)


#Piso D0 E0
Piso_Kolbi_D_0_E_0 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_ICE\Edificio_EO_D0\ICE_2023.11.04_13.00.29\ICE_2023.11.04_13.00.29.txt", sep=';', decimal=',')
Piso_Kolbi_D_0_E_0.fillna(0, inplace = True)

#Piso 1
Piso_Kolbi_D_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_ICE\Edificio_D1\ICE_2023.11.04_13.13.35\ICE_2023.11.04_13.13.35.txt", sep=';', decimal=',')
Piso_Kolbi_D_1.fillna(0, inplace = True)

#Piso 2
Piso_Kolbi_D_2 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_ICE\Edificio_D2\ICE_2023.11.04_14.54.36\ICE_2023.11.04_14.54.36.txt", sep=';', decimal=',')
Piso_Kolbi_D_2.fillna(0, inplace = True)

#Piso 3
Piso_Kolbi_D_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_ICE\Edificio_D3\ICE_2023.11.04_14.47.39\ICE_2023.11.04_14.47.39.txt", sep=';', decimal=',')
Piso_Kolbi_D_3.fillna(0, inplace = True)

#Piso 4
Piso_Kolbi_D_4 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_ICE\Edificio_D4\ICE_2023.11.04_14.39.07\ICE_2023.11.04_14.39.07.txt", sep=';', decimal=',')
Piso_Kolbi_D_4.fillna(0, inplace = True)



Piso_Liberty_D_0_E_0 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Liberty\Edificio_D0_E0\LIBERTY_2023.11.04_13.00.26\LIBERTY_2023.11.04_13.00.26.txt", sep=';', decimal=',')
Piso_Liberty_D_0_E_0.fillna(0, inplace = True)

#Piso 1
Piso_Liberty_D_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Liberty\Edificio_D1\LIBERTY_2023.11.04_13.13.26\LIBERTY_2023.11.04_13.13.26.txt", sep=';', decimal=',')
Piso_Liberty_D_1.fillna(0, inplace = True)

#Piso 2
Piso_Liberty_D_2 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Liberty\Edificio_D2\LIBERTY_2023.11.04_14.54.42\LIBERTY_2023.11.04_14.54.42.txt", sep=';', decimal=',')
Piso_Liberty_D_2.fillna(0, inplace = True)

#Piso 3
Piso_Liberty_D_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Liberty\Edificio_D3\LIBERTY_2023.11.04_14.47.32\LIBERTY_2023.11.04_14.47.32.txt", sep=';', decimal=',')
Piso_Liberty_D_3.fillna(0, inplace = True)

#Piso 4
Piso_Liberty_D_4 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Liberty\Edificio_D4\LIBERTY_2023.11.04_14.39.01\LIBERTY_2023.11.04_14.39.01.txt", sep=';', decimal=',')
Piso_Liberty_D_4.fillna(0, inplace = True)
#Edificio E

#Piso 1
Piso_Claro_E_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_E1\Claro_2023.11.04_15.15.14\Claro_2023.11.04_15.15.14.txt", sep=';', decimal=',')
Piso_Claro_E_1.fillna(0, inplace = True)

#Piso 2
Piso_Claro_E_2 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_E2\Claro_2023.11.04_15.19.24\Claro_2023.11.04_15.19.24.txt", sep=';', decimal=',')
Piso_Claro_E_2.fillna(0, inplace = True)

#Piso 3
Piso_Claro_E_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_E3\Claro_2023.11.04_15.25.34\Claro_2023.11.04_15.25.34.txt", sep=';', decimal=',')
Piso_Claro_E_3.fillna(0, inplace = True)

#Piso 4
Piso_Claro_E_4 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_E4\Claro_2023.11.04_15.31.52\Claro_2023.11.04_15.31.52.txt", sep=';', decimal=',')
Piso_Claro_E_4.fillna(0, inplace = True)

#Piso 5
Piso_Claro_E_5 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_E5\Claro_2023.11.04_15.34.27\Claro_2023.11.04_15.34.27.txt", sep=';', decimal=',')
Piso_Claro_E_5.fillna(0, inplace = True)

#Piso 1
Piso_Kolbi_E_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_ICE\Edificio_E1\ICE_2023.11.04_13.07.13\ICE_2023.11.04_13.07.13.txt", sep=';', decimal=',')
Piso_Kolbi_E_1.fillna(0, inplace = True)

#Piso 2
Piso_Kolbi_E_2 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_ICE\Edificio_E2\ICE_2023.11.04_14.50.43\ICE_2023.11.04_14.50.43.txt", sep=';', decimal=',')
Piso_Kolbi_E_2.fillna(0, inplace = True)

#Piso 3
Piso_Kolbi_E_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_ICE\Edificio_E3\ICE_2023.11.04_14.43.21\ICE_2023.11.04_14.43.21.txt", sep=';', decimal=',')
Piso_Kolbi_E_3.fillna(0, inplace = True)

#Piso 4
Piso_Kolbi_E_4 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_ICE\Edificio_E4\ICE_2023.11.04_14.35.26\ICE_2023.11.04_14.35.26.txt", sep=';', decimal=',')
Piso_Kolbi_E_4.fillna(0, inplace = True)

#Piso 5
Piso_Kolbi_E_5 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_ICE\Edificio_E5\ICE_2023.11.04_14.31.44\ICE_2023.11.04_14.31.44.txt", sep=';', decimal=',')
Piso_Kolbi_E_5.fillna(0, inplace = True)

#Piso 1
Piso_Liberty_E_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Liberty\Edificio_E1\LIBERTY_2023.11.04_13.06.59\LIBERTY_2023.11.04_13.06.59.txt", sep=';', decimal=',')
Piso_Liberty_E_1.fillna(0, inplace = True)

#Piso 2
Piso_Liberty_E_2 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Liberty\Edificio_E2\LIBERTY_2023.11.04_14.50.34\LIBERTY_2023.11.04_14.50.34.txt", sep=';', decimal=',')
Piso_Liberty_E_2.fillna(0, inplace = True)

#Piso 3
Piso_Liberty_E_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Liberty\Edificio_E3\LIBERTY_2023.11.04_14.43.14\LIBERTY_2023.11.04_14.43.14.txt", sep=';', decimal=',')
Piso_Liberty_E_3.fillna(0, inplace = True)

#Piso 4
Piso_Liberty_E_4 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Liberty\Edificio_E4\LIBERTY_2023.11.04_14.35.19\LIBERTY_2023.11.04_14.35.19.txt", sep=';', decimal=',')
Piso_Liberty_E_4.fillna(0, inplace = True)

#Piso 5
Piso_Liberty_E_5 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Liberty\Edificio_E5\LIBERTY_2023.11.04_14.31.37\LIBERTY_2023.11.04_14.31.37.txt", sep=';', decimal=',')
Piso_Liberty_E_5.fillna(0, inplace = True)

#Piso F

Piso_Liberty_F = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Liberty\Edificio_F\LIBERTY_2023.11.04_12.50.36\LIBERTY_2023.11.04_12.50.36.txt", sep=';', decimal=',')
Piso_Liberty_F.fillna(0, inplace = True)

Piso_Kolbi_F = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_ICE\Edificio_F\ICE_2023.11.04_12.51.03\ICE_2023.11.04_12.51.03.txt", sep=';', decimal=',')
Piso_Kolbi_F.fillna(0, inplace = True)

Piso_Claro_F = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_de_Claro\Edificio_F\Claro_2023.10.14_11.34.08\Claro_2023.10.14_11.34.08.txt", sep=';', decimal=',')
Piso_Claro_F.fillna(0, inplace = True)





#Funciones
def Limpiar(marks):
    b=[]
    m=len(marks.index)
    for j in range(m):
        Filaaux=marks.iloc[j,0]
        Filaaux=Filaaux.split()
        b.append(Filaaux)
    Datos=pd.DataFrame(b,columns=column_names)
    Datos.loc[Datos["Network"] == "4G", "Red_G"] = 4

    Datos.loc[Datos["Network"] == "3G", "Red_G"] = 3

    Datos.drop(Datos[(Datos['Red_G']==3)].index, inplace =True) #Elimina el 3G
    Datos.drop(['Time', 'Longitude', 'Latitude','Network','Level' ], axis=1, inplace=True)
    Datos["NetworkTech"]=Datos["NetworkTech"].astype(float)
    Datos["Speed"]=Datos["Speed"].astype(float)
    
   
    
    return Datos

def assign_Result_4G(marks):
    
    if marks <= -44 and marks >= -80 :
        result = "1-Excelente"
    elif marks <= -80 and marks >= -90 :
        result = "2-Buena" 
    elif marks <= -90 and marks >= -100 :
        result = "3-Justa"  
    elif  marks <= -100 and marks >= -110 :
        result = "4-Mala"
    elif marks <= -111 :
        result = "5-Muerta"  
    else:
        result = "6-Error"
    return result



def assign_Result_3G(marks):
    
    if marks <= -60.0 and marks >= -85.0 :
        result = "1-Excelente" 
    elif marks <= -86.0 and marks >= -100.0 :
        result = "2-Buena"  
    elif  marks <= -101.0 and marks >= -109.0 :
        result = "3-Justa" 
    elif marks <= -110.0 :
        result = "4-Mala" 
    
    else:
        result = "5-Muerta"
    return result

def assign_Umbral_4G(marks):
    
    if marks <= -44 and marks >= -95 :
        result = "1-Dentro_Umbral"
    elif marks <= -96:
        result = "2-Fuera_Umbral" 
     
    else:
        result = "6-Error"
    return result

def assign_3G_or_4G(marks):
    for i in range(len(marks)):
        if marks.iloc[i]['Red_G']==4.0:
            marks["Calidad_4G"] = marks["NetworkTech"].apply(assign_Result_4G)
            marks["Umbral"] = marks["NetworkTech"].apply(assign_Umbral_4G)
 
           
            
        elif marks.iloc[i]['Red_G']==3.0:
            marks["Calidad_3G"] = marks["NetworkTech"].apply(assign_Result_3G)
            
    marks=marks.sort_values("Calidad_4G")
    marks.head()        
    return marks

def Mala_cobertura(marks):

    x=0 
    y=0
    z=0 
    a=0 
    b=0 
    
    for i in range(len(marks["Calidad_4G"])):
        if marks.iloc[i]["Calidad_4G"]=="1-Excelente":
            a=a+1
        if marks.iloc[i]["Calidad_4G"]=="2-Buena":
            b=b+1
        if marks.iloc[i]["Calidad_4G"]=="3-Justa":
            x=x+1
        if marks.iloc[i]["Calidad_4G"]=="4-Mala":
            y=y+1
        if marks.iloc[i]["Calidad_4G"]=="5-Muerta":
            z=z+1
        
        

   # print("Se encontraron :""",a,"""datos de calidad
     #         Excelente respecto a la muestra de datos 
    #          de:""",len(marks["Calidad_4G"]))
 #   print("Se encontraron :""",b,""" datos de calidad 
    #          Buena respecto a la muestra de datos 
     #         de:""",len(marks["Calidad_4G"]))
  #  print("Se encontraron :""",x,""" datos de calidad 
    #          Justa respecto a la muestra de datos 
     #         de:""",len(marks["Calidad_4G"]))
  #  print("Se encontraron :""",y,""" datos de calidad 
     #         Mala respecto a la muestra de datos 
      #        de:""",len(marks["Calidad_4G"]))
  #  print("Se encontraron :""",z,"""datos de calidad 
     #         Muerta respecto a la muestra de datos 
      #        de:""",len(marks["Calidad_4G"]))
             
    return a,b,x,y,z

        
def Datos_Finales(marks):
 #   display(marks)
    Varianza=marks["NetworkTech"].var(ddof=0)
    Desviacion_Estandar=marks["NetworkTech"].std()
    Promedio_Cobertura=marks["NetworkTech"].mean()
#    Promedio_Velocidad=marks["Speed"].mean()
    print("La varianza de la cobertura es:",Varianza)#La variación de parametro
    print("La Desviacion estandar es:",Desviacion_Estandar)#Cuanto se desvian los parametros entre sí
    print("El promedio de cobertura es",Promedio_Cobertura)#Promedio de la señal
#    print("El promedio de ancho de banda",Promedio_Velocidad,"kbps")#Promedio de la señal
    
    
    # marks["NetworkTech"].plot()
    
#********************************************************************************
def plt_auxiliar(): 
    plt.plot(["1-Excelente", "1-Excelente"],
         [-70, -125],
         color='black', linestyle='')
    plt.plot(["2-Buena", "2-Buena"],
         [-70, -125],
         color='black', linestyle='')
    plt.plot(["3-Justa", "3-Justa"],
         [-70, -125],
         color='black', linestyle='')
    plt.plot(["4-Mala", "4-Mala"],
         [-70, -125],
         color='black', linestyle='')
    plt.plot(["5-Muerta", "5-Muerta"],
         [-70, -125],
         color='black', linestyle='')

def plt_auxiliar_2():     
    plt.plot(["1-Excelente", "5-Muerta"],
         [-80, -80],
         color='black', linestyle='--')
    plt.plot(["1-Excelente", "5-Muerta"],
         [-90, -90],
         color='black', linestyle='--')
    plt.plot(["1-Excelente", "5-Muerta"],
         [-100, -100],
         color='black', linestyle='--')    
    plt.plot(["1-Excelente", "5-Muerta"],
         [-110, -110],
         color='black', linestyle='--')
    

def plt_auxiliar_3():
    plt.plot(["1-Excelente", "1-Excelente"],
         [0, 100],color='black', linestyle='')
    
def plt_auxiliar_4():
    plt.plot(["1-Excelente", "1-Excelente"],
         [0, 120],color='black', linestyle='')
    

    
    
#********************************************************************************#
def Mala_cobertura_Sutel(marks):

    p=0 
    h=0

    
    for i in range(len(marks["Calidad_4G"])):
        if marks.iloc[i]["Umbral"]=="1-Dentro_Umbral":
            p=p+1
        if marks.iloc[i]["Umbral"]=="2-Fuera_Umbral":
            h=h+1

    return p,h
        
        
    


#Pisol
Piso_Uno_CLARO=Limpiar(Piso_Uno_CLARO)
Piso_Uno_CLARO=assign_3G_or_4G(Piso_Uno_CLARO)



#Piso2
Piso_Dos_CLARO=Limpiar(Piso_Dos_CLARO)
Piso_Dos_CLARO=assign_3G_or_4G(Piso_Dos_CLARO)

#Piso3
Piso_Tres_CLARO=Limpiar(Piso_Tres_CLARO)
Piso_Tres_CLARO=assign_3G_or_4G(Piso_Tres_CLARO)

#Piso4
Piso_Cuatro_CLARO=Limpiar(Piso_Cuatro_CLARO)
Piso_Cuatro_CLARO=assign_3G_or_4G(Piso_Cuatro_CLARO)

#Piso1
Piso_Uno_ICE=Limpiar(Piso_Uno_ICE)
Piso_Uno_ICE=assign_3G_or_4G(Piso_Uno_ICE)

#Piso2
Piso_Dos_ICE=Limpiar(Piso_Dos_ICE)
Piso_Dos_ICE=assign_3G_or_4G(Piso_Dos_ICE)


#Piso3
Piso_Tres_ICE=Limpiar(Piso_Tres_ICE)
Piso_Tres_ICE=assign_3G_or_4G(Piso_Tres_ICE)


#Piso4
Piso_Cuatro_ICE=Limpiar(Piso_Cuatro_ICE)
Piso_Cuatro_ICE=assign_3G_or_4G(Piso_Cuatro_ICE)


Piso_Uno_Liberty=Limpiar(Piso_Uno_Liberty)
Piso_Uno_LibertyE=assign_3G_or_4G(Piso_Uno_Liberty)

#Piso2
Piso_Dos_Liberty=Limpiar(Piso_Dos_Liberty)
Piso_Dos_Liberty=assign_3G_or_4G(Piso_Dos_Liberty)

#Piso3
Piso_Tres_Liberty=Limpiar(Piso_Tres_Liberty)
Piso_Tres_Liberty=assign_3G_or_4G(Piso_Tres_Liberty)

#Piso4
Piso_Cuatro_Liberty=Limpiar(Piso_Cuatro_Liberty)
Piso_Cuatro_Liberty=assign_3G_or_4G(Piso_Cuatro_Liberty)

Piso_Claro_B=Limpiar(Piso_Claro_B)
Piso_Claro_B=assign_3G_or_4G(Piso_Claro_B)



Piso_Kolbi_B_C=Limpiar(Piso_Kolbi_B_C)
Piso_Kolbi_B_C=assign_3G_or_4G(Piso_Kolbi_B_C)

Piso_Liberty_B_C=Limpiar(Piso_Liberty_B_C)
Piso_Liberty_B_C=assign_3G_or_4G(Piso_Liberty_B_C)


Piso_Claro_C=Limpiar(Piso_Claro_C)
Piso_Claro_C=assign_3G_or_4G(Piso_Claro_C)


Piso_Claro_D_0_E_0=Limpiar(Piso_Claro_D_0_E_0)
Piso_Claro_D_0_E_0=assign_3G_or_4G(Piso_Claro_D_0_E_0)

Piso_Claro_D_1=Limpiar(Piso_Claro_D_1)
Piso_Claro_D_1=assign_3G_or_4G(Piso_Claro_D_1)


Piso_Claro_D_2=Limpiar(Piso_Claro_D_2)
Piso_Claro_D_2=assign_3G_or_4G(Piso_Claro_D_2)


Piso_Claro_D_3=Limpiar(Piso_Claro_D_3)
Piso_Claro_D_3=assign_3G_or_4G(Piso_Claro_D_3)

Piso_Claro_D_4=Limpiar(Piso_Claro_D_4)
Piso_Claro_D_4=assign_3G_or_4G(Piso_Claro_D_4)

Piso_Kolbi_D_0_E_0=Limpiar(Piso_Kolbi_D_0_E_0)
Piso_Kolbi_D_0_E_0=assign_3G_or_4G(Piso_Kolbi_D_0_E_0)

Piso_Kolbi_D_1=Limpiar(Piso_Kolbi_D_1)
Piso_Kolbi_D_1=assign_3G_or_4G(Piso_Kolbi_D_1)

Piso_Kolbi_D_2=Limpiar(Piso_Kolbi_D_2)
Piso_Kolbi_D_2=assign_3G_or_4G(Piso_Kolbi_D_2)



Piso_Kolbi_D_3=Limpiar(Piso_Kolbi_D_3)
Piso_Kolbi_D_3=assign_3G_or_4G(Piso_Kolbi_D_3)

Piso_Kolbi_D_4=Limpiar(Piso_Kolbi_D_4)
Piso_Kolbi_D_4=assign_3G_or_4G(Piso_Kolbi_D_4)

Piso_Liberty_D_0_E_0=Limpiar(Piso_Liberty_D_0_E_0)
Piso_Liberty_D_0_E_0=assign_3G_or_4G(Piso_Liberty_D_0_E_0)

Piso_Liberty_D_1=Limpiar(Piso_Liberty_D_1)
Piso_Liberty_D_1=assign_3G_or_4G(Piso_Liberty_D_1)

Piso_Liberty_D_2=Limpiar(Piso_Liberty_D_2)
Piso_Liberty_D_2=assign_3G_or_4G(Piso_Liberty_D_2)

Piso_Liberty_D_3=Limpiar(Piso_Liberty_D_3)
Piso_Liberty_D_3=assign_3G_or_4G(Piso_Liberty_D_3)


Piso_Liberty_D_4=Limpiar(Piso_Liberty_D_4)
Piso_Liberty_D_4=assign_3G_or_4G(Piso_Liberty_D_4)

Piso_Claro_E_1=Limpiar(Piso_Claro_E_1)
Piso_Claro_E_1=assign_3G_or_4G(Piso_Claro_E_1)

Piso_Claro_E_2=Limpiar(Piso_Claro_E_2)
Piso_Claro_E_2=assign_3G_or_4G(Piso_Claro_E_2)

Piso_Claro_E_3=Limpiar(Piso_Claro_E_3)
Piso_Claro_E_3=assign_3G_or_4G(Piso_Claro_E_3)

Piso_Claro_E_4=Limpiar(Piso_Claro_E_4)
Piso_Claro_E_4=assign_3G_or_4G(Piso_Claro_E_4)

Piso_Claro_E_5=Limpiar(Piso_Claro_E_5)
Piso_Claro_E_5=assign_3G_or_4G(Piso_Claro_E_5)


Piso_Kolbi_E_1=Limpiar(Piso_Kolbi_E_1)
Piso_Kolbi_E_1=assign_3G_or_4G(Piso_Kolbi_E_1)

Piso_Kolbi_E_2=Limpiar(Piso_Kolbi_E_2)
Piso_Kolbi_E_2=assign_3G_or_4G(Piso_Kolbi_E_2)

Piso_Kolbi_E_3=Limpiar(Piso_Kolbi_E_3)
Piso_Kolbi_E_3=assign_3G_or_4G(Piso_Kolbi_E_3)

Piso_Kolbi_E_4=Limpiar(Piso_Kolbi_E_4)
Piso_Kolbi_E_4=assign_3G_or_4G(Piso_Kolbi_E_4)

Piso_Kolbi_E_5=Limpiar(Piso_Kolbi_E_5)
Piso_Kolbi_E_5=assign_3G_or_4G(Piso_Kolbi_E_5)


Piso_Liberty_E_1=Limpiar(Piso_Liberty_E_1)
Piso_Liberty_E_1=assign_3G_or_4G(Piso_Liberty_E_1)

Piso_Liberty_E_2=Limpiar(Piso_Liberty_E_2)
Piso_Liberty_E_2=assign_3G_or_4G(Piso_Liberty_E_2)

Piso_Liberty_E_3=Limpiar(Piso_Liberty_E_3)
Piso_Liberty_E_3=assign_3G_or_4G(Piso_Liberty_E_3)



Piso_Liberty_E_4=Limpiar(Piso_Liberty_E_4)
Piso_Liberty_E_4=assign_3G_or_4G(Piso_Liberty_E_4)


Piso_Liberty_E_5=Limpiar(Piso_Liberty_E_5)
Piso_Liberty_E_5=assign_3G_or_4G(Piso_Liberty_E_5)


Piso_Claro_F=Limpiar(Piso_Claro_F)
Piso_Claro_F=assign_3G_or_4G(Piso_Claro_F)

Piso_Liberty_F=Limpiar(Piso_Liberty_F)
Piso_Liberty_F=assign_3G_or_4G(Piso_Liberty_F)

Piso_Kolbi_F=Limpiar(Piso_Kolbi_F)
Piso_Kolbi_F=assign_3G_or_4G(Piso_Kolbi_F)


print("**-----------*Sección de plts*------------**")
 #Seccion Plt
#Piso 1 edificio A
# Crear el gráfico de dispersión

plt_auxiliar()
plt_auxiliar_2()

#Piso 4 edificio A


plt.scatter(Piso_Cuatro_Liberty["Calidad_4G"], Piso_Cuatro_Liberty["NetworkTech"], color='b', label="Liberty")
plt.scatter(Piso_Cuatro_ICE["Calidad_4G"],Piso_Cuatro_ICE["NetworkTech"], color = 'g',label = "ICE")
plt.scatter(Piso_Cuatro_CLARO["Calidad_4G"],Piso_Cuatro_CLARO["NetworkTech"], color = 'r',label = "Claro")
plt.legend(loc='upper right')
plt.title("Piso 4 Edificio A")
plt.show()

plt_auxiliar_3()
a_1,b_1,x_1,y_1,z_1=Mala_cobertura(Piso_Cuatro_ICE)
a_2,b_2,x_2,y_2,z_2=Mala_cobertura(Piso_Cuatro_Liberty)
a_3,b_3,x_3,y_3,z_3=Mala_cobertura(Piso_Cuatro_CLARO)

total_1 = a_1 + b_1 + x_1 + y_1 + z_1
total_2 = a_2 + b_2 + x_2 + y_2 + z_2
total_3 = a_3 + b_3 + x_3 + y_3 + z_3

 
calidad_x=np.array(["1-Excelente","2-Buena","3-Justa","4-Mala","5-Muerta"])
calidad_y=np.array([a_1,b_1,x_1,y_1,z_1])/ total_1 * 100
calidad_y_2=np.array([a_2,b_2,x_2,y_2,z_2])/ total_2 * 100
calidad_y_3=np.array([a_3,b_3,x_3,y_3,z_3])/ total_3 * 100

# Ancho de las barras
bar_width = 0.2

positions_1 = np.arange(len(calidad_x))
positions_2 = positions_1 + bar_width + 0.05
positions_3 = positions_2 + bar_width + 0.05

# Crear la gráfica
plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

# Etiquetas y título
plt.xlabel('Calidad')
plt.ylabel('Porcentaje')
plt.title('Comparación de Calidad (Porcentaje Total)')
plt.xticks(positions_2, calidad_x)

# Añadir el valor del porcentaje dentro de la barra

for i, value in enumerate(calidad_y):
    if value>0:
        plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_2):
    if value>0:
        plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_3):
    if value>0:
        plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

# Mostrar la gráfica
plt.show()

plt_auxiliar_4()

h_1,p_1=Mala_cobertura_Sutel(Piso_Cuatro_ICE)
h_2,p_2=Mala_cobertura_Sutel(Piso_Cuatro_Liberty)
h_3,p_3=Mala_cobertura_Sutel(Piso_Cuatro_CLARO)

total_1 = h_1 + p_1
total_2 = h_2 + p_2
total_3 = h_3 + p_3


calidad_x=np.array(["1-Dentro_Umbral","2-Fuera_Umbral"])
calidad_y=np.array([h_1,p_1])/ total_1 * 100
calidad_y_2=np.array([h_2,p_2])/ total_2 * 100
calidad_y_3=np.array([h_3,p_3])/ total_3 * 100

# Ancho de las barras
bar_width = 0.2

positions_1 = np.arange(len(calidad_x))
positions_2 = positions_1 + bar_width
positions_3 = positions_2 + bar_width


# Crear la gráfica
plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

# Etiquetas y título
plt.xlabel('Umbral de cobertura')
plt.ylabel('Valores')
plt.title('Comparación de Calidad porcentaje Sutel')
plt.xticks(positions_2, calidad_x)

plt.legend()
# Añadir el valor del porcentaje dentro de la barra

for i, value in enumerate(calidad_y):
    if value>0:
        plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_2):
    if value>0:
        plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_3):
    if value>0:
        plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

# Mostrar la gráfica
plt.show()
 

print("Para ICE:")
Datos_Finales(Piso_Cuatro_ICE)

print("Para Liberty:")
Datos_Finales(Piso_Cuatro_Liberty)

print("Para Claro:")
Datos_Finales(Piso_Cuatro_CLARO)

#**********************************************

#Piso 3 edificio A

plt_auxiliar()
plt_auxiliar_2()
plt.scatter(Piso_Tres_Liberty["Calidad_4G"], Piso_Tres_Liberty["NetworkTech"], color='b', label="Liberty")
plt.scatter(Piso_Tres_ICE["Calidad_4G"],Piso_Tres_ICE["NetworkTech"], color = 'g',label = "ICE")
plt.scatter(Piso_Tres_CLARO["Calidad_4G"],Piso_Tres_CLARO["NetworkTech"], color = 'r',label = "Claro")

plt.legend(loc='upper right')
plt.title("Piso 3 Edificio A")
plt.show()

plt_auxiliar_3()
p_3_a_1,p_3_b_1,p_3_x_1,p_3_y_1,p_3_z_1=Mala_cobertura(Piso_Tres_ICE)
p_3_a_2,p_3_b_2,p_3_x_2,p_3_y_2,p_3_z_2=Mala_cobertura(Piso_Tres_Liberty)
p_3_a_3,p_3_b_3,p_3_x_3,p_3_y_3,p_3_z_3=Mala_cobertura(Piso_Tres_CLARO)

total_1=p_3_a_1+p_3_b_1+p_3_x_1+p_3_y_1+p_3_z_1
total_2=p_3_a_2+p_3_b_2+p_3_x_2+p_3_y_2+p_3_z_2
total_3=p_3_a_3+p_3_b_3+p_3_x_3+p_3_y_3+p_3_z_3

p_3_calidad_x=np.array(["1-Excelente","2-Buena","3-Justa","4-Mala","5-Muerta"])
p_3_calidad_y=np.array([p_3_a_1,p_3_b_1,p_3_x_1,p_3_y_1,p_3_z_1])/ total_1 * 100
p_3_calidad_y_2=np.array([p_3_a_2,p_3_b_2,p_3_x_2,p_3_y_2,p_3_z_2])/ total_2 * 100
p_3_calidad_y_3=np.array([p_3_a_3,p_3_b_3,p_3_x_3,p_3_y_3,p_3_z_3])/ total_3 * 100

# Ancho de las barras
bar_width = 0.2

p_3_positions_1 = np.arange(len(p_3_calidad_x))
p_3_positions_2 = p_3_positions_1 + bar_width + 0.05
p_3_positions_3 = p_3_positions_2 + bar_width + 0.05


# Crear la gráfica
plt.bar(p_3_positions_1, p_3_calidad_y, color="g", width=bar_width, label='ICE')
plt.bar(p_3_positions_2, p_3_calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
plt.bar(p_3_positions_3, p_3_calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

# Etiquetas y título
plt.xlabel('Calidad')
plt.ylabel('Valores')
plt.title('Comparación de Calidad')
plt.xticks(p_3_positions_2, p_3_calidad_x)


for i, value in enumerate(p_3_calidad_y):
    if value>0:
        plt.text(p_3_positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(p_3_calidad_y_2):
    if value>0:
        plt.text(p_3_positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(p_3_calidad_y_3):
    if value>0:
        plt.text(p_3_positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')
plt.legend()
# Mostrar la gráfica
plt.show()
plt_auxiliar_4()

#**********************************************
h_1,p_1=Mala_cobertura_Sutel(Piso_Tres_ICE)
h_2,p_2=Mala_cobertura_Sutel(Piso_Tres_Liberty)
h_3,p_3=Mala_cobertura_Sutel(Piso_Tres_CLARO)

total_1 = h_1 + p_1
total_2 = h_2 + p_2
total_3 = h_3 + p_3

calidad_x=np.array(["1-Dentro_Umbral","2-Fuera_Umbral"])
calidad_y=np.array([h_1,p_1])/ total_1 * 100
calidad_y_2=np.array([h_2,p_2])/ total_2 * 100
calidad_y_3=np.array([h_3,p_3])/ total_3 * 100

# Ancho de las barras
bar_width = 0.2

positions_1 = np.arange(len(calidad_x))
positions_2 = positions_1 + bar_width
positions_3 = positions_2 + bar_width


# Crear la gráfica
plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

# Etiquetas y título
plt.xlabel('Umbral de cobertura')
plt.ylabel('Valores')
plt.title('Comparación de Calidad')
plt.xticks(positions_2, calidad_x)

plt.legend()
for i, value in enumerate(calidad_y):
    if value>0:
        plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_2):
    if value>0:
        plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_3):
    if value>0:
        plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')


# Mostrar la gráfica
plt.show()

print("Para ICE:")
Datos_Finales(Piso_Tres_ICE)
print("Para Liberty:")
Datos_Finales(Piso_Tres_Liberty)
print("Para Claro:")
Datos_Finales(Piso_Tres_CLARO)

#Piso 2 edificio A

plt_auxiliar()
plt_auxiliar_2()
plt.scatter(Piso_Dos_Liberty["Calidad_4G"], Piso_Dos_Liberty["NetworkTech"], color='b', label="Liberty")
plt.scatter(Piso_Dos_ICE["Calidad_4G"],Piso_Dos_ICE["NetworkTech"], color = 'g',label = "ICE")
plt.scatter(Piso_Dos_CLARO["Calidad_4G"],Piso_Dos_CLARO["NetworkTech"], color = 'r',label = "Claro")

plt.legend(loc='upper right')
plt.title("Piso 2 Edificio A")  # Configurar etiquetas personalizadas en el eje x
plt.show()

plt_auxiliar_3()

a_1,b_1,x_1,y_1,z_1=Mala_cobertura(Piso_Dos_ICE)
a_2,b_2,x_2,y_2,z_2=Mala_cobertura(Piso_Dos_Liberty)
a_3,b_3,x_3,y_3,z_3=Mala_cobertura(Piso_Dos_CLARO)

total_1 = a_1 + b_1 + x_1 + y_1 + z_1
total_2 = a_2 + b_2 + x_2 + y_2 + z_2
total_3 = a_3 + b_3 + x_3 + y_3 + z_3


calidad_x=np.array(["1-Excelente","2-Buena","3-Justa","4-Mala","5-Muerta"])
calidad_y=np.array([a_1,b_1,x_1,y_1,z_1])/ total_1 * 100
calidad_y_2=np.array([a_2,b_2,x_2,y_2,z_2])/ total_2 * 100
calidad_y_3=np.array([a_3,b_3,x_3,y_3,z_3])/ total_3 * 100

# Ancho de las barras
bar_width = 0.2

positions_1 = np.arange(len(calidad_x))
positions_2 = positions_1 + bar_width + 0.05
positions_3 = positions_2 + bar_width + 0.05


# Crear la gráfica
plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

# Etiquetas y título
plt.xlabel('Calidad')
plt.ylabel('Valores')
plt.title('Comparación de Calidad (Porcentaje Total)')
plt.xticks(positions_2, calidad_x)

plt.legend()

for i, value in enumerate(calidad_y):
    if value>0:
        plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_2):
    if value>0:
        plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_3):
    if value>0:
        plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

# Mostrar la gráfica
# Mostrar la gráfica
plt.show()

plt_auxiliar_4()

#**********************************************
h_1,p_1=Mala_cobertura_Sutel(Piso_Dos_ICE)
h_2,p_2=Mala_cobertura_Sutel(Piso_Dos_Liberty)
h_3,p_3=Mala_cobertura_Sutel(Piso_Dos_CLARO)


total_1 = h_1 + p_1
total_2 = h_2 + p_2
total_3 = h_3 + p_3

calidad_x=np.array(["1-Dentro_Umbral","2-Fuera_Umbral"])
calidad_y=np.array([h_1,p_1])/ total_1 * 100
calidad_y_2=np.array([h_2,p_2])/ total_2 * 100
calidad_y_3=np.array([h_3,p_3])/ total_3 * 100

# Ancho de las barras
bar_width = 0.2

positions_1 = np.arange(len(calidad_x))
positions_2 = positions_1 + bar_width
positions_3 = positions_2 + bar_width


# Crear la gráfica
plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

# Etiquetas y título
plt.xlabel('Umbral de cobertura')
plt.ylabel('Valores')
plt.title('Comparación de Calidad Sutel')
plt.xticks(positions_2, calidad_x)

plt.legend()
for i, value in enumerate(calidad_y):
    if value>0:
        plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_2):
    if value>0:
        plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_3):
    if value>0:
        plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

# Mostrar la gráfica
plt.show()



print("Para ICE:")
Datos_Finales(Piso_Dos_ICE)

print("Para Liberty:")
Datos_Finales(Piso_Dos_Liberty)

print("Para Claro:")
Datos_Finales(Piso_Dos_CLARO)


#Piso 1 edificio A

plt_auxiliar()
plt_auxiliar_2()
plt.scatter(Piso_Uno_Liberty["Calidad_4G"], Piso_Uno_Liberty["NetworkTech"], color='b', label="Liberty")
plt.scatter(Piso_Uno_ICE["Calidad_4G"],Piso_Uno_ICE["NetworkTech"], color = 'g',label = "ICE")
plt.scatter(Piso_Uno_CLARO["Calidad_4G"],Piso_Uno_CLARO["NetworkTech"], color = 'r',label = "Claro")

plt.legend(loc='upper right')
plt.title("Piso 1 Edificio A")  # Configurar etiquetas personalizadas en el eje x
plt.show()

plt_auxiliar_3()
a_1,b_1,x_1,y_1,z_1=Mala_cobertura(Piso_Uno_ICE)
a_2,b_2,x_2,y_2,z_2=Mala_cobertura(Piso_Uno_Liberty)
a_3,b_3,x_3,y_3,z_3=Mala_cobertura(Piso_Uno_CLARO)

total_1 = a_1 + b_1 + x_1 + y_1 + z_1
total_2 = a_2 + b_2 + x_2 + y_2 + z_2
total_3 = a_3 + b_3 + x_3 + y_3 + z_3

calidad_x=np.array(["1-Excelente","2-Buena","3-Justa","4-Mala","5-Muerta"])
calidad_y=np.array([a_1,b_1,x_1,y_1,z_1])/ total_1 * 100
calidad_y_2=np.array([a_2,b_2,x_2,y_2,z_2])/ total_2 * 100
calidad_y_3=np.array([a_3,b_3,x_3,y_3,z_3])/ total_3 * 100

# Ancho de las barras
bar_width = 0.2

positions_1 = np.arange(len(calidad_x))
positions_2 = positions_1 + bar_width + 0.05
positions_3 = positions_2 + bar_width + 0.05


# Crear la gráfica
plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

# Etiquetas y título
plt.xlabel('Calidad')
plt.ylabel('Valores')
plt.title('Comparación de Calidad (Porcentaje Total)')
plt.xticks(positions_2, calidad_x)

plt.legend()


for i, value in enumerate(calidad_y):
    if value>0:
        plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_2):
    if value>0:
        plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_3):
    if value>0:
        plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')


# Mostrar la gráfica
plt.show()

plt_auxiliar_4()
#**********************************************
h_1,p_1=Mala_cobertura_Sutel(Piso_Uno_ICE)
h_2,p_2=Mala_cobertura_Sutel(Piso_Uno_Liberty)
h_3,p_3=Mala_cobertura_Sutel(Piso_Uno_CLARO)

total_1 = h_1 + p_1
total_2 = h_2 + p_2
total_3 = h_3 + p_3

calidad_x=np.array(["1-Dentro_Umbral","2-Fuera_Umbral"])
calidad_y=np.array([h_1,p_1])/ total_1 * 100
calidad_y_2=np.array([h_2,p_2])/ total_2 * 100
calidad_y_3=np.array([h_3,p_3])/ total_3 * 100

# Ancho de las barras
bar_width = 0.2

positions_1 = np.arange(len(calidad_x))
positions_2 = positions_1 + bar_width
positions_3 = positions_2 + bar_width


# Crear la gráfica
plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

# Etiquetas y título
plt.xlabel('Umbral de cobertura')
plt.ylabel('Valores')
plt.title('Comparación de Calidad')
plt.xticks(positions_2, calidad_x)

plt.legend()
for i, value in enumerate(calidad_y):
    if value>0:
        plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_2):
    if value>0:
        plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_3):
    if value>0:
        plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')
# Mostrar la gráfica
plt.show()



print("Para ICE:")
Datos_Finales(Piso_Uno_ICE)

print("Para Liberty:")
Datos_Finales(Piso_Uno_Liberty)

print("Para Claro:")
Datos_Finales(Piso_Uno_CLARO)

#Piso B/C

plt_auxiliar()
plt_auxiliar_2()
plt.scatter(Piso_Liberty_B_C["Calidad_4G"], Piso_Liberty_B_C["NetworkTech"], color='b', label="Liberty")
plt.scatter(Piso_Kolbi_B_C["Calidad_4G"],Piso_Kolbi_B_C["NetworkTech"], color = 'g',label = "ICE")
plt.scatter(Piso_Claro_B["Calidad_4G"],Piso_Claro_B["NetworkTech"], color = 'r',label = "Claro")

plt.legend(loc='upper right')
plt.title("Piso 1 Edificio B-C")
plt.show()

plt_auxiliar_3()
a_1,b_1,x_1,y_1,z_1=Mala_cobertura(Piso_Kolbi_B_C)
a_2,b_2,x_2,y_2,z_2=Mala_cobertura(Piso_Liberty_B_C)
a_3,b_3,x_3,y_3,z_3=Mala_cobertura(Piso_Claro_B)


total_1 = a_1 + b_1 + x_1 + y_1 + z_1
total_2 = a_2 + b_2 + x_2 + y_2 + z_2
total_3 = a_3 + b_3 + x_3 + y_3 + z_3

calidad_x=np.array(["1-Excelente","2-Buena","3-Justa","4-Mala","5-Muerta"])
calidad_y=np.array([a_1,b_1,x_1,y_1,z_1])/ total_1 * 100
calidad_y_2=np.array([a_2,b_2,x_2,y_2,z_2])/ total_2 * 100
calidad_y_3=np.array([a_3,b_3,x_3,y_3,z_3])/ total_3 * 100

# Ancho de las barras
bar_width = 0.2

positions_1 = np.arange(len(calidad_x))
positions_2 = positions_1 + bar_width + 0.05
positions_3 = positions_2 + bar_width + 0.05


# Crear la gráfica
plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

# Etiquetas y título
plt.xlabel('Calidad')
plt.ylabel('Valores')
plt.title('Comparación de Calidad')
plt.xticks(positions_2, calidad_x)

plt.legend()
# Añadir el valor del porcentaje dentro de la barra

for i, value in enumerate(calidad_y):
    if value>0:
        plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_2):
    if value>0:
        plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_3):
    if value>0:
        plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

# Mostrar la gráfica
plt.show()

plt_auxiliar_4()
#**********************************************
h_1,p_1=Mala_cobertura_Sutel(Piso_Kolbi_B_C)
h_2,p_2=Mala_cobertura_Sutel(Piso_Liberty_B_C)
h_3,p_3=Mala_cobertura_Sutel(Piso_Claro_B)

total_1 = h_1 + p_1
total_2 = h_2 + p_2
total_3 = h_3 + p_3

calidad_x=np.array(["1-Dentro_Umbral","2-Fuera_Umbral"])
calidad_y=np.array([h_1,p_1])/ total_1 * 100
calidad_y_2=np.array([h_2,p_2])/ total_2 * 100
calidad_y_3=np.array([h_3,p_3])/ total_3 * 100

# Ancho de las barras
bar_width = 0.2

positions_1 = np.arange(len(calidad_x))
positions_2 = positions_1 + bar_width
positions_3 = positions_2 + bar_width


# Crear la gráfica
plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

# Etiquetas y título
plt.xlabel('Umbral de cobertura')
plt.ylabel('Valores')
plt.title('Comparación de Calidad Sutel')
plt.xticks(positions_2, calidad_x)

plt.legend()
for i, value in enumerate(calidad_y):
    if value>0:
        plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_2):
    if value>0:
        plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_3):
    if value>0:
        plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')


# Mostrar la gráfica
plt.show()

print("Para ICE:")
Datos_Finales(Piso_Kolbi_B_C)
print("Para Liberty:")
Datos_Finales(Piso_Liberty_B_C)
print("Para Claro:")
Datos_Finales(Piso_Claro_B)
 




#Piso D0/E0


plt_auxiliar()
plt_auxiliar_2()
plt.scatter(Piso_Liberty_D_0_E_0["Calidad_4G"], Piso_Liberty_D_0_E_0["NetworkTech"], color='b', label="Liberty")
plt.scatter(Piso_Kolbi_D_0_E_0["Calidad_4G"],Piso_Kolbi_D_0_E_0["NetworkTech"], color = 'g',label = "ICE")
plt.scatter(Piso_Claro_D_0_E_0["Calidad_4G"],Piso_Claro_D_0_E_0["NetworkTech"], color = 'r',label = "Claro")

plt.legend(loc='upper right')
plt.title("Piso 0 Edificio D-E")


plt.show()

plt_auxiliar_3()
a_1,b_1,x_1,y_1,z_1=Mala_cobertura(Piso_Kolbi_D_0_E_0)
a_2,b_2,x_2,y_2,z_2=Mala_cobertura(Piso_Liberty_D_0_E_0)
a_3,b_3,x_3,y_3,z_3=Mala_cobertura(Piso_Claro_D_0_E_0)


total_1 = a_1 + b_1 + x_1 + y_1 + z_1
total_2 = a_2 + b_2 + x_2 + y_2 + z_2
total_3 = a_3 + b_3 + x_3 + y_3 + z_3

calidad_x=np.array(["1-Excelente","2-Buena","3-Justa","4-Mala","5-Muerta"])
calidad_y=np.array([a_1,b_1,x_1,y_1,z_1])/ total_1 * 100
calidad_y_2=np.array([a_2,b_2,x_2,y_2,z_2])/ total_2 * 100
calidad_y_3=np.array([a_3,b_3,x_3,y_3,z_3])/ total_3 * 100

# Ancho de las barras
bar_width = 0.2

positions_1 = np.arange(len(calidad_x))
positions_2 = positions_1 + bar_width + 0.05
positions_3 = positions_2 + bar_width + 0.05


# Crear la gráfica
plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

# Etiquetas y título
plt.xlabel('Calidad')
plt.ylabel('Valores')
plt.title('Comparación de Calidad (Porcentaje Total)')
plt.xticks(positions_2, calidad_x)

plt.legend()
for i, value in enumerate(calidad_y):
    if value>0:
        plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_2):
    if value>0:
        plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_3):
    if value>0:
        plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

# Mostrar la gráfica
plt.show()
plt_auxiliar_4()
#**********************************************
h_1,p_1=Mala_cobertura_Sutel(Piso_Kolbi_D_0_E_0)
h_2,p_2=Mala_cobertura_Sutel(Piso_Liberty_D_0_E_0)
h_3,p_3=Mala_cobertura_Sutel(Piso_Claro_D_0_E_0)


total_1 = h_1 + p_1
total_2 = h_2 + p_2
total_3 = h_3 + p_3

calidad_x=np.array(["1-Dentro_Umbral","2-Fuera_Umbral"])
calidad_y=np.array([h_1,p_1])/ total_1 * 100
calidad_y_2=np.array([h_2,p_2])/ total_2 * 100
calidad_y_3=np.array([h_3,p_3])/ total_3 * 100

# Ancho de las barras
bar_width = 0.2

positions_1 = np.arange(len(calidad_x))
positions_2 = positions_1 + bar_width
positions_3 = positions_2 + bar_width


# Crear la gráfica
plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

# Etiquetas y título
plt.xlabel('Umbral de cobertura')
plt.ylabel('Valores')
plt.title('Comparación de Calidad')
plt.xticks(positions_2, calidad_x)

plt.legend()
for i, value in enumerate(calidad_y):
    if value>0:
        plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_2):
    if value>0:
        plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_3):
    if value>0:
        plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')


# Mostrar la gráfica
plt.show()

print("Para ICE:")
Datos_Finales(Piso_Kolbi_D_0_E_0)
print("Para Liberty:")
Datos_Finales(Piso_Liberty_D_0_E_0)
print("Para Claro:")
Datos_Finales(Piso_Claro_D_0_E_0)





#Piso D1


plt_auxiliar()
plt_auxiliar_2()
plt.scatter(Piso_Liberty_D_1["Calidad_4G"], Piso_Liberty_D_1["NetworkTech"], color='b', label="Liberty")
plt.scatter(Piso_Kolbi_D_1["Calidad_4G"],Piso_Kolbi_D_1["NetworkTech"], color = 'g',label = "ICE")
plt.scatter(Piso_Claro_D_1["Calidad_4G"],Piso_Claro_D_1["NetworkTech"], color = 'r',label = "Claro")

plt.legend(loc='upper right')
plt.title("Piso 1 Edificio D")
plt.show()

plt_auxiliar_3()
a_1,b_1,x_1,y_1,z_1=Mala_cobertura(Piso_Kolbi_D_1)
a_2,b_2,x_2,y_2,z_2=Mala_cobertura(Piso_Liberty_D_1)
a_3,b_3,x_3,y_3,z_3=Mala_cobertura(Piso_Claro_D_1)

total_1 = a_1 + b_1 + x_1 + y_1 + z_1
total_2 = a_2 + b_2 + x_2 + y_2 + z_2
total_3 = a_3 + b_3 + x_3 + y_3 + z_3

calidad_x=np.array(["1-Excelente","2-Buena","3-Justa","4-Mala","5-Muerta"])
calidad_y=np.array([a_1,b_1,x_1,y_1,z_1])/ total_1 * 100
calidad_y_2=np.array([a_2,b_2,x_2,y_2,z_2])/ total_2 * 100
calidad_y_3=np.array([a_3,b_3,x_3,y_3,z_3])/ total_3 * 100

# Ancho de las barras
bar_width = 0.2

positions_1 = np.arange(len(calidad_x))
positions_2 = positions_1 + bar_width + 0.05
positions_3 = positions_2 + bar_width + 0.05


# Crear la gráfica
plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

# Etiquetas y título
plt.xlabel('Calidad')
plt.ylabel('Valores')
plt.title('Comparación de Calidad (Porcentaje Total)')
plt.xticks(positions_2, calidad_x)

plt.legend()
for i, value in enumerate(calidad_y):
    if value>0:
        plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_2):
    if value>0:
        plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_3):
    if value>0:
        plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

# Mostrar la gráfica
plt.show()

plt_auxiliar_4()
#**********************************************
h_1,p_1=Mala_cobertura_Sutel(Piso_Kolbi_D_1)
h_2,p_2=Mala_cobertura_Sutel(Piso_Liberty_D_1)
h_3,p_3=Mala_cobertura_Sutel(Piso_Claro_D_1)

total_1 = h_1 + p_1
total_2 = h_2 + p_2
total_3 = h_3 + p_3

calidad_x=np.array(["1-Dentro_Umbral","2-Fuera_Umbral"])
calidad_y=np.array([h_1,p_1])/ total_1 * 100
calidad_y_2=np.array([h_2,p_2])/ total_2 * 100
calidad_y_3=np.array([h_3,p_3])/ total_3 * 100

# Ancho de las barras
bar_width = 0.2

positions_1 = np.arange(len(calidad_x))
positions_2 = positions_1 + bar_width
positions_3 = positions_2 + bar_width


# Crear la gráfica
plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

# Etiquetas y título
plt.xlabel('Umbral de cobertura')
plt.ylabel('Valores')
plt.title('Comparación de Calidad Sutel')
plt.xticks(positions_2, calidad_x)

plt.legend()
for i, value in enumerate(calidad_y):
    if value>0:
        plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_2):
    if value>0:
        plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_3):
    if value>0:
        plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')
# Mostrar la gráfica
plt.show()


print("Para ICE:")

Datos_Finales(Piso_Kolbi_D_1)
print("Para Liberty:")
Datos_Finales(Piso_Liberty_D_1)
print("Para Claro:")
Datos_Finales(Piso_Claro_D_1)

 

#Piso D2


plt_auxiliar()
plt_auxiliar_2()
plt.scatter(Piso_Liberty_D_2["Calidad_4G"], Piso_Liberty_D_2["NetworkTech"], color='b', label="Liberty")
plt.scatter(Piso_Kolbi_D_2["Calidad_4G"],Piso_Kolbi_D_2["NetworkTech"], color = 'g',label = "ICE")
plt.scatter(Piso_Claro_D_2["Calidad_4G"],Piso_Claro_D_2["NetworkTech"], color = 'r',label = "Claro")

plt.legend(loc='upper right')
plt.title("Piso 2 Edificio D")
plt.show()
plt_auxiliar_3()

a_1,b_1,x_1,y_1,z_1=Mala_cobertura(Piso_Kolbi_D_2)
a_2,b_2,x_2,y_2,z_2=Mala_cobertura(Piso_Liberty_D_2)
a_3,b_3,x_3,y_3,z_3=Mala_cobertura(Piso_Claro_D_2)

total_1 = a_1 + b_1 + x_1 + y_1 + z_1
total_2 = a_2 + b_2 + x_2 + y_2 + z_2
total_3 = a_3 + b_3 + x_3 + y_3 + z_3

calidad_x=np.array(["1-Excelente","2-Buena","3-Justa","4-Mala","5-Muerta"])
calidad_y=np.array([a_1,b_1,x_1,y_1,z_1])/ total_1 * 100
calidad_y_2=np.array([a_2,b_2,x_2,y_2,z_2])/ total_2 * 100
calidad_y_3=np.array([a_3,b_3,x_3,y_3,z_3])/ total_3 * 100

# Ancho de las barras
bar_width = 0.2

positions_1 = np.arange(len(calidad_x))
positions_2 = positions_1 + bar_width + 0.05
positions_3 = positions_2 + bar_width + 0.05


# Crear la gráfica
plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

# Etiquetas y título
plt.xlabel('Calidad')
plt.ylabel('Valores')
plt.title('Comparación de Calidad')
plt.xticks(positions_2, calidad_x)

plt.legend()

for i, value in enumerate(calidad_y):
    if value>0:
        plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_2):
    if value>0:
        plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_3):
    if value>0:
        plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')
# Mostrar la gráfica
plt.show()

plt_auxiliar_4()
#**********************************************
h_1,p_1=Mala_cobertura_Sutel(Piso_Kolbi_D_2)
h_2,p_2=Mala_cobertura_Sutel(Piso_Liberty_D_2)
h_3,p_3=Mala_cobertura_Sutel(Piso_Claro_D_2)

total_1 = h_1 + p_1
total_2 = h_2 + p_2
total_3 = h_3 + p_3

calidad_x=np.array(["1-Dentro_Umbral","2-Fuera_Umbral"])
calidad_y=np.array([h_1,p_1])/ total_1 * 100
calidad_y_2=np.array([h_2,p_2])/ total_2 * 100
calidad_y_3=np.array([h_3,p_3])/ total_3 * 100

# Ancho de las barras
bar_width = 0.2

positions_1 = np.arange(len(calidad_x))
positions_2 = positions_1 + bar_width
positions_3 = positions_2 + bar_width


# Crear la gráfica
plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

# Etiquetas y título
plt.xlabel('Umbral de cobertura')
plt.ylabel('Valores')
plt.title('Comparación de Calidad Sutel')
plt.xticks(positions_2, calidad_x)

plt.legend()
for i, value in enumerate(calidad_y):
    if value>0:
        plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_2):
    if value>0:
        plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_3):
    if value>0:
        plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')


# Mostrar la gráfica
plt.show()


print("Para ICE:")
Datos_Finales(Piso_Kolbi_D_2)
print("Para Liberty:")
Datos_Finales(Piso_Liberty_D_2)
print("Para Claro:")
Datos_Finales(Piso_Claro_D_2)

#Piso D3


plt_auxiliar()
plt_auxiliar_2()
plt.scatter(Piso_Liberty_D_3["Calidad_4G"], Piso_Liberty_D_3["NetworkTech"], color='b', label="Liberty")
plt.scatter(Piso_Kolbi_D_3["Calidad_4G"],Piso_Kolbi_D_3["NetworkTech"], color = 'g',label = "ICE")
plt.scatter(Piso_Claro_D_3["Calidad_4G"],Piso_Claro_D_3["NetworkTech"], color = 'r',label = "Claro")

plt.legend(loc='upper right')
plt.title("Piso 3 Edificio D")
plt.show()
plt_auxiliar_3()

a_1,b_1,x_1,y_1,z_1=Mala_cobertura(Piso_Kolbi_D_3)
a_2,b_2,x_2,y_2,z_2=Mala_cobertura(Piso_Liberty_D_3)
a_3,b_3,x_3,y_3,z_3=Mala_cobertura(Piso_Claro_D_3)

total_1 = a_1 + b_1 + x_1 + y_1 + z_1
total_2 = a_2 + b_2 + x_2 + y_2 + z_2
total_3 = a_3 + b_3 + x_3 + y_3 + z_3

calidad_x=np.array(["1-Excelente","2-Buena","3-Justa","4-Mala","5-Muerta"])
calidad_y=np.array([a_1,b_1,x_1,y_1,z_1])/ total_1 * 100
calidad_y_2=np.array([a_2,b_2,x_2,y_2,z_2])/ total_2 * 100
calidad_y_3=np.array([a_3,b_3,x_3,y_3,z_3])/ total_3 * 100

# Ancho de las barras
bar_width = 0.2

positions_1 = np.arange(len(calidad_x))
positions_2 = positions_1 + bar_width + 0.05
positions_3 = positions_2 + bar_width + 0.05


# Crear la gráfica
plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

# Etiquetas y título
plt.xlabel('Calidad')
plt.ylabel('Valores')
plt.title('Comparación de Calidad')
plt.xticks(positions_2, calidad_x)

plt.legend()

for i, value in enumerate(calidad_y):
    if value>0:
        plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_2):
    if value>0:
        plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_3):
    if value>0:
        plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')
# Mostrar la gráfica
plt.show()

plt_auxiliar_4()
#**********************************************
h_1,p_1=Mala_cobertura_Sutel(Piso_Kolbi_D_3)
h_2,p_2=Mala_cobertura_Sutel(Piso_Liberty_D_3)
h_3,p_3=Mala_cobertura_Sutel(Piso_Claro_D_3)

total_1 = h_1 + p_1
total_2 = h_2 + p_2
total_3 = h_3 + p_3

calidad_x=np.array(["1-Dentro_Umbral","2-Fuera_Umbral"])
calidad_y=np.array([h_1,p_1])/ total_1 * 100
calidad_y_2=np.array([h_2,p_2])/ total_2 * 100
calidad_y_3=np.array([h_3,p_3])/ total_3 * 100

# Ancho de las barras
bar_width = 0.2

positions_1 = np.arange(len(calidad_x))
positions_2 = positions_1 + bar_width
positions_3 = positions_2 + bar_width


# Crear la gráfica
plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

# Etiquetas y título
plt.xlabel('Umbral de cobertura')
plt.ylabel('Valores')
plt.title('Comparación de Calidad Sutel')
plt.xticks(positions_2, calidad_x)

plt.legend()
for i, value in enumerate(calidad_y):
    if value>0:
        plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_2):
    if value>0:
        plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_3):
    if value>0:
        plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')


# Mostrar la gráfica
plt.show()


print("Para ICE:")
Datos_Finales(Piso_Kolbi_D_3)
print("Para Liberty:")
Datos_Finales(Piso_Liberty_D_3)
print("Para Claro:")
Datos_Finales(Piso_Claro_D_3)


#Piso D4


plt_auxiliar()
plt_auxiliar_2()
plt.scatter(Piso_Liberty_D_4["Calidad_4G"], Piso_Liberty_D_4["NetworkTech"], color='b', label="Liberty")
plt.scatter(Piso_Kolbi_D_4["Calidad_4G"],Piso_Kolbi_D_4["NetworkTech"], color = 'g',label = "ICE")
plt.scatter(Piso_Claro_D_4["Calidad_4G"],Piso_Claro_D_4["NetworkTech"], color = 'r',label = "Claro")

plt.legend(loc='upper right')
plt.title("Piso 4 Edificio D")
plt.show()
plt_auxiliar_3()

a_1,b_1,x_1,y_1,z_1=Mala_cobertura(Piso_Kolbi_D_4)
a_2,b_2,x_2,y_2,z_2=Mala_cobertura(Piso_Liberty_D_4)
a_3,b_3,x_3,y_3,z_3=Mala_cobertura(Piso_Claro_D_4)

total_1 = a_1 + b_1 + x_1 + y_1 + z_1
total_2 = a_2 + b_2 + x_2 + y_2 + z_2
total_3 = a_3 + b_3 + x_3 + y_3 + z_3

calidad_x=np.array(["1-Excelente","2-Buena","3-Justa","4-Mala","5-Muerta"])
calidad_y=np.array([a_1,b_1,x_1,y_1,z_1])/ total_1 * 100
calidad_y_2=np.array([a_2,b_2,x_2,y_2,z_2])/ total_2 * 100
calidad_y_3=np.array([a_3,b_3,x_3,y_3,z_3])/ total_3 * 100

# Ancho de las barras
bar_width = 0.2

positions_1 = np.arange(len(calidad_x))
positions_2 = positions_1 + bar_width + 0.05
positions_3 = positions_2 + bar_width + 0.05


# Crear la gráfica
plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

# Etiquetas y título
plt.xlabel('Calidad')
plt.ylabel('Valores')
plt.title('Comparación de Calidad')
plt.xticks(positions_2, calidad_x)

plt.legend()

for i, value in enumerate(calidad_y):
    if value>0:
        plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_2):
    if value>0:
        plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_3):
    if value>0:
        plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')
# Mostrar la gráfica
plt.show()

plt_auxiliar_4()
#**********************************************
h_1,p_1=Mala_cobertura_Sutel(Piso_Kolbi_D_4)
h_2,p_2=Mala_cobertura_Sutel(Piso_Liberty_D_4)
h_3,p_3=Mala_cobertura_Sutel(Piso_Claro_D_4)

total_1 = h_1 + p_1
total_2 = h_2 + p_2
total_3 = h_3 + p_3

calidad_x=np.array(["1-Dentro_Umbral","2-Fuera_Umbral"])
calidad_y=np.array([h_1,p_1])/ total_1 * 100
calidad_y_2=np.array([h_2,p_2])/ total_2 * 100
calidad_y_3=np.array([h_3,p_3])/ total_3 * 100

# Ancho de las barras
bar_width = 0.2

positions_1 = np.arange(len(calidad_x))
positions_2 = positions_1 + bar_width
positions_3 = positions_2 + bar_width


# Crear la gráfica
plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

# Etiquetas y título
plt.xlabel('Umbral de cobertura')
plt.ylabel('Valores')
plt.title('Comparación de Calidad Sutel')
plt.xticks(positions_2, calidad_x)

plt.legend()
for i, value in enumerate(calidad_y):
    if value>0:
        plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_2):
    if value>0:
        plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_3):
    if value>0:
        plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')


# Mostrar la gráfica
plt.show()


print("Para ICE:")
Datos_Finales(Piso_Kolbi_D_4)
print("Para Liberty:")
Datos_Finales(Piso_Liberty_D_4)
print("Para Claro:")
Datos_Finales(Piso_Claro_D_4)


#Piso 1 EDIFICIO E


plt_auxiliar()
plt_auxiliar_2()
plt.scatter(Piso_Liberty_E_1["Calidad_4G"], Piso_Liberty_E_1["NetworkTech"], color='b', label="Liberty")
plt.scatter(Piso_Kolbi_E_1["Calidad_4G"],Piso_Kolbi_E_1["NetworkTech"], color = 'g',label = "ICE")
plt.scatter(Piso_Claro_E_1["Calidad_4G"],Piso_Claro_E_1["NetworkTech"], color = 'r',label = "Claro")

plt.legend(loc='upper right')
plt.title("Piso 1 Edificio E")
plt.show()
plt_auxiliar_3()

a_1,b_1,x_1,y_1,z_1=Mala_cobertura(Piso_Kolbi_E_1)
a_2,b_2,x_2,y_2,z_2=Mala_cobertura(Piso_Liberty_E_1)
a_3,b_3,x_3,y_3,z_3=Mala_cobertura(Piso_Claro_E_1)


total_1 = a_1 + b_1 + x_1 + y_1 + z_1
total_2 = a_2 + b_2 + x_2 + y_2 + z_2
total_3 = a_3 + b_3 + x_3 + y_3 + z_3

calidad_x=np.array(["1-Excelente","2-Buena","3-Justa","4-Mala","5-Muerta"])
calidad_y=np.array([a_1,b_1,x_1,y_1,z_1])/ total_1 * 100
calidad_y_2=np.array([a_2,b_2,x_2,y_2,z_2])/ total_2 * 100
calidad_y_3=np.array([a_3,b_3,x_3,y_3,z_3])/ total_3 * 100

# Ancho de las barras
bar_width = 0.2

positions_1 = np.arange(len(calidad_x))
positions_2 = positions_1 + bar_width + 0.05
positions_3 = positions_2 + bar_width + 0.05


# Crear la gráfica
plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

# Etiquetas y título
plt.xlabel('Calidad')
plt.ylabel('Valores')
plt.title('Comparación de Calidad')
plt.xticks(positions_2, calidad_x)

plt.legend()
for i, value in enumerate(calidad_y):
    if value>0:
        plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_2):
    if value>0:
        plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_3):
    if value>0:
        plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

# Mostrar la gráfica
# Mostrar la gráfica
plt.show()

plt_auxiliar_4()

#**********************************************
h_1,p_1=Mala_cobertura_Sutel(Piso_Kolbi_E_1)
h_2,p_2=Mala_cobertura_Sutel(Piso_Liberty_E_1)
h_3,p_3=Mala_cobertura_Sutel(Piso_Claro_E_1)

total_1 = h_1 + p_1
total_2 = h_2 + p_2
total_3 = h_3 + p_3

calidad_x=np.array(["1-Dentro_Umbral","2-Fuera_Umbral"])
calidad_y=np.array([h_1,p_1])/ total_1 * 100
calidad_y_2=np.array([h_2,p_2])/ total_2 * 100
calidad_y_3=np.array([h_3,p_3])/ total_3 * 100

# Ancho de las barras
bar_width = 0.2

positions_1 = np.arange(len(calidad_x))
positions_2 = positions_1 + bar_width
positions_3 = positions_2 + bar_width


# Crear la gráfica
plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

# Etiquetas y título
plt.xlabel('Umbral de cobertura')
plt.ylabel('Valores')
plt.title('Comparación de Calidad')
plt.xticks(positions_2, calidad_x)

plt.legend()

for i, value in enumerate(calidad_y):
    if value>0:
        plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_2):
    if value>0:
        plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_3):
    if value>0:
        plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

# Mostrar la gráfica
plt.show()


print("Para ICE:")

Datos_Finales(Piso_Kolbi_E_1)
print("Para Liberty:")
Datos_Finales(Piso_Liberty_E_1)
print("Para Claro:")
Datos_Finales(Piso_Claro_E_1)


#Piso 2 edificio E
plt_auxiliar()
plt_auxiliar_2()
plt.scatter(Piso_Liberty_E_2["Calidad_4G"], Piso_Liberty_E_2["NetworkTech"], color='b', label="Liberty")
plt.scatter(Piso_Kolbi_E_2["Calidad_4G"],Piso_Kolbi_E_2["NetworkTech"], color = 'g',label = "ICE")
plt.scatter(Piso_Claro_E_2["Calidad_4G"],Piso_Claro_E_2["NetworkTech"], color = 'r',label = "Claro")

plt.legend(loc='upper right')
plt.title("Piso 2 Edificio E")
plt.show()

plt_auxiliar_3()
a_1,b_1,x_1,y_1,z_1=Mala_cobertura(Piso_Kolbi_E_2)
a_2,b_2,x_2,y_2,z_2=Mala_cobertura(Piso_Liberty_E_2)
a_3,b_3,x_3,y_3,z_3=Mala_cobertura(Piso_Claro_E_2)


total_1 = a_1 + b_1 + x_1 + y_1 + z_1
total_2 = a_2 + b_2 + x_2 + y_2 + z_2
total_3 = a_3 + b_3 + x_3 + y_3 + z_3


calidad_x=np.array(["1-Excelente","2-Buena","3-Justa","4-Mala","5-Muerta"])
calidad_y=np.array([a_1,b_1,x_1,y_1,z_1])/ total_1 * 100
calidad_y_2=np.array([a_2,b_2,x_2,y_2,z_2])/ total_2 * 100
calidad_y_3=np.array([a_3,b_3,x_3,y_3,z_3])/ total_3 * 100

# Ancho de las barras
bar_width = 0.2

positions_1 = np.arange(len(calidad_x))
positions_2 = positions_1 + bar_width + 0.05
positions_3 = positions_2 + bar_width + 0.05


# Crear la gráfica
plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

# Etiquetas y título
plt.xlabel('Calidad')
plt.ylabel('Valores')
plt.title('Comparación de Calidad')
plt.xticks(positions_2, calidad_x)

plt.legend()

for i, value in enumerate(calidad_y):
    if value>0:
        plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_2):
    if value>0:
        plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_3):
    if value>0:
        plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

# Mostrar la gráfica
plt.show()


plt_auxiliar_4()
#**********************************************
h_1,p_1=Mala_cobertura_Sutel(Piso_Kolbi_E_2)
h_2,p_2=Mala_cobertura_Sutel(Piso_Liberty_E_2)
h_3,p_3=Mala_cobertura_Sutel(Piso_Claro_E_2)

total_1 = h_1 + p_1
total_2 = h_2 + p_2
total_3 = h_3 + p_3

calidad_x=np.array(["1-Dentro_Umbral","2-Fuera_Umbral"])
calidad_y=np.array([h_1,p_1])/ total_1 * 100
calidad_y_2=np.array([h_2,p_2])/ total_2 * 100
calidad_y_3=np.array([h_3,p_3])/ total_3 * 100

# Ancho de las barras
bar_width = 0.2

positions_1 = np.arange(len(calidad_x))
positions_2 = positions_1 + bar_width
positions_3 = positions_2 + bar_width


# Crear la gráfica
plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

# Etiquetas y título
plt.xlabel('Umbral de cobertura')
plt.ylabel('Valores')
plt.title('Comparación de Calidad')
plt.xticks(positions_2, calidad_x)

plt.legend()

for i, value in enumerate(calidad_y):
    if value>0:
        plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_2):
    if value>0:
        plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_3):
    if value>0:
        plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

# Mostrar la gráfica
plt.show()


print("Para ICE:")
Datos_Finales(Piso_Kolbi_E_2)
print("Para Liberty:")
Datos_Finales(Piso_Liberty_E_2)
print("Para Claro:")
Datos_Finales(Piso_Claro_E_2)



#Piso 3 edificio E
plt_auxiliar()
plt_auxiliar_2()
plt.scatter(Piso_Liberty_E_3["Calidad_4G"], Piso_Liberty_E_3["NetworkTech"], color='b', label="Liberty")
plt.scatter(Piso_Kolbi_E_3["Calidad_4G"],Piso_Kolbi_E_3["NetworkTech"], color = 'g',label = "ICE")
plt.scatter(Piso_Claro_E_3["Calidad_4G"],Piso_Claro_E_3["NetworkTech"], color = 'r',label = "Claro")

plt.legend(loc='upper right')
plt.title("Piso 3 Edificio E")
plt.show()

plt_auxiliar_3()
a_1,b_1,x_1,y_1,z_1=Mala_cobertura(Piso_Kolbi_E_3)
a_2,b_2,x_2,y_2,z_2=Mala_cobertura(Piso_Liberty_E_3)
a_3,b_3,x_3,y_3,z_3=Mala_cobertura(Piso_Claro_E_3)

total_1 = a_1 + b_1 + x_1 + y_1 + z_1
total_2 = a_2 + b_2 + x_2 + y_2 + z_2
total_3 = a_3 + b_3 + x_3 + y_3 + z_3

calidad_x=np.array(["1-Excelente","2-Buena","3-Justa","4-Mala","5-Muerta"])
calidad_y=np.array([a_1,b_1,x_1,y_1,z_1])/ total_1 * 100
calidad_y_2=np.array([a_2,b_2,x_2,y_2,z_2])/ total_2 * 100
calidad_y_3=np.array([a_3,b_3,x_3,y_3,z_3])/ total_3 * 100

# Ancho de las barras
bar_width = 0.2

positions_1 = np.arange(len(calidad_x))
positions_2 = positions_1 + bar_width + 0.05
positions_3 = positions_2 + bar_width + 0.05


# Crear la gráfica
plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

# Etiquetas y título
plt.xlabel('Calidad')
plt.ylabel('Valores')
plt.title('Comparación de Calidad (Porcentaje Total)')
plt.xticks(positions_2, calidad_x)

plt.legend()

for i, value in enumerate(calidad_y):
    if value>0:
        plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_2):
    if value>0:
        plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_3):
    if value>0:
        plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

# Mostrar la gráfica
plt.show()


plt_auxiliar_4()
#**********************************************
h_1,p_1=Mala_cobertura_Sutel(Piso_Kolbi_E_3)
h_2,p_2=Mala_cobertura_Sutel(Piso_Liberty_E_3)
h_3,p_3=Mala_cobertura_Sutel(Piso_Claro_E_3)

total_1 = h_1 + p_1
total_2 = h_2 + p_2
total_3 = h_3 + p_3

calidad_x=np.array(["1-Dentro_Umbral","2-Fuera_Umbral"])
calidad_y=np.array([h_1,p_1])/ total_1 * 100
calidad_y_2=np.array([h_2,p_2])/ total_2 * 100
calidad_y_3=np.array([h_3,p_3])/ total_3 * 100

# Ancho de las barras
bar_width = 0.2

positions_1 = np.arange(len(calidad_x))
positions_2 = positions_1 + bar_width
positions_3 = positions_2 + bar_width


# Crear la gráfica
plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

# Etiquetas y título
plt.xlabel('Umbral de cobertura')
plt.ylabel('Valores')
plt.title('Comparación de Calidad')
plt.xticks(positions_2, calidad_x)

plt.legend()
for i, value in enumerate(calidad_y):
    if value>0:
        plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_2):
    if value>0:
        plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_3):
    if value>0:
        plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

# Mostrar la gráfica
plt.show()

print("Para ICE:")
Datos_Finales(Piso_Kolbi_E_3)
print("Para Liberty:")
Datos_Finales(Piso_Liberty_E_3)
print("Para Claro:")
Datos_Finales(Piso_Claro_E_3)

#Piso 4 edificio E
plt_auxiliar()
plt_auxiliar_2()
plt.scatter(Piso_Liberty_E_4["Calidad_4G"], Piso_Liberty_E_4["NetworkTech"], color='b', label="Liberty")
plt.scatter(Piso_Kolbi_E_4["Calidad_4G"],Piso_Kolbi_E_4["NetworkTech"], color = 'g',label = "ICE")
plt.scatter(Piso_Claro_E_4["Calidad_4G"],Piso_Claro_E_4["NetworkTech"], color = 'r',label = "Claro")

plt.legend(loc='upper right')
plt.title("Piso 4 Edificio E")
plt.show()

plt_auxiliar_3()

a_1,b_1,x_1,y_1,z_1=Mala_cobertura(Piso_Kolbi_E_4)
a_2,b_2,x_2,y_2,z_2=Mala_cobertura(Piso_Liberty_E_4)
a_3,b_3,x_3,y_3,z_3=Mala_cobertura(Piso_Claro_E_4)

total_1 = a_1 + b_1 + x_1 + y_1 + z_1
total_2 = a_2 + b_2 + x_2 + y_2 + z_2
total_3 = a_3 + b_3 + x_3 + y_3 + z_3

calidad_x=np.array(["1-Excelente","2-Buena","3-Justa","4-Mala","5-Muerta"])
calidad_y=np.array([a_1,b_1,x_1,y_1,z_1])/ total_1 * 100
calidad_y_2=np.array([a_2,b_2,x_2,y_2,z_2])/ total_2 * 100
calidad_y_3=np.array([a_3,b_3,x_3,y_3,z_3])/ total_3 * 100

# Ancho de las barras
bar_width = 0.2

positions_1 = np.arange(len(calidad_x))
positions_2 = positions_1 + bar_width +0.05
positions_3 = positions_2 + bar_width +0.05


# Crear la gráfica
plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

# Etiquetas y título
plt.xlabel('Calidad')
plt.ylabel('Valores')
plt.title('Comparación de Calidad')
plt.xticks(positions_2, calidad_x)

plt.legend()


for i, value in enumerate(calidad_y):
    if value>0:
        plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_2):
    if value>0:
        plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_3):
    if value>0:
        plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')
# Mostrar la gráfica
plt.show()

plt_auxiliar_4()
#**********************************************
h_1,p_1=Mala_cobertura_Sutel(Piso_Kolbi_E_4)
h_2,p_2=Mala_cobertura_Sutel(Piso_Liberty_E_4)
h_3,p_3=Mala_cobertura_Sutel(Piso_Claro_E_4)

total_1 = h_1 + p_1
total_2 = h_2 + p_2
total_3 = h_3 + p_3

calidad_x=np.array(["1-Dentro_Umbral","2-Fuera_Umbral"])
calidad_y=np.array([h_1,p_1])/ total_1 * 100
calidad_y_2=np.array([h_2,p_2])/ total_2 * 100
calidad_y_3=np.array([h_3,p_3])/ total_3 * 100

# Ancho de las barras
bar_width = 0.2

positions_1 = np.arange(len(calidad_x))
positions_2 = positions_1 + bar_width
positions_3 = positions_2 + bar_width


# Crear la gráfica
plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

# Etiquetas y título
plt.xlabel('Umbral de cobertura')
plt.ylabel('Valores')
plt.title('Comparación de Calidad')
plt.xticks(positions_2, calidad_x)

plt.legend()
for i, value in enumerate(calidad_y):
    if value>0:
        plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_2):
    if value>0:
        plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_3):
    if value>0:
        plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

# Mostrar la gráfica
plt.show()

print("Para ICE:")
Datos_Finales(Piso_Kolbi_E_4)
print("Para Liberty:")
Datos_Finales(Piso_Liberty_E_4)
print("Para Claro:")
Datos_Finales(Piso_Claro_E_4)


#Piso 5 edificio E
plt_auxiliar()
plt_auxiliar_2()
plt.scatter(Piso_Liberty_E_5["Calidad_4G"], Piso_Liberty_E_5["NetworkTech"], color='b', label="Liberty")
plt.scatter(Piso_Kolbi_E_5["Calidad_4G"],Piso_Kolbi_E_5["NetworkTech"], color = 'g',label = "ICE")
plt.scatter(Piso_Claro_E_5["Calidad_4G"],Piso_Claro_E_5["NetworkTech"], color = 'r',label = "Claro")

plt.legend(loc='upper right')
plt.title("Piso 5 Edificio E")
plt.show()

plt_auxiliar_3()
a_1,b_1,x_1,y_1,z_1=Mala_cobertura(Piso_Kolbi_E_5)
a_2,b_2,x_2,y_2,z_2=Mala_cobertura(Piso_Liberty_E_5)
a_3,b_3,x_3,y_3,z_3=Mala_cobertura(Piso_Claro_E_5)


total_1 = a_1 + b_1 + x_1 + y_1 + z_1
total_2 = a_2 + b_2 + x_2 + y_2 + z_2
total_3 = a_3 + b_3 + x_3 + y_3 + z_3

calidad_x=np.array(["1-Excelente","2-Buena","3-Justa","4-Mala","5-Muerta"])
calidad_y=np.array([a_1,b_1,x_1,y_1,z_1])/ total_1 * 100
calidad_y_2=np.array([a_2,b_2,x_2,y_2,z_2])/ total_2 * 100
calidad_y_3=np.array([a_3,b_3,x_3,y_3,z_3])/ total_3 * 100

# Ancho de las barras
bar_width = 0.2

positions_1 = np.arange(len(calidad_x))
positions_2 = positions_1 + bar_width +0.05
positions_3 = positions_2 + bar_width +0.05


# Crear la gráfica
plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

# Etiquetas y título
plt.xlabel('Calidad')
plt.ylabel('Valores')
plt.title('Comparación de Calidad (Porcentaje Total)')
plt.xticks(positions_2, calidad_x)

plt.legend()

for i, value in enumerate(calidad_y):
    if value>0:
        plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_2):
    if value>0:
        plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_3):
    if value>0:
        plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')
# Mostrar la gráfica
plt.show()

plt_auxiliar_4()
#**********************************************
h_1,p_1=Mala_cobertura_Sutel(Piso_Kolbi_E_5)
h_2,p_2=Mala_cobertura_Sutel(Piso_Liberty_E_5)
h_3,p_3=Mala_cobertura_Sutel(Piso_Claro_E_5)


total_1 = h_1 + p_1
total_2 = h_2 + p_2
total_3 = h_3 + p_3

calidad_x=np.array(["1-Dentro_Umbral","2-Fuera_Umbral"])
calidad_y=np.array([h_1,p_1])/ total_1 * 100
calidad_y_2=np.array([h_2,p_2])/ total_2 * 100
calidad_y_3=np.array([h_3,p_3])/ total_3 * 100

# Ancho de las barras
bar_width = 0.2

positions_1 = np.arange(len(calidad_x))
positions_2 = positions_1 + bar_width
positions_3 = positions_2 + bar_width


# Crear la gráfica
plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

# Etiquetas y título
plt.xlabel('Umbral de cobertura')
plt.ylabel('Valores')
plt.title('Comparación de Calidad')
plt.xticks(positions_2, calidad_x)

plt.legend()

for i, value in enumerate(calidad_y):
    if value>0:
        plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_2):
    if value>0:
        plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_3):
    if value>0:
        plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')
# Mostrar la gráfica
plt.show()

print("Para ICE:")
Datos_Finales(Piso_Kolbi_E_5)
print("Para Liberty:")
Datos_Finales(Piso_Liberty_E_5)
print("Para Claro:")
Datos_Finales(Piso_Claro_E_5)
 
#Piso 1 edificio F

plt_auxiliar()
plt_auxiliar_2()
plt.scatter(Piso_Liberty_F["Calidad_4G"], Piso_Liberty_F["NetworkTech"], color='b', label="Liberty")
plt.scatter(Piso_Kolbi_F["Calidad_4G"],Piso_Kolbi_F["NetworkTech"], color = 'g',label = "ICE")
plt.scatter(Piso_Claro_F["Calidad_4G"],Piso_Claro_F["NetworkTech"], color = 'r',label = "Claro")

plt.legend(loc='upper right')
plt.title("Piso 1 Edificio F")
plt.show()

plt_auxiliar_3()

a_1,b_1,x_1,y_1,z_1=Mala_cobertura(Piso_Kolbi_F)
a_2,b_2,x_2,y_2,z_2=Mala_cobertura(Piso_Liberty_F)
a_3,b_3,x_3,y_3,z_3=Mala_cobertura(Piso_Claro_F)

total_1 = a_1 + b_1 + x_1 + y_1 + z_1
total_2 = a_2 + b_2 + x_2 + y_2 + z_2
total_3 = a_3 + b_3 + x_3 + y_3 + z_3

calidad_x=np.array(["1-Excelente","2-Buena","3-Justa","4-Mala","5-Muerta"])
calidad_y=np.array([a_1,b_1,x_1,y_1,z_1])/ total_1 * 100
calidad_y_2=np.array([a_2,b_2,x_2,y_2,z_2])/ total_2 * 100
calidad_y_3=np.array([a_3,b_3,x_3,y_3,z_3])/ total_3 * 100

# Ancho de las barras
bar_width = 0.2

positions_1 = np.arange(len(calidad_x))
positions_2 = positions_1 + bar_width +0.05
positions_3 = positions_2 + bar_width +0.05


# Crear la gráfica
plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

# Etiquetas y título
plt.xlabel('Calidad')
plt.ylabel('Valores')
plt.title('Comparación de Calidad en porcentaje')
plt.xticks(positions_2, calidad_x)

plt.legend()


for i, value in enumerate(calidad_y):
    if value>0:
        plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_2):
    if value>0:
        plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_3):
    if value>0:
        plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')
# Mostrar la gráfica
plt.show()

plt_auxiliar_4()
#**********************************************
h_1,p_1=Mala_cobertura_Sutel(Piso_Kolbi_F)
h_2,p_2=Mala_cobertura_Sutel(Piso_Liberty_F)
h_3,p_3=Mala_cobertura_Sutel(Piso_Claro_F)


total_1 = h_1 + p_1
total_2 = h_2 + p_2
total_3 = h_3 + p_3

calidad_x=np.array(["1-Dentro_Umbral","2-Fuera_Umbral"])
calidad_y=np.array([h_1,p_1])/ total_1 * 100
calidad_y_2=np.array([h_2,p_2])/ total_2 * 100
calidad_y_3=np.array([h_3,p_3])/ total_3 * 100

# Ancho de las barras
bar_width = 0.2

positions_1 = np.arange(len(calidad_x))
positions_2 = positions_1 + bar_width
positions_3 = positions_2 + bar_width


# Crear la gráfica
plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

# Etiquetas y título
plt.xlabel('Umbral de cobertura')
plt.ylabel('Valores')
plt.title('Comparación de Calidad')
plt.xticks(positions_2, calidad_x)

plt.legend()
for i, value in enumerate(calidad_y):
    if value>0:
        plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_2):
    if value>0:
        plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

for i, value in enumerate(calidad_y_3):
    if value>0:
        plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

# Mostrar la gráfica
plt.show()

print("Para ICE:")
Datos_Finales(Piso_Kolbi_F)
print("Para Liberty:")
Datos_Finales(Piso_Liberty_F)
print("Para Claro:")
Datos_Finales(Piso_Claro_F)
 