# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import pandas as pd
import glob
import numpy as np
import random
import matplotlib.pyplot as plt

#******************************************************************************************

#Edificio A
#CLARO
column_names = pd.Series(['Time', 'Longitude', 'Latitude', 'Operador',"Network" , 'NetworkTech', 'Level', "Speed"])
Piso_Cuatro = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_de_Claro\Edificio_A\Claro_2023.10.14_08.15.48\Claro_2023.10.14_08.15.48.txt", sep=';', decimal=',') 
#print(df.info())
Piso_Tres = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_de_Claro\Edificio_A\Claro_2023.10.14_08.35.22\Claro_2023.10.14_08.35.22.txt", sep=';', decimal=',')
Piso_Dos = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_de_Claro\Edificio_A\Claro_2023.10.14_08.44.36\Claro_2023.10.14_08.44.36.txt", sep=';', decimal=',') 
Piso_Uno = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_de_Claro\Edificio_A\Claro_2023.10.14_08.53.29\Claro_2023.10.14_08.53.29.txt", sep=';', decimal=',')  

#ICE

Piso_Cuatro_ICE = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_de_ICE\Edificio_A\ICE_2023.10.14_08.16.07\ICE_2023.10.14_08.16.07.txt", sep=';', decimal=',') 
Piso_Tres_ICE = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_de_ICE\Edificio_A\ICE_2023.10.14_08.36.25\ICE_2023.10.14_08.36.25.txt", sep=';', decimal=',') 
Piso_Dos_ICE = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_de_ICE\Edificio_A\ICE_2023.10.14_08.48.51\ICE_2023.10.14_08.48.51.txt", sep=';', decimal=',') 
Piso_Uno_ICE = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_de_ICE\Edificio_A\ICE_2023.10.14_08.57.51\ICE_2023.10.14_08.57.51.txt", sep=';', decimal=',') 


#Liberty

Piso_Cuatro_Liberty = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_de_Liberty\Edificio_A\Sin_servicio_2023.10.14_08.27.42\Sin_servicio_2023.10.14_08.27.42.txt", sep=';', decimal=',') 
Piso_Tres_Liberty = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_de_Liberty\Edificio_A\Sin_servicio_2023.10.14_08.40.26\Sin_servicio_2023.10.14_08.40.26.txt", sep=';', decimal=',') 
Piso_Dos_Liberty = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_de_Liberty\Edificio_A\Sin_servicio_2023.10.14_08.48.29\Sin_servicio_2023.10.14_08.48.29.txt", sep=';', decimal=',') 
Piso_Uno_Liberty = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_de_Liberty\Edificio_A\Sin_servicio_2023.10.14_08.57.49\Sin_servicio_2023.10.14_08.57.49.txt", sep=';', decimal=',') 

#******************************************************************************************
#Edificio B

Piso_Claro_B = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_de_Claro\Edificio_B\Claro_2023.10.14_09.12.51\Claro_2023.10.14_09.12.51.txt", sep=';', decimal=',')
Piso_Kolbi_B = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_de_ICE\Edificio_B\ICE_2023.10.14_09.10.52\ICE_2023.10.14_09.10.52.txt", sep=';', decimal=',')
Piso_Liberty_B = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_de_Liberty\Edificio_B\Sin_servicio_2023.10.14_09.18.26\Sin_servicio_2023.10.14_09.18.26.txt", sep=';', decimal=',')


#******************************************************************************************
#Edificio C
Piso_Claro_C = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_de_Claro\Edificio_C\Claro_2023.10.14_09.25.27\Claro_2023.10.14_09.25.27.txt", sep=';', decimal=',')
Piso_Kolbi_C = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_de_ICE\Edificio_C\ICE_2023.10.14_09.25.32\ICE_2023.10.14_09.25.32.txt", sep=';', decimal=',')
Piso_Liberty_C = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_de_Liberty\Edificio_C\Claro_2023.10.14_09.29.16\Claro_2023.10.14_09.29.16.txt", sep=';', decimal=',')


#******************************************************************************************
#Edificio D

#Piso 1
Piso_Claro_D_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_de_Claro\Edificio_D\Claro_2023.10.14_09.32.04\Claro_2023.10.14_09.32.04.txt", sep=';', decimal=',')
#Piso 2
Piso_Claro_D_0 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_de_Claro\Edificio_D\Claro_2023.10.14_09.42.11\Claro_2023.10.14_09.42.11.txt", sep=';', decimal=',')

#Piso 1
Piso_Kolbi_D_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_de_ICE\Edificio_D\ICE_2023.10.14_09.42.16\ICE_2023.10.14_09.42.16.txt", sep=';', decimal=',')
#Piso 2
Piso_Kolbi_D_0 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_de_ICE\Edificio_D\ICE_2023.10.14_09.57.13\ICE_2023.10.14_09.57.13.txt", sep=';', decimal=',')

#Piso 1
Piso_Liberty_D_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_de_ICE\Edificio_D\ICE_2023.10.14_09.42.16\ICE_2023.10.14_09.42.16.txt", sep=';', decimal=',')
#Piso 2
Piso_Liberty_D_0 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_de_ICE\Edificio_D\ICE_2023.10.14_09.57.13\ICE_2023.10.14_09.57.13.txt", sep=';', decimal=',')







#Funciones
def Limpiar(marks):
    b=[]
    m=len(marks.index)
    for j in range(m):
        Filaaux=marks.iloc[j,0]
        Filaaux=Filaaux.split()
        b.append(Filaaux)
    Datos=pd.DataFrame(b,columns=column_names)
    Datos.loc[Datos["Network"] == "4G", "Red_G"] = 4
    Datos.loc[Datos["Network"] == "3G", "Red_G"] = 3
    Datos.drop(['Time', 'Longitude', 'Latitude','Network','Level' ], axis=1, inplace=True)
    Datos["NetworkTech"]=Datos["NetworkTech"].astype(float)
    Datos["Speed"]=Datos["Speed"].astype(float)
    
    return Datos

def assign_Result_4G(marks):
    
    if marks <= -60.0 and marks >= -89.0 :
        result = "Excelente"    
    elif marks <= -90.0 and marks >= -105.0 :
        result = "Buena" 
    elif marks <= -106.0 or marks >= -110.0 :
        result = "Justa"  
    elif  marks <= -111.0 or marks >= -119.0 :
        result = "Mala"
    
    elif marks < -120.0 :
        result = "Muera"  

    else:
        result = "Excelente"
    return result

def assign_Result_3G(marks):
    
    if marks <= -60.0 and marks >= -85.0 :
        result = "Buena" 
    elif marks <= -86.0 or marks >= -100.0 :
        result = "Justa"  
    elif  marks <= -101.0 or marks >= -109.0 :
        result = "Mala" 
   
    elif marks <= -110.0 :
        result = "Muera" 
  
    else:
        result = "Excelente"
    return result

def assign_3G_or_4G(marks):
    for i in range(len(marks)):
        if marks.iloc[i]['Red_G']==4.0:
            marks["Calidad_4G"] = marks["NetworkTech"].apply(assign_Result_4G)
            
        else:
            marks["Calidad_3G"] = marks["NetworkTech"].apply(assign_Result_3G)
             
    return marks


        
def Datos_Finales(marks):
    display(marks)
    Varianza=marks["NetworkTech"].var(ddof=0)
    Desviacion_Estandar=marks["NetworkTech"].std()
    Promedio=marks["NetworkTech"].mean()
    print("La varianza de la cobertura es:",Varianza)#La variación de parametro
    print("La Desviacion estandar es:",Desviacion_Estandar)#Cuanto se desvian los parametros entre sí
    print("El promedio es",Promedio)#Promedio de la señal
   # marks["NetworkTech"].plot()
    
#********************************************************************************
print("*******************************************************")
print("Edificio A-Claro")
#Pisol
Piso_Uno=Limpiar(Piso_Uno)
Piso_Uno=assign_3G_or_4G(Piso_Uno)
Datos_Finales(Piso_Uno)

#Piso2
Piso_Dos=Limpiar(Piso_Dos)
Piso_Dos=assign_3G_or_4G(Piso_Dos)
Datos_Finales(Piso_Dos)

#Piso3
Piso_Tres=Limpiar(Piso_Tres)
Piso_Tres=assign_3G_or_4G(Piso_Tres)
Datos_Finales(Piso_Tres)

#Piso4
Piso_Cuatro=Limpiar(Piso_Cuatro)
Piso_Cuatro=assign_3G_or_4G(Piso_Cuatro)
Datos_Finales(Piso_Cuatro)

#********************************************************************************
print("*******************************************************")
print("Edificio A-ICE ")

Piso_Uno_ICE=Limpiar(Piso_Uno_ICE)
Piso_Uno_ICE=assign_3G_or_4G(Piso_Uno_ICE)
Datos_Finales(Piso_Uno_ICE)

#Piso2
Piso_Dos_ICE=Limpiar(Piso_Dos_ICE)
Piso_Dos_ICE=assign_3G_or_4G(Piso_Dos_ICE)
Datos_Finales(Piso_Dos_ICE)

#Piso3
Piso_Tres_ICE=Limpiar(Piso_Tres_ICE)
Piso_Tres_ICE=assign_3G_or_4G(Piso_Tres_ICE)
Datos_Finales(Piso_Tres_ICE)

#Piso4
Piso_Cuatro_ICE=Limpiar(Piso_Cuatro_ICE)
Piso_Cuatro_ICE=assign_3G_or_4G(Piso_Cuatro_ICE)
Datos_Finales(Piso_Cuatro_ICE)

print("*******************************************************")
print("Edificio A-Liberty ")

Piso_Uno_Liberty=Limpiar(Piso_Uno_Liberty)
Piso_Uno_LibertyE=assign_3G_or_4G(Piso_Uno_Liberty)
Datos_Finales(Piso_Uno_Liberty)

#Piso2
Piso_Dos_Liberty=Limpiar(Piso_Dos_Liberty)
Piso_Dos_Liberty=assign_3G_or_4G(Piso_Dos_Liberty)
Datos_Finales(Piso_Dos_Liberty)

#Piso3
Piso_Tres_Liberty=Limpiar(Piso_Tres_Liberty)
Piso_Tres_Liberty=assign_3G_or_4G(Piso_Tres_Liberty)
Datos_Finales(Piso_Tres_Liberty)

#Piso4
Piso_Cuatro_Liberty=Limpiar(Piso_Cuatro_Liberty)
Piso_Cuatro_Liberty=assign_3G_or_4G(Piso_Cuatro_Liberty)
Datos_Finales(Piso_Cuatro_Liberty)

print("*******************************************************")
print("Edificio B-Claro ")

Piso_Claro_B=Limpiar(Piso_Claro_B)
Piso_Claro_B=assign_3G_or_4G(Piso_Claro_B)
Datos_Finales(Piso_Claro_B)

print("*******************************************************")
print("Edificio B-Kolbi ")
Piso_Kolbi_B=Limpiar(Piso_Kolbi_B)
Piso_Kolbi_B=assign_3G_or_4G(Piso_Kolbi_B)
Datos_Finales(Piso_Kolbi_B)

print("*******************************************************")
print("Edificio B-Liberty ")
Piso_Liberty_B=Limpiar(Piso_Liberty_B)
Piso_Liberty_B=assign_3G_or_4G(Piso_Liberty_B)
Datos_Finales(Piso_Liberty_B)


print("*******************************************************")
print("Edificio C-Claro ")

Piso_Claro_C=Limpiar(Piso_Claro_C)
Piso_Claro_C=assign_3G_or_4G(Piso_Claro_C)
Datos_Finales(Piso_Claro_C)

print("*******************************************************")
print("Edificio C-Kolbi ")
Piso_Kolbi_C=Limpiar(Piso_Kolbi_C)
Piso_Kolbi_C=assign_3G_or_4G(Piso_Kolbi_C)
Datos_Finales(Piso_Kolbi_C)

print("*******************************************************")
Piso_Liberty_C=Limpiar(Piso_Liberty_C)
Piso_Liberty_C=assign_3G_or_4G(Piso_Liberty_C)
Datos_Finales(Piso_Liberty_C)

print("*******************************************************")
print("Edificio D-Claro ")
Piso_Claro_D_1=Limpiar(Piso_Claro_D_1)
Piso_Claro_D_1=assign_3G_or_4G(Piso_Claro_D_1)
Datos_Finales(Piso_Claro_D_1)

Piso_Claro_D_0=Limpiar(Piso_Claro_D_0)
Piso_Claro_D_0=assign_3G_or_4G(Piso_Claro_D_0)
Datos_Finales(Piso_Claro_D_0)

print("*******************************************************")
print("Edificio D-ICE ")
Piso_Kolbi_D_1=Limpiar(Piso_Kolbi_D_1)
Piso_Kolbi_D_1=assign_3G_or_4G(Piso_Kolbi_D_1)
Datos_Finales(Piso_Kolbi_D_1)

Piso_Kolbi_D_0=Limpiar(Piso_Kolbi_D_0)
Piso_Kolbi_D_0=assign_3G_or_4G(Piso_Kolbi_D_0)
Datos_Finales(Piso_Kolbi_D_0)

print("*******************************************************")
print("Edificio D-Libery ")
Piso_Liberty_D_1=Limpiar(Piso_Liberty_D_1)
Piso_Liberty_D_1=assign_3G_or_4G(Piso_Liberty_D_1)
Datos_Finales(Piso_Liberty_D_1)

Piso_Liberty_D_0=Limpiar(Piso_Liberty_D_0)
Piso_Liberty_D_0=assign_3G_or_4G(Piso_Liberty_D_0)
Datos_Finales(Piso_Liberty_D_0)
