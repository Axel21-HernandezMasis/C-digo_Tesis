# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import pandas as pd
import glob
import numpy as np
import random
import matplotlib.pyplot as plt

#******************************************************************************************

#Edificio A
#ICE

column_names = pd.Series(['Time', 'Longitude', 'Latitude', 'Operador',"Network" , 'NetworkTech', 'Level', "Speed"])

Piso_Cuatro_ICE = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_ICE\Edificio_A4\ICE_2023.11.04_13.40.07\ICE_2023.11.04_13.40.07.txt", sep=';', decimal=',') 
#print(df.info())
Piso_Tres_ICE = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_ICE\Edificio_A3\ICE_2023.11.04_13.43.10\ICE_2023.11.04_13.43.10.txt", sep=';', decimal=',')

Piso_Dos_ICE = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_ICE\Edificio_A2\ICE_2023.11.04_13.46.26\ICE_2023.11.04_13.46.26.txt", sep=';', decimal=',') 

Piso_Uno_ICE = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_ICE\Edificio_A1\ICE_2023.11.04_13.37.40\ICE_2023.11.04_13.37.40.txt", sep=';', decimal=',')  

#Claro

Piso_Cuatro_CLARO = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_A4\Claro_2023.11.04_15.40.59\Claro_2023.11.04_15.40.59.txt", sep=';', decimal=',') 

Piso_Tres_CLARO = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_A3\Claro_2023.11.04_15.43.18\Claro_2023.11.04_15.43.18.txt", sep=';', decimal=',') 

Piso_Dos_CLARO = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_A2\Claro_2023.11.04_15.45.25\Claro_2023.11.04_15.45.25.txt", sep=';', decimal=',') 

Piso_Uno_CLARO = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_A1\Claro_2023.11.04_15.47.30\Claro_2023.11.04_15.47.30.txt", sep=';', decimal=',') 


#Liberty

Piso_Cuatro_Liberty = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Liberty\Edificio_A4\LIBERTY_2023.11.04_13.39.58\LIBERTY_2023.11.04_13.39.58.txt", sep=';', decimal=',') 
Piso_Tres_Liberty = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Liberty\Edificio_A3\LIBERTY_2023.11.04_13.43.12\LIBERTY_2023.11.04_13.43.12.txt", sep=';', decimal=',') 
Piso_Dos_Liberty = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Liberty\Edificio_A2\LIBERTY_2023.11.04_13.46.23\LIBERTY_2023.11.04_13.46.23.txt", sep=';', decimal=',') 
Piso_Uno_Liberty = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Liberty\Edificio_A1\LIBERTY_2023.11.04_13.37.33\LIBERTY_2023.11.04_13.37.33.txt", sep=';', decimal=',') 

#******************************************************************************************

#Edificio B/C

Piso_Claro_B = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_B\Claro_2023.11.04_15.56.11\Claro_2023.11.04_15.56.11.txt", sep=';', decimal=',')

Piso_Kolbi_B_C = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_ICE\Edificio_B_C\ICE_2023.11.04_13.21.18\ICE_2023.11.04_13.21.18.txt", sep=';', decimal=',')
Piso_Liberty_B_C = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Liberty\Edificio_B_C\LIBERTY_2023.11.04_13.21.14\LIBERTY_2023.11.04_13.21.14.txt", sep=';', decimal=',')


#******************************************************************************************
#Edificio C
Piso_Claro_C = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_C\Claro_2023.11.04_15.53.27\Claro_2023.11.04_15.53.27.txt", sep=';', decimal=',')


#******************************************************************************************
#Edificio D


#Piso D0 E0
Piso_Claro_D_0_E_0 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_D0_E0\Claro_2023.11.04_15.09.24\Claro_2023.11.04_15.09.24.txt", sep=';', decimal=',')

#Piso 1
Piso_Claro_D_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_D1\Claro_2023.11.04_15.49.54\Claro_2023.11.04_15.49.54.txt", sep=';', decimal=',')
#Piso 2
Piso_Claro_D_2 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_D2\Claro_2023.11.04_15.22.44\Claro_2023.11.04_15.22.44.txt", sep=';', decimal=',')
#Piso 3
Piso_Claro_D_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_D3\Claro_2023.11.04_15.28.50\Claro_2023.11.04_15.28.50.txt", sep=';', decimal=',')
#Piso 4
Piso_Claro_D_4 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_D4\Claro_2023.11.04_15.37.59\Claro_2023.11.04_15.37.59.txt", sep=';', decimal=',')



#Piso D0 E0
Piso_Kolbi_D_0_E_0 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_ICE\Edificio_EO_D0\ICE_2023.11.04_13.00.29\ICE_2023.11.04_13.00.29.txt", sep=';', decimal=',')
#Piso 1
Piso_Kolbi_D_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_ICE\Edificio_D1\ICE_2023.11.04_13.13.35\ICE_2023.11.04_13.13.35.txt", sep=';', decimal=',')
#Piso 2
Piso_Kolbi_D_2 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_ICE\Edificio_D2\ICE_2023.11.04_14.54.36\ICE_2023.11.04_14.54.36.txt", sep=';', decimal=',')
#Piso 3
Piso_Kolbi_D_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_ICE\Edificio_D3\ICE_2023.11.04_14.47.39\ICE_2023.11.04_14.47.39.txt", sep=';', decimal=',')
#Piso 4
Piso_Kolbi_D_4 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_ICE\Edificio_D4\ICE_2023.11.04_14.39.07\ICE_2023.11.04_14.39.07.txt", sep=';', decimal=',')




Piso_Liberty_D_0_E_0 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Liberty\Edificio_D0_E0\LIBERTY_2023.11.04_13.00.26\LIBERTY_2023.11.04_13.00.26.txt", sep=';', decimal=',')
#Piso 1
Piso_Liberty_D_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Liberty\Edificio_D1\LIBERTY_2023.11.04_13.13.26\LIBERTY_2023.11.04_13.13.26.txt", sep=';', decimal=',')
#Piso 2
Piso_Liberty_D_2 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Liberty\Edificio_D2\LIBERTY_2023.11.04_14.54.42\LIBERTY_2023.11.04_14.54.42.txt", sep=';', decimal=',')
#Piso 3
Piso_Liberty_D_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Liberty\Edificio_D3\LIBERTY_2023.11.04_14.47.32\LIBERTY_2023.11.04_14.47.32.txt", sep=';', decimal=',')
#Piso 4
Piso_Liberty_D_4 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Liberty\Edificio_D4\LIBERTY_2023.11.04_14.39.01\LIBERTY_2023.11.04_14.39.01.txt", sep=';', decimal=',')

#Edificio E

#Piso 1
Piso_Claro_E_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_E1\Claro_2023.11.04_15.15.14\Claro_2023.11.04_15.15.14.txt", sep=';', decimal=',')
#Piso 2
Piso_Claro_E_2 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_E2\Claro_2023.11.04_15.19.24\Claro_2023.11.04_15.19.24.txt", sep=';', decimal=',')
#Piso 3
Piso_Claro_E_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_E3\Claro_2023.11.04_15.25.34\Claro_2023.11.04_15.25.34.txt", sep=';', decimal=',')
#Piso 4
Piso_Claro_E_4 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_E4\Claro_2023.11.04_15.31.52\Claro_2023.11.04_15.31.52.txt", sep=';', decimal=',')
#Piso 5
Piso_Claro_E_5 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_E5\Claro_2023.11.04_15.34.27\Claro_2023.11.04_15.34.27.txt", sep=';', decimal=',')

#Piso 1
Piso_Kolbi_E_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_ICE\Edificio_E1\ICE_2023.11.04_13.07.13\ICE_2023.11.04_13.07.13.txt", sep=';', decimal=',')
#Piso 2
Piso_Kolbi_E_2 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_ICE\Edificio_E2\ICE_2023.11.04_14.50.43\ICE_2023.11.04_14.50.43.txt", sep=';', decimal=',')
#Piso 3
Piso_Kolbi_E_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_ICE\Edificio_E3\ICE_2023.11.04_14.43.21\ICE_2023.11.04_14.43.21.txt", sep=';', decimal=',')
#Piso 4
Piso_Kolbi_E_4 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_ICE\Edificio_E4\ICE_2023.11.04_14.35.26\ICE_2023.11.04_14.35.26.txt", sep=';', decimal=',')
#Piso 5
Piso_Kolbi_E_5 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_ICE\Edificio_E5\ICE_2023.11.04_14.31.44\ICE_2023.11.04_14.31.44.txt", sep=';', decimal=',')

#Piso 1
Piso_Liberty_E_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Liberty\Edificio_E1\LIBERTY_2023.11.04_13.06.59\LIBERTY_2023.11.04_13.06.59.txt", sep=';', decimal=',')
#Piso 2
Piso_Liberty_E_2 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Liberty\Edificio_E2\LIBERTY_2023.11.04_14.50.34\LIBERTY_2023.11.04_14.50.34.txt", sep=';', decimal=',')
#Piso 3
Piso_Liberty_E_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Liberty\Edificio_E3\LIBERTY_2023.11.04_14.43.14\LIBERTY_2023.11.04_14.43.14.txt", sep=';', decimal=',')
#Piso 4
Piso_Liberty_E_4 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Liberty\Edificio_E4\LIBERTY_2023.11.04_14.35.19\LIBERTY_2023.11.04_14.35.19.txt", sep=';', decimal=',')
#Piso 5
Piso_Liberty_E_5 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Liberty\Edificio_E5\LIBERTY_2023.11.04_14.31.37\LIBERTY_2023.11.04_14.31.37.txt", sep=';', decimal=',')






#Funciones
def Limpiar(marks):
    b=[]
    m=len(marks.index)
    for j in range(m):
        Filaaux=marks.iloc[j,0]
        Filaaux=Filaaux.split()
        b.append(Filaaux)
    Datos=pd.DataFrame(b,columns=column_names)
    Datos.loc[Datos["Network"] == "4G", "Red_G"] = 4

    Datos.loc[Datos["Network"] == "3G", "Red_G"] = 3

    Datos.drop(Datos[(Datos['Red_G']==3)].index, inplace =True) #Elimina el 3G
    Datos.drop(['Time', 'Longitude', 'Latitude','Network','Level' ], axis=1, inplace=True)
    Datos["NetworkTech"]=Datos["NetworkTech"].astype(float)
    Datos["Speed"]=Datos["Speed"].astype(float)
    
    return Datos

def assign_Result_4G(marks):
    
    if marks <= -60 and marks >= -95 :
        result = "Excelente"    
    elif marks <= -90 and marks >= -105 :
        result = "Buena" 
    elif marks <= -106 and marks >= -110 :
        result = "Justa"  
    elif  marks <= -111 and marks >= -119 :
        result = "Mala"
    elif marks <= -120 :
        result = "Muera"  

    else:
        result = "Error"
    return result

def assign_Result_3G(marks):
    
    if marks <= -60.0 and marks >= -85.0 :
        result = "Buena" 
    elif marks <= -86.0 and marks >= -100.0 :
        result = "Justa"  
    elif  marks <= -101.0 and marks >= -109.0 :
        result = "Mala" 
        
   
    elif marks <= -110.0 :
        result = "Muera" 
        
  
    else:
        result = "Error"
    return result

def assign_3G_or_4G(marks):
    for i in range(len(marks)):
        if marks.iloc[i]['Red_G']==4.0:
            marks["Calidad_4G"] = marks["NetworkTech"].apply(assign_Result_4G)
            
        elif marks.iloc[i]['Red_G']==3.0:
            marks["Calidad_3G"] = marks["NetworkTech"].apply(assign_Result_3G)
            
             
    return marks

def Mala_cobertura(marks):
    x=0 
    for i in range(len(marks["Calidad_4G"])):
        if marks.iloc[i]["Calidad_4G"]=="Mala":
            x=x+1
        if marks.iloc[i]["Calidad_4G"]=="Muerta":
            x=x+1
    print(""""Se encontraron los siguientes problemas de cobertura:""",x,"""
          respecto a las siguientes mediciones:""",len(marks["Calidad_4G"]))
        

        
def Datos_Finales(marks):
 #   display(marks)
    Varianza=marks["NetworkTech"].var(ddof=0)
    Desviacion_Estandar=marks["NetworkTech"].std()
    Promedio_Cobertura=marks["NetworkTech"].mean()
    Promedio_Velocidad=marks["Speed"].mean()
    print("La varianza de la cobertura es:",Varianza)#La variación de parametro
    print("La Desviacion estandar es:",Desviacion_Estandar)#Cuanto se desvian los parametros entre sí
    print("El promedio de cobertura es",Promedio_Cobertura)#Promedio de la señal
    print("El promedio de ancho de banda",Promedio_Velocidad,"kbps")#Promedio de la señal
    Mala_cobertura(marks)
    # marks["NetworkTech"].plot()
    
#********************************************************************************

    

print("*******************************************************")
print("Edificio A-Claro")
#Pisol
Piso_Uno_CLARO=Limpiar(Piso_Uno_CLARO)
Piso_Uno_CLARO=assign_3G_or_4G(Piso_Uno_CLARO)
Datos_Finales(Piso_Uno_CLARO)


print("*******************************************************")
print("Edificio A_2-Claro")
#Piso2
Piso_Dos_CLARO=Limpiar(Piso_Dos_CLARO)
Piso_Dos_CLARO=assign_3G_or_4G(Piso_Dos_CLARO)
Datos_Finales(Piso_Dos_CLARO)

print("*******************************************************")
print("Edificio A_3-Claro")
#Piso3
Piso_Tres_CLARO=Limpiar(Piso_Tres_CLARO)
Piso_Tres_CLARO=assign_3G_or_4G(Piso_Tres_CLARO)
Datos_Finales(Piso_Tres_CLARO)

print("*******************************************************")
print("Edificio A_4-Claro")
#Piso4
Piso_Cuatro_CLARO=Limpiar(Piso_Cuatro_CLARO)
Piso_Cuatro_CLARO=assign_3G_or_4G(Piso_Cuatro_CLARO)
Datos_Finales(Piso_Cuatro_CLARO)

#********************************************************************************
print("*******************************************************")
print("Edificio A_1-ICE ")

Piso_Uno_ICE=Limpiar(Piso_Uno_ICE)
Piso_Uno_ICE=assign_3G_or_4G(Piso_Uno_ICE)
Datos_Finales(Piso_Uno_ICE)

print("*******************************************************")
print("Edificio A_2-ICE ")
#Piso2
Piso_Dos_ICE=Limpiar(Piso_Dos_ICE)
Piso_Dos_ICE=assign_3G_or_4G(Piso_Dos_ICE)
Datos_Finales(Piso_Dos_ICE)

print("*******************************************************")
print("Edificio A_3-ICE ")
#Piso3
Piso_Tres_ICE=Limpiar(Piso_Tres_ICE)
Piso_Tres_ICE=assign_3G_or_4G(Piso_Tres_ICE)
Datos_Finales(Piso_Tres_ICE)

print("*******************************************************")
print("Edificio A_4-ICE ")
#Piso4
Piso_Cuatro_ICE=Limpiar(Piso_Cuatro_ICE)
Piso_Cuatro_ICE=assign_3G_or_4G(Piso_Cuatro_ICE)
Datos_Finales(Piso_Cuatro_ICE)

print("*******************************************************")
print("Edificio A_1-Liberty ")

Piso_Uno_Liberty=Limpiar(Piso_Uno_Liberty)
Piso_Uno_LibertyE=assign_3G_or_4G(Piso_Uno_Liberty)
Datos_Finales(Piso_Uno_Liberty)


print("*******************************************************")
print("Edificio A_2-Liberty ")
#Piso2
Piso_Dos_Liberty=Limpiar(Piso_Dos_Liberty)
Piso_Dos_Liberty=assign_3G_or_4G(Piso_Dos_Liberty)
Datos_Finales(Piso_Dos_Liberty)


print("*******************************************************")
print("Edificio A_3-Liberty ")
#Piso3
Piso_Tres_Liberty=Limpiar(Piso_Tres_Liberty)
Piso_Tres_Liberty=assign_3G_or_4G(Piso_Tres_Liberty)
Datos_Finales(Piso_Tres_Liberty)


print("*******************************************************")
print("Edificio A_4-Liberty ")
#Piso4
Piso_Cuatro_Liberty=Limpiar(Piso_Cuatro_Liberty)
Piso_Cuatro_Liberty=assign_3G_or_4G(Piso_Cuatro_Liberty)
Datos_Finales(Piso_Cuatro_Liberty)

print("*******************************************************")
print("Edificio B/C-Claro ")

Piso_Claro_B=Limpiar(Piso_Claro_B)
Piso_Claro_B=assign_3G_or_4G(Piso_Claro_B)
Datos_Finales(Piso_Claro_B)

print("*******************************************************")
print("Edificio B/C-Kolbi ")
Piso_Kolbi_B_C=Limpiar(Piso_Kolbi_B_C)
Piso_Kolbi_B_C=assign_3G_or_4G(Piso_Kolbi_B_C)
Datos_Finales(Piso_Kolbi_B_C)

print("*******************************************************")
print("Edificio B/C-Liberty ")
Piso_Liberty_B_C=Limpiar(Piso_Liberty_B_C)
Piso_Liberty_B_C=assign_3G_or_4G(Piso_Liberty_B_C)
Datos_Finales(Piso_Liberty_B_C)


print("*******************************************************")
print("Edificio C-Claro ")

Piso_Claro_C=Limpiar(Piso_Claro_C)
Piso_Claro_C=assign_3G_or_4G(Piso_Claro_C)
Datos_Finales(Piso_Claro_C)

print("*******************************************************")


print("*******************************************************")
print("Edificio D_0/E_0-Claro ")

Piso_Claro_D_0_E_0=Limpiar(Piso_Claro_D_0_E_0)
Piso_Claro_D_0_E0=assign_3G_or_4G(Piso_Claro_D_0_E_0)
Datos_Finales(Piso_Claro_D_0_E0)

print("*******************************************************")
print("Edificio D_1-Claro ")
Piso_Claro_D_1=Limpiar(Piso_Claro_D_1)
Piso_Claro_D_1=assign_3G_or_4G(Piso_Claro_D_1)
Datos_Finales(Piso_Claro_D_1)

print("*******************************************************")
print("Edificio D_2-Claro ")
Piso_Claro_D_2=Limpiar(Piso_Claro_D_2)
Piso_Claro_D_2=assign_3G_or_4G(Piso_Claro_D_2)
Datos_Finales(Piso_Claro_D_2)

print("*******************************************************")
print("Edificio D_3-Claro ")
Piso_Claro_D_3=Limpiar(Piso_Claro_D_3)
Piso_Claro_D_3=assign_3G_or_4G(Piso_Claro_D_3)
Datos_Finales(Piso_Claro_D_3)

print("*******************************************************")
print("Edificio D_4-Claro ")
Piso_Claro_D_4=Limpiar(Piso_Claro_D_4)
Piso_Claro_D_4=assign_3G_or_4G(Piso_Claro_D_4)
Datos_Finales(Piso_Claro_D_4)



print("*******************************************************")
print("Edificio D_0/E_0-ICE ")
Piso_Kolbi_D_0_E_0=Limpiar(Piso_Kolbi_D_0_E_0)
Piso_Kolbi_D_0_E_0=assign_3G_or_4G(Piso_Kolbi_D_0_E_0)
Datos_Finales(Piso_Kolbi_D_0_E_0)


print("*******************************************************")
print("Edificio D_1-ICE ")
Piso_Kolbi_D_1=Limpiar(Piso_Kolbi_D_1)
Piso_Kolbi_D_1=assign_3G_or_4G(Piso_Kolbi_D_1)
Datos_Finales(Piso_Kolbi_D_1)

print("*******************************************************")
print("Edificio D_2-ICE ")
Piso_Kolbi_D_2=Limpiar(Piso_Kolbi_D_2)
Piso_Kolbi_D_2=assign_3G_or_4G(Piso_Kolbi_D_2)
Datos_Finales(Piso_Kolbi_D_2)

print("*******************************************************")
print("Edificio D_3-ICE ")
Piso_Kolbi_D_3=Limpiar(Piso_Kolbi_D_3)
Piso_Kolbi_D_3=assign_3G_or_4G(Piso_Kolbi_D_3)
Datos_Finales(Piso_Kolbi_D_3)

print("*******************************************************")
print("Edificio D_4-ICE ")
Piso_Kolbi_D_4=Limpiar(Piso_Kolbi_D_4)
Piso_Kolbi_D_4=assign_3G_or_4G(Piso_Kolbi_D_4)
Datos_Finales(Piso_Kolbi_D_4)


print("*******************************************************")
print("Edificio D_0/E_0-Libery ")


Piso_Liberty_D_0_E_0=Limpiar(Piso_Liberty_D_0_E_0)
Piso_Liberty_D_0_E_0=assign_3G_or_4G(Piso_Liberty_D_0_E_0)
Datos_Finales(Piso_Liberty_D_0_E_0)
print("*******************************************************")
print("Edificio D_1-Libery ")


Piso_Liberty_D_1=Limpiar(Piso_Liberty_D_1)
Piso_Liberty_D_1=assign_3G_or_4G(Piso_Liberty_D_1)
Datos_Finales(Piso_Liberty_D_1)

print("*******************************************************")
print("Edificio D_2-Libery ")
Piso_Liberty_D_2=Limpiar(Piso_Liberty_D_2)
Piso_Liberty_D_2=assign_3G_or_4G(Piso_Liberty_D_2)
Datos_Finales(Piso_Liberty_D_2)

print("*******************************************************")
print("Edificio D_3-Libery ")
Piso_Liberty_D_3=Limpiar(Piso_Liberty_D_3)
Piso_Liberty_D_3=assign_3G_or_4G(Piso_Liberty_D_3)
Datos_Finales(Piso_Liberty_D_3)

print("*******************************************************")
print("Edificio D_4-Libery ")
Piso_Liberty_D_4=Limpiar(Piso_Liberty_D_4)
Piso_Liberty_D_4=assign_3G_or_4G(Piso_Liberty_D_4)
Datos_Finales(Piso_Liberty_D_4)

print("*******************************************************")
print("Edificio E_1-Claro ")


Piso_Claro_E_1=Limpiar(Piso_Claro_E_1)
Piso_Claro_E_1=assign_3G_or_4G(Piso_Claro_E_1)
Datos_Finales(Piso_Claro_E_1)

print("*******************************************************")
print("Edificio E_2-Claro ")

Piso_Claro_E_2=Limpiar(Piso_Claro_E_2)
Piso_Claro_E_2=assign_3G_or_4G(Piso_Claro_E_2)
Datos_Finales(Piso_Claro_E_2)

print("*******************************************************")
print("Edificio E_3-Claro ")

Piso_Claro_E_3=Limpiar(Piso_Claro_E_3)
Piso_Claro_E_3=assign_3G_or_4G(Piso_Claro_E_3)
Datos_Finales(Piso_Claro_E_3)

print("*******************************************************")
print("Edificio E_4-Claro ")

Piso_Claro_E_4=Limpiar(Piso_Claro_E_4)
Piso_Claro_E_4=assign_3G_or_4G(Piso_Claro_E_4)
Datos_Finales(Piso_Claro_E_4)

print("*******************************************************")
print("Edificio E_5-Claro ")

Piso_Claro_E_5=Limpiar(Piso_Claro_E_5)
Piso_Claro_E_5=assign_3G_or_4G(Piso_Claro_E_5)
Datos_Finales(Piso_Claro_E_5)

print("*******************************************************")
print("Edificio E_1-ICE ")

Piso_Kolbi_E_1=Limpiar(Piso_Kolbi_E_1)
Piso_Kolbi_E_1=assign_3G_or_4G(Piso_Kolbi_E_1)
Datos_Finales(Piso_Kolbi_E_1)
print("*******************************************************")
print("Edificio E_2-ICE ")
Piso_Kolbi_E_2=Limpiar(Piso_Kolbi_E_2)
Piso_Kolbi_E_2=assign_3G_or_4G(Piso_Kolbi_E_2)
Datos_Finales(Piso_Kolbi_E_2)

print("*******************************************************")
print("Edificio E_3-ICE ")
Piso_Kolbi_E_3=Limpiar(Piso_Kolbi_E_3)
Piso_Kolbi_E_3=assign_3G_or_4G(Piso_Kolbi_E_3)
Datos_Finales(Piso_Kolbi_E_3)

print("*******************************************************")
print("Edificio E_4-ICE ")
Piso_Kolbi_E_4=Limpiar(Piso_Kolbi_E_4)
Piso_Kolbi_E_4=assign_3G_or_4G(Piso_Kolbi_E_4)
Datos_Finales(Piso_Kolbi_E_4)

print("*******************************************************")
print("Edificio E_5-ICE ")
Piso_Kolbi_E_5=Limpiar(Piso_Kolbi_E_5)
Piso_Kolbi_E_5=assign_3G_or_4G(Piso_Kolbi_E_5)
Datos_Finales(Piso_Kolbi_E_5)

print("*******************************************************")
print("Edificio E_1-Libery ")

Piso_Liberty_E_1=Limpiar(Piso_Liberty_E_1)
Piso_Liberty_E_1=assign_3G_or_4G(Piso_Liberty_E_1)
Datos_Finales(Piso_Liberty_E_1)

print("*******************************************************")
print("Edificio E_2-Libery ")

Piso_Liberty_E_2=Limpiar(Piso_Liberty_E_2)
Piso_Kolbi_E_2=assign_3G_or_4G(Piso_Liberty_E_2)
Datos_Finales(Piso_Liberty_E_2)

print("*******************************************************")
print("Edificio E_3-Libery ")

Piso_Liberty_E_3=Limpiar(Piso_Liberty_E_3)
Piso_Liberty_E_3=assign_3G_or_4G(Piso_Liberty_E_3)
Datos_Finales(Piso_Liberty_E_3)

print("*******************************************************")
print("Edificio E_4-Libery ")

Piso_Liberty_E_4=Limpiar(Piso_Liberty_E_4)
Piso_Liberty_E_4=assign_3G_or_4G(Piso_Liberty_E_4)
Datos_Finales(Piso_Liberty_E_4)

print("*******************************************************")
print("Edificio E_5-Libery ")

Piso_Liberty_E_5=Limpiar(Piso_Liberty_E_5)
Piso_Liberty_E_5=assign_3G_or_4G(Piso_Liberty_E_5)
Datos_Finales(Piso_Liberty_E_5)
