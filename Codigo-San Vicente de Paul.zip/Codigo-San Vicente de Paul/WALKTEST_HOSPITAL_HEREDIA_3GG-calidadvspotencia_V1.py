# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import pandas as pd
import glob
import numpy as np
import random
import matplotlib.pyplot as plt



    
    
#******************************************************************************************
pd.options.display.max_rows = 9999
#Edificio A
#ICE

column_names = pd.Series(['Time', 'Longitude', 'Latitude', 'Operador',"Network" , 'NetworkTech', 'Level', "Speed"])


Piso_Cuatro_ICE = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_3G_ICE\Edificio_A4\ICE_2023.11.04_15.41.10\ICE_2023.11.04_15.41.10.txt", sep=';', decimal=',') 
Piso_Cuatro_ICE.fillna(0, inplace = True)

Piso_Tres_ICE = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_3G_ICE\Edificio_A3\ICE_2023.11.04_15.43.25\ICE_2023.11.04_15.43.25.txt", sep=';', decimal=',')
Piso_Tres_ICE.fillna(0, inplace = True)

Piso_Dos_ICE = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_3G_ICE\Edificio_A2\ICE_2023.11.04_15.45.21\ICE_2023.11.04_15.45.21.txt", sep=';', decimal=',') 
Piso_Dos_ICE.fillna(0, inplace = True)

Piso_Uno_ICE = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_3G_ICE\Edificio_A1\ICE_2023.11.04_15.47.25\ICE_2023.11.04_15.47.25.txt", sep=';', decimal=',')  
Piso_Uno_ICE.fillna(0, inplace = True)

#Claro

Piso_Cuatro_CLARO = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_3_3G_Claro\Edificio_A4\Claro_2024.02.01_10.59.58\Claro_2024.02.01_10.59.58.txt", sep=';', decimal=',') 
Piso_Cuatro_CLARO.fillna(0, inplace = True)

Piso_Tres_CLARO = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_3_3G_Claro\Edificio_A3\Claro_2024.02.01_10.55.21\Claro_2024.02.01_10.55.21.txt", sep=';', decimal=',') 
Piso_Tres_CLARO.fillna(0, inplace = True)

Piso_Dos_CLARO = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_3_3G_Claro\Edificio_A2\Claro_2024.02.01_10.52.11\Claro_2024.02.01_10.52.11.txt", sep=';', decimal=',') 
Piso_Dos_CLARO.fillna(0, inplace = True)

Piso_Uno_CLARO = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_3_3G_Claro\Edificio_A1\Claro_2024.02.01_10.48.51\Claro_2024.02.01_10.48.51.txt", sep=';', decimal=',') 
Piso_Uno_CLARO.fillna(0, inplace = True)

#Liberty

Piso_Cuatro_Liberty = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_3_3G_Liberty\Edificio_A4\71204_2024.02.01_10.59.54\71204_2024.02.01_10.59.54.txt", sep=';', decimal=',') 
Piso_Cuatro_Liberty.fillna(0, inplace = True)

Piso_Tres_Liberty = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_3_3G_Liberty\Edificio_A3\71204_2024.02.01_10.56.56\71204_2024.02.01_10.56.56.txt", sep=';', decimal=',') 
Piso_Tres_Liberty.fillna(0, inplace = True)

Piso_Dos_Liberty = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_3_3G_Liberty\Edificio_A2\71204_2024.02.01_10.53.14\71204_2024.02.01_10.53.14.txt", sep=';', decimal=',') 
Piso_Dos_Liberty.fillna(0, inplace = True)

Piso_Uno_Liberty = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_3_3G_Liberty\Edificio_A1\71204_2024.02.01_10.48.46\71204_2024.02.01_10.48.46.txt", sep=';', decimal=',') 
Piso_Uno_Liberty.fillna(0, inplace = True)
#******************************************************************************************

#Edificio B/C

Piso_Claro_B_C = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_3_3G_Claro\Edificio_B_C\Claro_2024.02.01_11.48.38\Claro_2024.02.01_11.48.38.txt", sep=';', decimal=',')
Piso_Claro_B_C.fillna(0, inplace = True)


Piso_Liberty_B_C = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_3_3G_Liberty\Edificio_B_C\71204_2024.02.01_11.48.35\71204_2024.02.01_11.48.35.txt", sep=';', decimal=',')
Piso_Liberty_B_C.fillna(0, inplace = True)

Piso_Kolbi_B_C = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_3G_ICE\Edificio_B\ICE_2023.11.04_15.56.06\ICE_2023.11.04_15.56.06.txt", sep=';', decimal=',')
Piso_Kolbi_B_C.fillna(0, inplace = True)
 

#******************************************************************************************
#Edificio D


#Piso D0 E0
Piso_Claro_D_0_E_0 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_3_3G_Claro\Edificio_D0_E0\Claro_2024.02.01_11.57.52\Claro_2024.02.01_11.57.52.txt", sep=';', decimal=',')
Piso_Claro_D_0_E_0.fillna(0, inplace = True)

#Piso 1
Piso_Claro_D_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_3_3G_Claro\Edificio_D1\Claro_2024.02.01_11.45.04\Claro_2024.02.01_11.45.04.txt", sep=';', decimal=',')
Piso_Claro_D_1.fillna(0, inplace = True)

#Piso 2
Piso_Claro_D_2 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_3_3G_Claro\Edificio_D2\Claro_2024.02.01_11.31.45\Claro_2024.02.01_11.31.45.txt", sep=';', decimal=',')
Piso_Claro_D_2.fillna(0, inplace = True)

#Piso 3
Piso_Claro_D_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_3_3G_Claro\Edificio_D3\Claro_2024.02.01_11.25.25\Claro_2024.02.01_11.25.25.txt", sep=';', decimal=',')
Piso_Claro_D_3.fillna(0, inplace = True)

#Piso 4
Piso_Claro_D_4 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_3_3G_Claro\Edificio_D4\Claro_2024.02.01_11.02.26\Claro_2024.02.01_11.02.26.txt", sep=';', decimal=',')
Piso_Claro_D_4.fillna(0, inplace = True)


#Piso D0 E0
Piso_Kolbi_D_0_E_0 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_3G_ICE\Edificio_D0_E0\ICE_2023.11.04_15.09.18\ICE_2023.11.04_15.09.18.txt", sep=';', decimal=',')
Piso_Kolbi_D_0_E_0.fillna(0, inplace = True)

#Piso 1
Piso_Kolbi_D_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_3G_ICE\Edificio_D1\ICE_2023.11.04_15.50.03\ICE_2023.11.04_15.50.03.txt", sep=';', decimal=',')
Piso_Kolbi_D_1.fillna(0, inplace = True)

#Piso 2
Piso_Kolbi_D_2 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_3G_ICE\Edificio_D2\ICE_2023.11.04_15.22.46\ICE_2023.11.04_15.22.46.txt", sep=';', decimal=',')
Piso_Kolbi_D_2.fillna(0, inplace = True)

#Piso 3
Piso_Kolbi_D_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_3G_ICE\Edificio_D3\ICE_2023.11.04_15.28.44\ICE_2023.11.04_15.28.44.txt", sep=';', decimal=',')
Piso_Kolbi_D_3.fillna(0, inplace = True)

#Piso 4
Piso_Kolbi_D_4 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_3G_ICE\Edificio_D4\ICE_2023.11.04_15.38.09\ICE_2023.11.04_15.38.09.txt", sep=';', decimal=',')
Piso_Kolbi_D_4.fillna(0, inplace = True)



Piso_Liberty_D_0_E_0 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_3_3G_Liberty\Edificio_D0_E0\71204_2024.02.01_11.57.48\71204_2024.02.01_11.57.48.txt", sep=';', decimal=',')
Piso_Liberty_D_0_E_0.fillna(0, inplace = True)

#Piso 1
Piso_Liberty_D_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_3_3G_Liberty\Edificio_D1\71204_2024.02.01_11.45.00\71204_2024.02.01_11.45.00.txt", sep=';', decimal=',')
Piso_Liberty_D_1.fillna(0, inplace = True)

#Piso 2
Piso_Liberty_D_2 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_3_3G_Liberty\Edificio_D2\71204_2024.02.01_11.31.37\71204_2024.02.01_11.31.37.txt", sep=';', decimal=',')
Piso_Liberty_D_2.fillna(0, inplace = True)

#Piso 3
Piso_Liberty_D_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_3_3G_Liberty\Edificio_D3\71204_2024.02.01_11.25.22\71204_2024.02.01_11.25.22.txt", sep=';', decimal=',')
Piso_Liberty_D_3.fillna(0, inplace = True)

#Piso 4
Piso_Liberty_D_4 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_3_3G_Liberty\Edificio_D4\71204_2024.02.01_11.02.22\71204_2024.02.01_11.02.22.txt", sep=';', decimal=',')
Piso_Liberty_D_4.fillna(0, inplace = True)
#Edificio E

#Piso 1
Piso_Claro_E_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_3_3G_Claro\Edificio_E1\Claro_2024.02.01_11.35.54\Claro_2024.02.01_11.35.54.txt", sep=';', decimal=',')
Piso_Claro_E_1.fillna(0, inplace = True)

#Piso 2
Piso_Claro_E_2 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_3_3G_Claro\Edificio_E2\Claro_2024.02.01_11.28.47\Claro_2024.02.01_11.28.47.txt", sep=';', decimal=',')
Piso_Claro_E_2.fillna(0, inplace = True)

#Piso 3
Piso_Claro_E_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_3_3G_Claro\Edificio_E3\Claro_2024.02.01_11.13.59\Claro_2024.02.01_11.13.59.txt", sep=';', decimal=',')
Piso_Claro_E_3.fillna(0, inplace = True)

#Piso 4
Piso_Claro_E_4 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_3_3G_Claro\Edificio_E4\Claro_2024.02.01_11.06.07\Claro_2024.02.01_11.06.07.txt", sep=';', decimal=',')
Piso_Claro_E_4.fillna(0, inplace = True)

#Piso 5
Piso_Claro_E_5 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_3_3G_Claro\Edificio_E5\Claro_2024.02.01_11.10.08\Claro_2024.02.01_11.10.08.txt", sep=';', decimal=',')
Piso_Claro_E_5.fillna(0, inplace = True)

#Piso 1
Piso_Kolbi_E_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_3G_ICE\Edificio_E1\ICE_2023.11.04_15.15.21\ICE_2023.11.04_15.15.21.txt", sep=';', decimal=',')
Piso_Kolbi_E_1.fillna(0, inplace = True)

#Piso 2
Piso_Kolbi_E_2 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_3G_ICE\Edificio_E2\ICE_2023.11.04_15.19.31\ICE_2023.11.04_15.19.31.txt", sep=';', decimal=',')
Piso_Kolbi_E_2.fillna(0, inplace = True)

#Piso 3
Piso_Kolbi_E_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_3G_ICE\Edificio_E3\ICE_2023.11.04_15.25.37\ICE_2023.11.04_15.25.37.txt", sep=';', decimal=',')
Piso_Kolbi_E_3.fillna(0, inplace = True)

#Piso 4
Piso_Kolbi_E_4 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_3G_ICE\Edificio_E4\ICE_2023.11.04_15.32.00\ICE_2023.11.04_15.32.00.txt", sep=';', decimal=',')
Piso_Kolbi_E_4.fillna(0, inplace = True)

#Piso 5
Piso_Kolbi_E_5 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_3G_ICE\Edificio_E5\ICE_2023.11.04_15.34.35\ICE_2023.11.04_15.34.35.txt", sep=';', decimal=',')
Piso_Kolbi_E_5.fillna(0, inplace = True)

#Piso 1
Piso_Liberty_E_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_3_3G_Liberty\Edificio_E1\71204_2024.02.01_11.35.50\71204_2024.02.01_11.35.50.txt", sep=';', decimal=',')
Piso_Liberty_E_1.fillna(0, inplace = True)

#Piso 2
Piso_Liberty_E_2 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_3_3G_Liberty\Edificio_E2\71204_2024.02.01_11.28.44\71204_2024.02.01_11.28.44.txt", sep=';', decimal=',')
Piso_Liberty_E_2.fillna(0, inplace = True)

#Piso 3
Piso_Liberty_E_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_3_3G_Liberty\Edificio_E3\71204_2024.02.01_11.13.54\71204_2024.02.01_11.13.54.txt", sep=';', decimal=',')
Piso_Liberty_E_3.fillna(0, inplace = True)

#Piso 4
Piso_Liberty_E_4 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_3_3G_Liberty\Edificio_E4\71204_2024.02.01_11.06.02\71204_2024.02.01_11.06.02.txt", sep=';', decimal=',')
Piso_Liberty_E_4.fillna(0, inplace = True)

#Piso 5
Piso_Liberty_E_5 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_3_3G_Liberty\Edificio_E5\71204_2024.02.01_11.10.04\71204_2024.02.01_11.10.04.txt", sep=';', decimal=',')
Piso_Liberty_E_5.fillna(0, inplace = True)

#Piso F

Piso_Liberty_F = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_3_3G_Liberty\Edificio_F\71204_2024.02.01_12.20.07\71204_2024.02.01_12.20.07.txt", sep=';', decimal=',')
Piso_Liberty_F.fillna(0, inplace = True)

Piso_Kolbi_F = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_3G_ICE\Edificio_F\ICE_2023.11.04_15.04.53\ICE_2023.11.04_15.04.53.txt", sep=';', decimal=',')
Piso_Kolbi_F.fillna(0, inplace = True)

Piso_Claro_F = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_3_3G_Claro\Edificio_F\Claro_2024.02.01_12.20.12\Claro_2024.02.01_12.20.12.txt", sep=';', decimal=',')
Piso_Claro_F.fillna(0, inplace = True)






 

#Funciones


def Limpiar(marks):
    b=[]
    m=len(marks.index)
    for j in range(m):
        Filaaux=marks.iloc[j,0]
        Filaaux=Filaaux.split()
        b.append(Filaaux)
    Datos=pd.DataFrame(b,columns=column_names)
    Datos.loc[Datos["Network"] == "4G", "Red_G"] = 4

    Datos.loc[Datos["Network"] == "3G", "Red_G"] = 3

    Datos.drop(Datos[(Datos['Red_G']==4)].index, inplace =True) #Elimina el 4G
    Datos.drop(['Time', 'Longitude', 'Latitude','Network','Level' ], axis=1, inplace=True)
    Datos["NetworkTech"]=Datos["NetworkTech"].astype(float)
    Datos["Speed"]=Datos["Speed"].astype(float)
    
   
    
    return Datos



def assign_Result_4G(marks):
    
    if marks <= -44 and marks >= -80 :
        result = "1-Excelente"
    elif marks <= -80 and marks >= -90 :
        result = "2-Buena" 
    elif marks <= -90 and marks >= -100 :
        result = "3-Justa"  
    elif  marks <= -100 and marks >= -110 :
        result = "4-Mala"
    elif marks <= -111 :
        result = "5-Muerta"  
    else:
        result = "6-Error"
    return result



def assign_Result_3G(marks):
    
    if marks <= -44 and marks >= -60 :
        result = "1-Excelente" 
    elif marks <= -60 and marks >= -75 :
        result = "2-Buena"  
    elif  marks <= -75 and marks >= -85 :
        result = "3-Justa" 
    elif  marks <= -85 and marks >= -95 :
        result = "4-Mala"
    elif marks <= -96 :
        result = "5-Muerta"  
    else:
        result = "6-Error"
    return result
        
  
   

def assign_Umbral_3G(marks):
    
    if marks <= -44 and marks >= -85 :
        result = "1-Dentro_Umbral"
    elif marks <= -86:
        result = "2-Fuera_Umbral" 
     
    else:
        result = "6-Error"
    return result

def assign_3G_or_4G(marks):
    for i in range(len(marks)):
        if marks.iloc[i]['Red_G']==4.0:
            marks["Calidad_4G"] = marks["NetworkTech"].apply(assign_Result_3G) #Esto al final se remueve
            marks["Umbral"] = marks["NetworkTech"].apply(assign_Umbral_3G)
 
           
            
        elif marks.iloc[i]['Red_G']==3.0:
            marks["Calidad_3G"] = marks["NetworkTech"].apply(assign_Result_3G)
            marks["Umbral"] = marks["NetworkTech"].apply(assign_Umbral_3G)
            
    marks=marks.sort_values("Calidad_3G")
    marks.head()        
    return marks

def Mala_cobertura(marks):

    x=0 
    y=0
    z=0 
    a=0 
    b=0 
    
    for i in range(len(marks["Calidad_3G"])):
        if marks.iloc[i]["Calidad_3G"]=="1-Excelente":
            a=a+1
        if marks.iloc[i]["Calidad_3G"]=="2-Buena":
            b=b+1
        if marks.iloc[i]["Calidad_3G"]=="3-Justa":
            x=x+1
        if marks.iloc[i]["Calidad_3G"]=="4-Mala":
            y=y+1
        if marks.iloc[i]["Calidad_3G"]=="5-Muerta":
            z=z+1

        

   # print("Se encontraron :""",a,"""datos de calidad
     #         Excelente respecto a la muestra de datos 
    #          de:""",len(marks["Calidad_4G"]))
 #   print("Se encontraron :""",b,""" datos de calidad 
    #          Buena respecto a la muestra de datos 
     #         de:""",len(marks["Calidad_4G"]))
  #  print("Se encontraron :""",x,""" datos de calidad 
    #          Justa respecto a la muestra de datos 
     #         de:""",len(marks["Calidad_4G"]))
  #  print("Se encontraron :""",y,""" datos de calidad 
     #         Mala respecto a la muestra de datos 
      #        de:""",len(marks["Calidad_4G"]))
  #  print("Se encontraron :""",z,"""datos de calidad 
     #         Muerta respecto a la muestra de datos 
      #        de:""",len(marks["Calidad_4G"]))
             
    return a,b,x,y,z


        
def Datos_Finales(marks):
 #   display(marks)
    Varianza=marks["NetworkTech"].var(ddof=0)
    Desviacion_Estandar=marks["NetworkTech"].std()
    Promedio_Cobertura=marks["NetworkTech"].mean()
#    Promedio_Velocidad=marks["Speed"].mean()
    print("La varianza de la cobertura es:",Varianza)#La variación de parametro
    print("La Desviacion estandar es:",Desviacion_Estandar)#Cuanto se desvian los parametros entre sí
    print("El promedio de cobertura es",Promedio_Cobertura)#Promedio de la señal
#    print("El promedio de ancho de banda",Promedio_Velocidad,"kbps")#Promedio de la señal
    
    
    # marks["NetworkTech"].plot()
    
    

def plt_auxiliar(): 
    plt.plot(["1-Excelente", "1-Excelente"],
         [-50, -115],
         color='black', linestyle='')
    plt.plot(["2-Buena", "2-Buena"],
         [-50, -115],
         color='black', linestyle='')
    plt.plot(["3-Justa", "3-Justa"],
         [-50, -115],
         color='black', linestyle='')
    plt.plot(["4-Mala", "4-Mala"],
         [-50, -115],
         color='black', linestyle='')
    plt.plot(["5-Muerta", "5-Muerta"],
         [-50, -115],
         color='black', linestyle='')

def plt_auxiliar_2():     
    plt.plot(["1-Excelente", "5-Muerta"],
         [-60, -60],
         color='black', linestyle='--')
    plt.plot(["1-Excelente", "5-Muerta"],
         [-75, -75],
         color='black', linestyle='--')
    plt.plot(["1-Excelente", "5-Muerta"],
         [-85, -85],
         color='black', linestyle='--')    
    plt.plot(["1-Excelente", "5-Muerta"],
         [-95, -95],
         color='black', linestyle='--')

def plt_auxiliar_3():
    plt.plot(["1-Excelente", "1-Excelente"],
         [0, 100],color='black', linestyle='')
    
def plt_auxiliar_4():
    plt.plot(["1-Excelente", "1-Excelente"],
         [0, 120],color='black', linestyle='')
    
    
#********************************************************************************#
def Mala_cobertura_Sutel(marks):

    p=0 
    h=0

    
    for i in range(len(marks["Calidad_3G"])):
        if marks.iloc[i]["Umbral"]=="1-Dentro_Umbral":
            p=p+1
        if marks.iloc[i]["Umbral"]=="2-Fuera_Umbral":
            h=h+1

    return p,h
        
        





print("**-----------*Sección de plts*------------**")
 #Seccion Plt
#Piso 1 edificio A
# Crear el gráfico de dispersión

def funcion(marks, marks2, marks3):
    
#********************************************************************************

#Pisol
    marks=Limpiar(marks)
    marks=assign_3G_or_4G(marks)
    
    marks2=Limpiar(marks2)
    marks2=assign_3G_or_4G(marks2)
    
    marks3=Limpiar(marks3)
    marks3=assign_3G_or_4G(marks3)
    
    plt_auxiliar()
    plt_auxiliar_2()
    
    plt.scatter(marks2["Calidad_3G"], marks2["NetworkTech"], color='b', label="Liberty")
    plt.scatter(marks["Calidad_3G"],marks["NetworkTech"], color = 'g',label = "ICE")
    plt.scatter(marks3["Calidad_3G"],marks3["NetworkTech"], color = 'r',label = "Claro")
    plt.legend(loc='upper right')
    plt.title("Edificio")
    plt.show()
    
    plt_auxiliar_3()
    a_1,b_1,x_1,y_1,z_1=Mala_cobertura(marks)
    a_2,b_2,x_2,y_2,z_2=Mala_cobertura(marks2)
    a_3,b_3,x_3,y_3,z_3=Mala_cobertura(marks3)

    total_1 = a_1 + b_1 + x_1 + y_1 + z_1
    total_2 = a_2 + b_2 + x_2 + y_2 + z_2
    total_3 = a_3 + b_3 + x_3 + y_3 + z_3

    calidad_x=np.array(["1-Excelente","2-Buena","3-Justa","4-Mala","5-Muerta"])
    calidad_y=np.array([a_1,b_1,x_1,y_1,z_1])/ total_1 * 100
    calidad_y_2=np.array([a_2,b_2,x_2,y_2,z_2])/ total_2 * 100
    calidad_y_3=np.array([a_3,b_3,x_3,y_3,z_3])/ total_3 * 100
    
    # Ancho de las barras
    bar_width = 0.2

    positions_1 = np.arange(len(calidad_x))
    positions_2 = positions_1 + bar_width + 0.05
    positions_3 = positions_2 + bar_width + 0.05

    # Crear la gráfica
    plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
    plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
    plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')
    
    # Etiquetas y título
    plt.xlabel('Calidad')
    plt.ylabel('Porcentaje')
    plt.title('Comparación de Calidad (Porcentaje Total)')
    plt.xticks(positions_2, calidad_x)

    # Añadir el valor del porcentaje dentro de la barra

    for i, value in enumerate(calidad_y):
        if value>0:
            plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

    for i, value in enumerate(calidad_y_2):
        if value>0:
            plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

    for i, value in enumerate(calidad_y_3):
        if value>0:
            plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

    # Mostrar la gráfica
    plt.show()
    
    plt_auxiliar_4()

    h_1,p_1=Mala_cobertura_Sutel(marks)
    h_2,p_2=Mala_cobertura_Sutel(marks2)
    h_3,p_3=Mala_cobertura_Sutel(marks3)

    total_1 = h_1 + p_1
    total_2 = h_2 + p_2
    total_3 = h_3 + p_3


    calidad_x=np.array(["1-Dentro_Umbral","2-Fuera_Umbral"])
    calidad_y=np.array([h_1,p_1])/ total_1 * 100
    calidad_y_2=np.array([h_2,p_2])/ total_2 * 100
    calidad_y_3=np.array([h_3,p_3])/ total_3 * 100

    # Ancho de las barras
    bar_width = 0.2

    positions_1 = np.arange(len(calidad_x))
    positions_2 = positions_1 + bar_width
    positions_3 = positions_2 + bar_width


    # Crear la gráfica
    plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
    plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
    plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

    # Etiquetas y título
    plt.xlabel('Umbral de cobertura')
    plt.ylabel('Valores')
    plt.title('Comparación de Calidad porcentaje Sutel')
    plt.xticks(positions_2, calidad_x)

    plt.legend()
    # Añadir el valor del porcentaje dentro de la barra

    for i, value in enumerate(calidad_y):
        if value>0:
            plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

    for i, value in enumerate(calidad_y_2):
        if value>0:
            plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

    for i, value in enumerate(calidad_y_3):
        if value>0:
            plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

    # Mostrar la gráfica
    plt.show()
     

    print("Para ICE:")
    Datos_Finales(marks)

    print("Para Liberty:")
    Datos_Finales(marks2)

    print("Para Claro:")
    Datos_Finales(marks3)

    #**********************************************
    
#Main
#Edificio A
print("piso 1-A")
funcion(Piso_Uno_ICE, Piso_Uno_Liberty, Piso_Uno_CLARO)
print("piso 2-A")
funcion(Piso_Dos_ICE, Piso_Dos_Liberty, Piso_Dos_CLARO)
print("piso 3-A")
funcion(Piso_Tres_ICE, Piso_Tres_Liberty, Piso_Tres_CLARO)
print("piso 4-A")
funcion(Piso_Cuatro_ICE, Piso_Cuatro_Liberty, Piso_Cuatro_CLARO) 

#Edificio B y C
print("piso 1-B_C")
funcion(Piso_Kolbi_B_C, Piso_Liberty_B_C, Piso_Claro_B_C) 
 
print("piso D0-EO")
#Edificio D0 y E0
funcion(Piso_Kolbi_D_0_E_0,Piso_Liberty_D_0_E_0,Piso_Claro_D_0_E_0)

#EDIFICIO D
print("piso D1")
funcion(Piso_Kolbi_D_1,Piso_Liberty_D_1,Piso_Claro_D_1)
print("piso D2")
funcion(Piso_Kolbi_D_2,Piso_Liberty_D_2,Piso_Claro_D_2)
print("piso D3")
funcion(Piso_Kolbi_D_3,Piso_Liberty_D_3,Piso_Claro_D_3)
print("piso D4")
funcion(Piso_Kolbi_D_4,Piso_Liberty_D_4,Piso_Claro_D_4)
#Edificio E
print("piso E1")
funcion(Piso_Kolbi_E_1,Piso_Liberty_E_1,Piso_Claro_E_1)
print("piso E2")
funcion(Piso_Kolbi_E_2,Piso_Liberty_E_2,Piso_Claro_E_2)
print("piso E3")
funcion(Piso_Kolbi_E_3,Piso_Liberty_E_3,Piso_Claro_E_3)
print("piso E4")
funcion(Piso_Kolbi_E_4,Piso_Liberty_E_4,Piso_Claro_E_4)
print("piso E5")
funcion(Piso_Kolbi_E_5,Piso_Liberty_E_4,Piso_Claro_E_5)
print("piso F")
#Edificio F
funcion(Piso_Kolbi_F,Piso_Liberty_F,Piso_Claro_F)