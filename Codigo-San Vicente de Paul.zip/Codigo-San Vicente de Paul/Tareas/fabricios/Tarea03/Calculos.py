'''
Tarea 03, parte 1

Fabricio Solano Rojas B77447
'''

import numpy as np

# ------------------------------ Punto a ------------------------------

lista1 = [13,2,104,36,9,120,29,500,89,41,65,7 ]
diccionario={0:20,1:320,2:90,3:147,4:122,5:717,6:2,7:77,8:112,9:14,10:17,11:24}

def ordenamiento(lista1, diccionario):
    # Lista de salida que contiene los datos de la lista y valores del diccionario
    listaOrdenada =  lista1.copy()
    
    # Agregar valores del diccionario a la lista
    for value in diccionario.values():
        listaOrdenada.append(value)
    
    # Ordenar la nueva lista
    listaOrdenada.sort()
    
    return listaOrdenada

print("------------------------------ Punto a ------------------------------")
print("La lista con valores ordenados:\n", ordenamiento(lista1, diccionario), "\n")

# ------------------------------ Punto b ------------------------------

print("------------------------------ Punto b ------------------------------")
# Para la lista
mediaLista = np.mean(lista1)
print("La media de la lista es: ", mediaLista)

desviacionLista = np.std(lista1)
print("La desviación estándar de la lista es: ", desviacionLista)

medianaLista = np.median(lista1)
print("La mediana de la lista es: ", medianaLista, "\n")

# Para los valores del diccionario
listaDiccionario = [] # Lista con los valores del diccionario
for value in diccionario.values():
        listaDiccionario.append(value)

mediaDiccionario = np.mean(listaDiccionario)
print("La media de los valores del diccionario es: ", mediaDiccionario)

desviacionDiccionario = np.std(listaDiccionario)
print("La desviación estándar de los valores del diccionario es: ", desviacionDiccionario)

medianaDiccionario = np.median(listaDiccionario)
print("La mediana de los valores del diccionario es: ", medianaDiccionario, "\n")

# ------------------------------ Punto c ------------------------------
listaCopia = lista1.copy()
diccionarioCopia = diccionario.copy()
        
def nuevoDiccionario(listaCopia, diccionarioCopia):
    diccionario2 = {}
    for key in diccionarioCopia.keys():
        diccionario2[key] = listaCopia[key]
    
    return diccionario2

print("------------------------------ Punto c ------------------------------")        
print("Nuevo diccionario:\n", nuevoDiccionario(listaCopia, diccionarioCopia))
 