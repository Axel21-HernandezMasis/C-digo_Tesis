#include <iostream>

using namespace std;

#include "unidad_Generadora.h"
#include "fuente_Generadora.h"

unidad_generadora::unidad_generadora(string nombre_g, string sitio_u, string potencia_p, string nombre_f):fuente_generadora(nombre_f)
{
    nombre_generador = nombre_g;
    sitio_ubicacion = sitio_u;
    potencia_placa = potencia_p;
};

void unidad_generadora::ubicacion(void)
{
    cout << "Ubicacion unidad generadora: " << sitio_ubicacion << endl;
};

void unidad_generadora::despliegue_informacion(void)
{
    cout << "Nombre de la unidad generadora: " << nombre_generador << endl;
    cout << "Potencia de placa de la unidad generadora: " << potencia_placa << endl;
    fuente_generadora::despliegue_informacion();
};
