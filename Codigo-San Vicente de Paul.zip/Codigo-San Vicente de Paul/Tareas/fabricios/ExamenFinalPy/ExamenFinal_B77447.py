'''
Examen Final
Fabricio Solano Rojas B77447
'''

# ------------- Parte 1 -------------
#%%
# 1
import numpy as np
import pandas as pd
import prince
import os

import matplotlib.pyplot as plt
import seaborn as sns

from   sklearn.cluster import KMeans
from scipy.cluster.hierarchy import dendrogram, ward, single, complete,average,linkage, fcluster
from scipy.spatial.distance import pdist
#%%
# 2
filename_eval= "EnergíaMensualHorariaPlantasSEN_9_2022.csv"
Tabla = pd.read_csv(filename_eval, delimiter=',', decimal=".")
# 2.a
Indice = "Fechas"
Tabla = Tabla.set_index(Indice)
Tabla.index = pd.to_datetime(Tabla.index, format="%Y-%m-%d %H:%M:%S")
# 2.b
print("Datos: \n", Tabla, "\n")
# 2.c

# 3
Tabla_caso1 = Tabla.copy()

# 4
Tabla_caso1["SemanaIdx"] = Tabla_caso1.index.isocalendar().week
Tabla_caso1["DiaIdx"] = Tabla_caso1.index.isocalendar().day
print("Datos agregando las columnas SemanaIdx y DiaIdx\n", Tabla_caso1, "\n")
# 4.a
indice_semanas = Tabla_caso1.SemanaIdx.unique()
print("Arreglo de enteros con los valores de las semanas del año:\n", indice_semanas, "\n")
# 4.b
SemanaA = 1
SemanaB = 2
semanasInteres = Tabla_caso1.apply(lambda x: True if (x.SemanaIdx in indice_semanas[[SemanaA-1,SemanaB-1]]) else False, axis=1)
Tabla_caso1 = Tabla_caso1[semanasInteres]
print("Datos con las semanas solicitadas:\n", Tabla_caso1, "\n")
#%%
# ------------- Parte 2 -------------
# 1
Tabla_caso2 = Tabla_caso1.copy()
# 1.a
Tabla_caso2_semanaA = Tabla_caso2.groupby("SemanaIdx").get_group(indice_semanas[SemanaA-1])
Tabla_caso2_semanaB = Tabla_caso2.groupby("SemanaIdx").get_group(indice_semanas[SemanaB-1])
# Eliminando la columna SemanaIdx de las tablas
Tabla_caso2_semanaA=Tabla_caso2_semanaA.drop(["SemanaIdx"], axis=1, inplace=False)
Tabla_caso2_semanaB=Tabla_caso2_semanaB.drop(["SemanaIdx"], axis=1, inplace=False)
print("Tabla 'Tabla_caso2_semanaA':\n", Tabla_caso2_semanaA, "\n")
print("Tabla 'Tabla_caso2_semanaB':\n", Tabla_caso2_semanaB, "\n")
# Seleccionado las observaciones correspondientes a los días laborales para la tabla Tabla_caso2_semanaA
dias_laborales = Tabla_caso2_semanaA.apply(lambda x: True if (x.DiaIdx in [1,2,3,4,5]) else False, axis=1)
Tabla_caso2_semanaA = Tabla_caso2_semanaA[dias_laborales]
# Seleccionando las observaciones correspondientes a los fines de semana para la tabla Tabla_caso2_semanaB
dias_fin_semana = Tabla_caso2_semanaB.apply(lambda x: True if (x.DiaIdx in [6,7]) else False, axis=1)
Tabla_caso2_semanaB = Tabla_caso2_semanaB[dias_fin_semana]
# Eliminando columna DiaIdx
Tabla_caso2_semanaA.drop(["DiaIdx"], axis=1, inplace=True)
Tabla_caso2_semanaB.drop(["DiaIdx"], axis=1, inplace=True)
print("Tabla 'Tabla_caso2_semanaA' sin la columna DiaIdx:\n", Tabla_caso2_semanaA, "\n")
print("Tabla 'Tabla_caso2_semanaB' sin la columna DiaIdx:\n", Tabla_caso2_semanaB, "\n")
#%%
# 2
# 2.a
grupos = fcluster(linkage(pdist(Tabla_caso2_semanaA), method='ward'),3,criterion='maxclust')
print("Grupos:\n", grupos, "\n")
# 2.b
Tabla_caso2_semanaA_ext = Tabla_caso2_semanaA.copy()
Tabla_caso2_semanaA_ext["cluster"] = grupos
centros = Tabla_caso2_semanaA_ext.groupby("cluster").mean()
print("Centros:\n", centros, "\n")
# 2.c
colores_1 = ['#CF8EF8', '#523C81', '#D2D132', '#59C951', '#E5826C']
# Plotea Centro 1
c1 = centros.iloc[0]
y = c1.tolist()
N = len(y)
x = range(N)

width = 1/1.5
null=plt.bar(x, y, width, color=colores_1)
null=plt.xticks(range(centros.shape[1]), centros.columns,rotation=80,size=5.5)
plt.show()

# Plotea Centro 2
c2 = centros.iloc[1]
y = c2.tolist()
N = len(y)
x = range(N)

width = 1/1.5
null=plt.bar(x, y, width, color=colores_1)
null=plt.xticks(range(centros.shape[1]), centros.columns,rotation=80,size=5.5)
plt.show()

# Plotea Centro 3
c3 = centros.iloc[2]
y = c3.tolist()
N = len(y)
x = range(N)

width = 1/1.5
null=plt.bar(x, y, width, color=colores_1)
null=plt.xticks(range(centros.shape[1]), centros.columns,rotation=80,size=5.5)
plt.show()

# 3 Cometarios
# Para el caso del primer grupo se puede observar que se presenta más demanda de energía eléctrica
# para la planta Reventazón, además de otras tres plantas que presentan una demanda alta.
# Para el caso del segundo grupo se puede observar que se presenta más demanda de energía eléctrica
# en el caso del Intercambio Sur.
# Para el caso del tercer grupo se puede observar que se presenta más demanda de energía eléctrica
# para la planta Reventazón.
# Estos datos de parte de la planta Reventazón se debe a que esta es una de las plantas hidroeléctricas
# más grandes de Costa Rica, por lo tanto presenta una alta generación de energía eléctrica.
# Como se observó en los tres grupos, se presenta datos negativos por parte del Intercambio Norte,
# esto se debe por la línea SIEPAC, en donde se presenta un intercambio (entrega/comsumo) de energía eléctrica
# en centroamérica, por lo tanto se pueden presentar valores negativos de demanda.
#%%
# ------------- Parte 3 -------------
# 1
Tabla_caso3 = Tabla_caso2_semanaB.copy()

# 2
Tabla_caso3 = Tabla_caso3.T
print("Tabla Tabla_caso3 transpuesta:\n", Tabla_caso3, "\n")

# 3
# 3.a
grupos1 = fcluster(linkage(pdist(Tabla_caso3), method='average'),3,criterion='maxclust')
print("Grupos:\n", grupos1, "\n")
Tabla_caso3_ext = Tabla_caso3.copy()
Tabla_caso3_ext["cluster"] = grupos1
centros1 = Tabla_caso3_ext.groupby("cluster").mean()
print("Centros:\n", centros1, "\n")
#%%
# 3.b
# Plotea Centro 1
plt.plot(Tabla_caso3.columns, centros1.iloc[0].tolist())
# Plotea Centro 2
plt.plot(Tabla_caso3.columns, centros1.iloc[1].tolist())
# Plotea Centro 3
plt.plot(Tabla_caso3.columns, centros1.iloc[2].tolist())
plt.xticks(rotation=90, size=8)
plt.show()
# 3.c 
# Los números de los grupos obtenidos son: [1, 2, 3]
# Lista de plantas que corresponden al clouster 1
#%%
clouster1 = Tabla_caso3_ext.index[Tabla_caso3_ext["cluster"]==1].tolist()
print("Lista de plantas que corresponden al clouster 1:\n", clouster1, "\n")
# Lista de plantas que corresponden al clouster 2
clouster2 = Tabla_caso3_ext.index[Tabla_caso3_ext["cluster"]==2].tolist()
print("Lista de plantas que corresponden al clouster 2:\n", clouster2, "\n")
# Lista de plantas que corresponden al clouster 3
clouster3 = Tabla_caso3_ext.index[Tabla_caso3_ext["cluster"]==3].tolist()
print("Lista de plantas que corresponden al clouster 3:\n", clouster3, "\n")
# Conclusiones
# Del primer grupo se puede observar que para la semana B se presenta una demanda de energía eléctrica
# prácticmanete constante como se muestra en la curva azúl, además este grupo está conformado por mayor número
# de plantas.
# Del segundo grupo se puede observar en la curva naranja que presenta variaciones, en donde se presentan
# valores altos y luego tienden a reducirse, estos valores elevados de demanda también se deben a que en este grupo
# se encuentran conformados las planta de Reventazón e Intercambio Sur y como se mostraban en el gráfico de barras
# que aunque era de la semana A estas presentaban valores altos de demanda de energía eléctrica.
# El tercer grupo está conformado solo por el Intercambio Norte y por lo tanto como se observa en la curva verde
# presenta valores negativos de demanda y como se mencionó anteriormente esto se debe al intercambio de energía
# por medio de la línea SIEPAC.

#%%
# 4
# 4.a
pca = prince.PCA(n_components=2,n_iter=3,rescale_with_mean=True,rescale_with_std=True,copy=True,check_input=True,engine='auto',random_state=42)
pca = pca.fit(Tabla_caso3)
transformacion = pca.transform(Tabla_caso3)
print("Transformación mediante análisis por componentes principales:\n", transformacion, "\n")
# 4.b
y_color = pd.Series(grupos1).map({1: 'Grupo 1', 2: 'Grupo 2', 3: 'Grupo 3'})
ax = pca.plot_row_coordinates(Tabla_caso3,ax=None,figsize=(6, 6),x_component=0,y_component=1,labels=Tabla_caso3.index,color_labels=y_color,ellipse_outline=False,ellipse_fill=False,show_points=True)
plt.show()
#%%
# 4.c
average_res = average(Tabla_caso3)
null=dendrogram(average_res,labels= Tabla_caso3.index.tolist(),color_threshold=1.9,leaf_rotation=90)
plt.ylabel("Distancia o Agregación")
plt.show()
# 4.d Comentarios
# Del gráfico de ACP y el dendograma se puede observar que en el caso del Intercambio Norte se encuentra bastante distante
# respecto al resto de plantas, por lo tanto del dendograma se muestra una partición de dos ramas, la agrupación: Intercambio Norte y
# el resto de plantas. Ahora en el caso de la partición de tres grupos como se tiene establecido se puede observar claramente tanto del
# gráfico del ACP y el dendograma la separación de estos, en donde se muestra que el caso del grupo 1 presentan una distancia pequeña
# para algunas de las plantas, por lo tanto se encuentran bastantes juntos.
# A pesar de esta comparación, es importnte también el anális separado del gráfico ACP y el dendograma ya que en cada una se presenta
# información importante, como en el caso de un análisis para diferentes distancias o agregaciones en el dendograma para el análisis de
# diferentes particiones de los clústeres.

# %%
