// ===============================
// Fabricio Solano Rojas B77447
// ===============================

#include <iostream>
#include <cstdio>
#include "metodoh.h"

using namespace std;

int main(void)
{
    // ----------------------------------------------------------------
    // Se definen los valores que se deben ingresar por linea de comandos
    cout << "Ingrese el valor de evualuacion: " << endl;
    float x;
    cin >> x;

    cout << "Ingrese el error aceptado por el metodo numerico: " << endl;
    float error;
    cin >> error;
    // ----------------------------------------------------------------

    cout << "Metodo de Newton\n" << endl;

    // Se crea el objeto asociado a la clase de la ecuaci�n del polinomio
    _polinomio objeto(x, error);
    objeto.metodoNewton(); // Se ejecuta el m�todo de Newton
    // Se crea el objeto asociado a la clase de la ecuaci�n del exponencial
    _exponencial objeto1(x, error);
    objeto1.metodoNewton(); // Se ejecuta el m�todo de Newton
    // Se crea el objeto asociado a la clase de la ecuaci�n del seno
    _seno objeto2(x, error);
    objeto2.metodoNewton(); // Se ejecuta el m�todo de Newton

    return 0;
}

