#ifndef PLANTA_GENERADORA_H_INCLUDED
#define PLANTA_GENERADORA_H_INCLUDED

#include <list>
#include "unidad_Generadora.h"

class planta_generadora{
private:
    string nombre_planta;
    string ubicacion_planta;
    list<unidad_generadora> unidades_generadoras;
public:
    planta_generadora(string, string);
    void insertar_componentes(unidad_generadora);
    void mostrar_componentes(void);
    void despliegue_informacion(void);
};

#endif // PLANTA_GENERADORA_H_INCLUDED
