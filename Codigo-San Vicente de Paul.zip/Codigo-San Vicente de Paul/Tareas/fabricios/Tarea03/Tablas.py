'''
Tarea 03, parte 2

Fabricio Solano Rojas B77447
'''

import pandas as pd
from numpy import mean, std

datos = {'nombre': ["Marco","Francisco","Roberto","Mariel","Sonia","John","Charles"],
         'carrera': ["Ing. Eléctrica","Educacion Física","Matemáticas","Ing. Mecánica","Derecho","Idiiomas","Ing. Civil"],
         'Edad': [21,20,19,29,22,21,22]
         }

# ------------------------------ Punto a ------------------------------
DF = pd.DataFrame(datos, index=['est1','est2','est3','est4','est5','est6','est7'])

# ------------------------------ Punto b ------------------------------
print("------------------------------ Punto b ------------------------------")
print("Tabla convertida con pandas:\n", DF, "\n")

# ------------------------------ Punto c ------------------------------
print("------------------------------ Punto c ------------------------------")
# Ordenar de manera ascendente
ordenarNombre = DF.sort_values('nombre')

print("Tabla ordenada por nombre (ascendente):\n", ordenarNombre, "\n")

# ------------------------------ Punto d ------------------------------
print("------------------------------ Punto d ------------------------------")
# Ordenar de manera descendente
ordenarCarrera = DF.sort_values('carrera', ascending=False)

print("Tabla ordenada por carrera (descendente):\n", ordenarCarrera, "\n")

# ------------------------------ Punto e ------------------------------
print("------------------------------ Punto e ------------------------------")
print("Visualización usando el índice binario de los cuatro primeros estudiantes:")
print(DF.iloc[0:4], "\n")

# ------------------------------ Punto f ------------------------------
print("------------------------------ Punto f ------------------------------")
print("Visualización usando el índice textual de los estudiantes a partir de la segunda entrada:")
print(DF.loc['est2':], "\n")

# ------------------------------ Punto g ------------------------------
print("------------------------------ Punto g ------------------------------")
print("Estudiantes de las posiciones binarias 3,4,5 de los datos de carrera y edad únicamente:")
print(DF.iloc[[3, 4, 5], [1, 2]])

# ------------------------------ Punto h ------------------------------
# Convertir y exportar una tabla pandas en un archivo de Excel
DF.to_excel('tablaPandas.xlsx')