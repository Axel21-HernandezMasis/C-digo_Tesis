# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import pandas as pd
import glob
import numpy as np
import random
import matplotlib.pyplot as plt



    
    
#******************************************************************************************
pd.options.display.max_rows = 9999
#Edificio A
#ICE

column_names = pd.Series(['Time', 'Longitude', 'Latitude', 'Operador',"Network" , 'NetworkTech', 'Level', "Speed"])


Piso_Siete_ICE = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_ICE\EDIFICIO_A_PISO_7\ICE_2023.11.25_13.00.50\ICE_2023.11.25_13.00.50.txt", sep=';', decimal=',') 
Piso_Siete_ICE.fillna(0, inplace = True)

Piso_Seis_ICE = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_ICE\EDIFICIO_A_PISO_6\ICE_2023.11.25_13.04.20\ICE_2023.11.25_13.04.20.txt", sep=';', decimal=',') 
Piso_Seis_ICE.fillna(0, inplace = True)

Piso_Cinco_ICE = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_ICE\EDIFICIO_A_PISO_5\ICE_2023.11.25_13.07.46\ICE_2023.11.25_13.07.46.txt", sep=';', decimal=',') 
Piso_Cinco_ICE.fillna(0, inplace = True)

Piso_Cuatro_ICE = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_ICE\EDIFICIO_A_PISO_4\ICE_2023.11.25_13.11.42\ICE_2023.11.25_13.11.42.txt", sep=';', decimal=',') 
Piso_Cuatro_ICE.fillna(0, inplace = True)

Piso_Tres_ICE = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_ICE\EDIFICIO_A_PISO_3\ICE_2023.11.25_13.15.34\ICE_2023.11.25_13.15.34.txt", sep=';', decimal=',')
Piso_Tres_ICE.fillna(0, inplace = True)

Piso_Uno_ICE = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_ICE\EDIFICIO_A_PISO_1\ICE_2023.11.25_13.28.44\ICE_2023.11.25_13.28.44.txt", sep=';', decimal=',')  
Piso_Uno_ICE.fillna(0, inplace = True)


#Claro

Piso_Siete_CLARO = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_CLARO\EDIFICIO_A_PISO_7\Claro_2023.11.25_13.00.43\Claro_2023.11.25_13.00.43.txt", sep=';', decimal=',') 
Piso_Siete_CLARO.fillna(0, inplace = True)

Piso_Seis_CLARO = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_CLARO\EDIFICIO_A_PISO_6\Claro_2023.11.25_13.04.22\Claro_2023.11.25_13.04.22.txt", sep=';', decimal=',') 
Piso_Seis_CLARO.fillna(0, inplace = True)

Piso_Cinco_CLARO = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_CLARO\EDIFICIO_A_PISO_5\Claro_2023.11.25_13.07.49\Claro_2023.11.25_13.07.49.txt", sep=';', decimal=',') 
Piso_Cinco_CLARO.fillna(0, inplace = True)

Piso_Cuatro_CLARO = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_CLARO\EDIFICIO_A_PISO_4\Claro_2023.11.25_13.11.45\Claro_2023.11.25_13.11.45.txt", sep=';', decimal=',') 
Piso_Cuatro_CLARO.fillna(0, inplace = True)

Piso_Tres_CLARO = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_CLARO\EDIFICIO_A_PISO_3\Claro_2023.11.25_13.15.31\Claro_2023.11.25_13.15.31.txt", sep=';', decimal=',') 
Piso_Tres_CLARO.fillna(0, inplace = True)


Piso_Uno_CLARO = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_CLARO\EDIFICIO_A_PISO_1\Claro_2023.11.25_13.28.47\Claro_2023.11.25_13.28.47.txt", sep=';', decimal=',') 
Piso_Uno_CLARO.fillna(0, inplace = True)

#Liberty

Piso_Siete_Liberty = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_LIBERTY\EDIFICIO_A_PISO_7\LIBERTY_2023.11.25_14.14.55\LIBERTY_2023.11.25_14.14.55.txt", sep=';', decimal=',') 
Piso_Siete_Liberty.fillna(0, inplace = True)


Piso_Seis_Liberty = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_LIBERTY\EDIFICIO_A_PISO_6\LIBERTY_2023.11.25_14.17.47\LIBERTY_2023.11.25_14.17.47.txt", sep=';', decimal=',') 
Piso_Seis_Liberty.fillna(0, inplace = True)


Piso_Cinco_Liberty = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_LIBERTY\EDIFICIO_A_PISO_5\LIBERTY_2023.11.25_14.21.15\LIBERTY_2023.11.25_14.21.15.txt", sep=';', decimal=',') 
Piso_Cinco_Liberty.fillna(0, inplace = True)


Piso_Cuatro_Liberty = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_LIBERTY\EDIFICIO_A_PISO_4\LIBERTY_2023.11.25_14.24.25\LIBERTY_2023.11.25_14.24.25.txt", sep=';', decimal=',') 
Piso_Cuatro_Liberty.fillna(0, inplace = True)

Piso_Tres_Liberty = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_LIBERTY\EDIFICIO_A_PISO_3\LIBERTY_2023.11.25_14.27.52\LIBERTY_2023.11.25_14.27.52.txt", sep=';', decimal=',') 
Piso_Tres_Liberty.fillna(0, inplace = True)

Piso_Uno_Liberty = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_LIBERTY\EDIFICIO_A_PISO_1\LIBERTY_2023.11.25_14.38.47\LIBERTY_2023.11.25_14.38.47.txt", sep=';', decimal=',') 
Piso_Uno_Liberty.fillna(0, inplace = True)
#******************************************************************************************

#Edificio B

#CLARO

Piso_Claro_B_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_CLARO\EDIFICIO_B_PISO_3\Claro_2023.11.25_13.23.34\Claro_2023.11.25_13.23.34.txt", sep=';', decimal=',')
Piso_Claro_B_3.fillna(0, inplace = True)

Piso_Claro_B_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_CLARO\EDIFICIO_B_PISO_1\Claro_2023.11.25_13.34.43\Claro_2023.11.25_13.34.43.txt", sep=';', decimal=',')
Piso_Claro_B_1.fillna(0, inplace = True)

Piso_Claro_B_PB = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_CLARO\EDIFICIO_B_PB\Claro_2023.11.25_13.40.24\Claro_2023.11.25_13.40.24.txt", sep=';', decimal=',')
Piso_Claro_B_PB.fillna(0, inplace = True)

#ICE

Piso_Kolbi_B_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_ICE\EDIFICIO_B_PISO_3\ICE_2023.11.25_13.23.39\ICE_2023.11.25_13.23.39.txt", sep=';', decimal=',')
Piso_Kolbi_B_3.fillna(0, inplace = True)

Piso_Kolbi_B_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_ICE\EDIFICIO_B_PISO_1\ICE_2023.11.25_13.34.50\ICE_2023.11.25_13.34.50.txt", sep=';', decimal=',')
Piso_Kolbi_B_1.fillna(0, inplace = True)

Piso_Kolbi_B_PB = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_ICE\EDIFICIO_B_PB\ICE_2023.11.25_13.40.29\ICE_2023.11.25_13.40.29.txt", sep=';', decimal=',')
Piso_Kolbi_B_PB.fillna(0, inplace = True)
#LIBERTY

Piso_Liberty_B_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_LIBERTY\EDIFICIO_B_PISO_3\LIBERTY_2023.11.25_14.31.40\LIBERTY_2023.11.25_14.31.40.txt", sep=';', decimal=',')
Piso_Liberty_B_3.fillna(0, inplace = True)

Piso_Liberty_B_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_LIBERTY\EDIFICIO_B_PISO_1\LIBERTY_2023.11.25_14.42.49\LIBERTY_2023.11.25_14.42.49.txt", sep=';', decimal=',')
Piso_Liberty_B_1.fillna(0, inplace = True)

Piso_Liberty_B_PB = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_LIBERTY\EDIFICIO_B_PB\LIBERTY_2023.11.25_14.47.17\LIBERTY_2023.11.25_14.47.17.txt", sep=';', decimal=',')
Piso_Liberty_B_PB.fillna(0, inplace = True)

#******************************************************************************************
#Edificio C

Piso_Claro_C_FARMACIA = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_CLARO\EDIFICIO_C_FARMACIA\Claro_2023.11.25_13.42.53\Claro_2023.11.25_13.42.53.txt", sep=';', decimal=',')
Piso_Claro_C_FARMACIA.fillna(0, inplace = True)

Piso_Claro_C_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_CLARO\EDIFICIO_C_PISO_1\Claro_2023.11.25_13.45.23\Claro_2023.11.25_13.45.23.txt", sep=';', decimal=',')
Piso_Claro_C_1.fillna(0, inplace = True)

Piso_Kolbi_C_FARMACIA = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_ICE\EDIFICIO_C_FARMACIA\ICE_2023.11.25_13.42.58\ICE_2023.11.25_13.42.58.txt", sep=';', decimal=',')
Piso_Kolbi_C_FARMACIA.fillna(0, inplace = True)

Piso_Kolbi_C_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_ICE\EDIFICIO_C_PISO_1\ICE_2023.11.25_13.45.27\ICE_2023.11.25_13.45.27.txt", sep=';', decimal=',')
Piso_Kolbi_C_1.fillna(0, inplace = True)

Piso_Liberty_C_FARMACIA = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_LIBERTY\EDIFICIO_C_FARMACIA\LIBERTY_2023.11.25_14.51.45\LIBERTY_2023.11.25_14.51.45.txt", sep=';', decimal=',')
Piso_Liberty_C_FARMACIA.fillna(0, inplace = True)

Piso_Liberty_C_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_LIBERTY\EDIFICIO_C_PISO_1\LIBERTY_2023.11.25_14.53.56\LIBERTY_2023.11.25_14.53.56.txt", sep=';', decimal=',')
Piso_Liberty_C_1.fillna(0, inplace = True)


#******************************************************************************************
#Edificio R


#Piso R
Piso_Claro_R_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_CLARO\EDIFICIO_R_PISO_3\Claro_2023.11.25_13.55.50\Claro_2023.11.25_13.55.50.txt", sep=';', decimal=',')
Piso_Claro_R_3.fillna(0, inplace = True)

#Piso 1
Piso_Claro_R_2 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_CLARO\EDIFICIO_R_PISO_2\Claro_2023.11.25_13.58.33\Claro_2023.11.25_13.58.33.txt", sep=';', decimal=',')
Piso_Claro_R_2.fillna(0, inplace = True)
#Piso 2
Piso_Claro_R_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_CLARO\EDIFICIO_R_PISO_1\Claro_2023.11.25_14.01.30\Claro_2023.11.25_14.01.30.txt", sep=';', decimal=',')
Piso_Claro_R_1.fillna(0, inplace = True)

Piso_Kolbi_R_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_ICE\EDIFICIO_R_PISO_3\ICE_2023.11.25_13.56.01\ICE_2023.11.25_13.56.01.txt", sep=';', decimal=',')
Piso_Kolbi_R_3.fillna(0, inplace = True)
#Piso 1
Piso_Kolbi_R_2 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_ICE\EDIFICIO_R_PISO_2\ICE_2023.11.25_13.58.37\ICE_2023.11.25_13.58.37.txt", sep=';', decimal=',')
Piso_Kolbi_R_2.fillna(0, inplace = True)
#Piso 2
Piso_Kolbi_R_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_ICE\EDIFICIO_R_PISO_1\ICE_2023.11.25_14.01.33\ICE_2023.11.25_14.01.33.txt", sep=';', decimal=',')
Piso_Kolbi_R_1.fillna(0, inplace = True)
#Piso D0 E0

Piso_Liberty_R_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_LIBERTY\EDIFICIO_R_PISO_3\LIBERTY_2023.11.25_15.05.06\LIBERTY_2023.11.25_15.05.06.txt", sep=';', decimal=',')
Piso_Liberty_R_3.fillna(0, inplace = True)
#Piso 1
Piso_Liberty_R_2 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_LIBERTY\EDIFICIO_R_PISO_2\LIBERTY_2023.11.25_15.06.17\LIBERTY_2023.11.25_15.06.17.txt", sep=';', decimal=',')
Piso_Liberty_R_2.fillna(0, inplace = True)
#Piso 2
Piso_Liberty_R_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_3G_LIBERTY\EDIFICIO_R_PISO_1\LIBERTY_2023.11.25_15.08.42\LIBERTY_2023.11.25_15.08.42.txt", sep=';', decimal=',')
Piso_Liberty_R_1.fillna(0, inplace = True)





 

#Funciones


def Limpiar(marks):
    b=[]
    m=len(marks.index)
    for j in range(m):
        Filaaux=marks.iloc[j,0]
        Filaaux=Filaaux.split()
        b.append(Filaaux)
    Datos=pd.DataFrame(b,columns=column_names)
    Datos.loc[Datos["Network"] == "4G", "Red_G"] = 4

    Datos.loc[Datos["Network"] == "3G", "Red_G"] = 3

    Datos.drop(Datos[(Datos['Red_G']==4)].index, inplace =True) #Elimina el 4G
    Datos.drop(['Time', 'Longitude', 'Latitude','Network','Level' ], axis=1, inplace=True)
    Datos["NetworkTech"]=Datos["NetworkTech"].astype(float)
    Datos["Speed"]=Datos["Speed"].astype(str)
    
   
    
    return Datos



def assign_Result_4G(marks):
    
    if marks <= -44 and marks >= -80 :
        result = "1-Excelente"
    elif marks <= -80 and marks >= -90 :
        result = "2-Buena" 
    elif marks <= -90 and marks >= -100 :
        result = "3-Justa"  
    elif  marks <= -100 and marks >= -110 :
        result = "4-Mala"
    elif marks <= -111 :
        result = "5-Muerta"  
    else:
        result = "6-Error"
    return result



def assign_Result_3G(marks):
    
    if marks <= -44 and marks >= -60 :
        result = "1-Excelente" 
    elif marks <= -60 and marks >= -75 :
        result = "2-Buena"  
    elif  marks <= -75 and marks >= -85 :
        result = "3-Justa" 
    elif  marks <= -85 and marks >= -95 :
        result = "4-Mala"
    elif marks <= -96 :
        result = "5-Muerta"  
    else:
        result = "6-Error"
    return result
        
  
   

def assign_Umbral_3G(marks):
    
    if marks <= -44 and marks >= -85 :
        result = "1-Dentro_Umbral"
    elif marks <= -86:
        result = "2-Fuera_Umbral" 
     
    else:
        result = "6-Error"
    return result

def assign_3G_or_4G(marks):
    for i in range(len(marks)):
        if marks.iloc[i]['Red_G']==4.0:
            marks["Calidad_4G"] = marks["NetworkTech"].apply(assign_Result_3G) #Esto al final se remueve
            marks["Umbral"] = marks["NetworkTech"].apply(assign_Umbral_3G)
 
           
            
        elif marks.iloc[i]['Red_G']==3.0:
            marks["Calidad_3G"] = marks["NetworkTech"].apply(assign_Result_3G)
            marks["Umbral"] = marks["NetworkTech"].apply(assign_Umbral_3G)
            
    marks=marks.sort_values("Calidad_3G")
    marks.head()        
    return marks

def Mala_cobertura(marks):

    x=0 
    y=0
    z=0 
    a=0 
    b=0 
    
    for i in range(len(marks["Calidad_3G"])):
        if marks.iloc[i]["Calidad_3G"]=="1-Excelente":
            a=a+1
        if marks.iloc[i]["Calidad_3G"]=="2-Buena":
            b=b+1
        if marks.iloc[i]["Calidad_3G"]=="3-Justa":
            x=x+1
        if marks.iloc[i]["Calidad_3G"]=="4-Mala":
            y=y+1
        if marks.iloc[i]["Calidad_3G"]=="5-Muerta":
            z=z+1
        
        

   # print("Se encontraron :""",a,"""datos de calidad
     #         Excelente respecto a la muestra de datos 
    #          de:""",len(marks["Calidad_4G"]))
 #   print("Se encontraron :""",b,""" datos de calidad 
    #          Buena respecto a la muestra de datos 
     #         de:""",len(marks["Calidad_4G"]))
  #  print("Se encontraron :""",x,""" datos de calidad 
    #          Justa respecto a la muestra de datos 
     #         de:""",len(marks["Calidad_4G"]))
  #  print("Se encontraron :""",y,""" datos de calidad 
     #         Mala respecto a la muestra de datos 
      #        de:""",len(marks["Calidad_4G"]))
  #  print("Se encontraron :""",z,"""datos de calidad 
     #         Muerta respecto a la muestra de datos 
      #        de:""",len(marks["Calidad_4G"]))
             
    return a,b,x,y,z


        
def Datos_Finales(marks):
 #   display(marks)
    Varianza=marks["NetworkTech"].var(ddof=0)
    Desviacion_Estandar=marks["NetworkTech"].std()
    Promedio_Cobertura=marks["NetworkTech"].mean()
#    Promedio_Velocidad=marks["Speed"].mean()
    print("La varianza de la cobertura es:",Varianza)#La variación de parametro
    print("La Desviacion estandar es:",Desviacion_Estandar)#Cuanto se desvian los parametros entre sí
    print("El promedio de cobertura es",Promedio_Cobertura)#Promedio de la señal
#    print("El promedio de ancho de banda",Promedio_Velocidad,"kbps")#Promedio de la señal
    
    
    # marks["NetworkTech"].plot()
    
    

def plt_auxiliar(): 
    plt.plot(["1-Excelente", "1-Excelente"],
         [-50, -115],
         color='black', linestyle='')
    plt.plot(["2-Buena", "2-Buena"],
         [-50, -115],
         color='black', linestyle='')
    plt.plot(["3-Justa", "3-Justa"],
         [-50, -115],
         color='black', linestyle='')
    plt.plot(["4-Mala", "4-Mala"],
         [-50, -115],
         color='black', linestyle='')
    plt.plot(["5-Muerta", "5-Muerta"],
         [-50, -115],
         color='black', linestyle='')

def plt_auxiliar_2():     
    plt.plot(["1-Excelente", "5-Muerta"],
         [-60, -60],
         color='black', linestyle='--')
    plt.plot(["1-Excelente", "5-Muerta"],
         [-75, -75],
         color='black', linestyle='--')
    plt.plot(["1-Excelente", "5-Muerta"],
         [-85, -85],
         color='black', linestyle='--')    
    plt.plot(["1-Excelente", "5-Muerta"],
         [-95, -95],
         color='black', linestyle='--')

def plt_auxiliar_3():
    plt.plot(["1-Excelente", "1-Excelente"],
         [0, 100],color='black', linestyle='')
    
def plt_auxiliar_4():
    plt.plot(["1-Excelente", "1-Excelente"],
         [0, 120],color='black', linestyle='')
    
    
#********************************************************************************#
def Mala_cobertura_Sutel(marks):

    p=0 
    h=0

    
    for i in range(len(marks["Calidad_3G"])):
        if marks.iloc[i]["Umbral"]=="1-Dentro_Umbral":
            p=p+1
        if marks.iloc[i]["Umbral"]=="2-Fuera_Umbral":
            h=h+1

    return p,h
        
        





print("**-----------*Sección de plts*------------**")
 #Seccion Plt
#Piso 1 edificio A
# Crear el gráfico de dispersión

def funcion(marks, marks2, marks3):
    
#********************************************************************************

#Pisol
    marks=Limpiar(marks)
    marks=assign_3G_or_4G(marks)
    
    marks2=Limpiar(marks2)
    marks2=assign_3G_or_4G(marks2)
    
    marks3=Limpiar(marks3)
    marks3=assign_3G_or_4G(marks3)
    
    plt_auxiliar()
    plt_auxiliar_2()
    
    plt.scatter(marks2["Calidad_3G"], marks2["NetworkTech"], color='b', label="Liberty")
    plt.scatter(marks["Calidad_3G"],marks["NetworkTech"], color = 'g',label = "ICE")
    plt.scatter(marks3["Calidad_3G"],marks3["NetworkTech"], color = 'r',label = "Claro")
    plt.legend(loc='upper right')
    plt.title("Edificio")
    plt.show()
    
    plt_auxiliar_3()
    a_1,b_1,x_1,y_1,z_1=Mala_cobertura(marks)
    a_2,b_2,x_2,y_2,z_2=Mala_cobertura(marks2)
    a_3,b_3,x_3,y_3,z_3=Mala_cobertura(marks3)

    total_1 = a_1 + b_1 + x_1 + y_1 + z_1
    total_2 = a_2 + b_2 + x_2 + y_2 + z_2
    total_3 = a_3 + b_3 + x_3 + y_3 + z_3

    calidad_x=np.array(["1-Excelente","2-Buena","3-Justa","4-Mala","5-Muerta"])
    calidad_y=np.array([a_1,b_1,x_1,y_1,z_1])/ total_1 * 100
    calidad_y_2=np.array([a_2,b_2,x_2,y_2,z_2])/ total_2 * 100
    calidad_y_3=np.array([a_3,b_3,x_3,y_3,z_3])/ total_3 * 100
    
    # Ancho de las barras
    bar_width = 0.2

    positions_1 = np.arange(len(calidad_x))
    positions_2 = positions_1 + bar_width + 0.05
    positions_3 = positions_2 + bar_width + 0.05

    # Crear la gráfica
    plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
    plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
    plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')
    
    # Etiquetas y título
    plt.xlabel('Calidad')
    plt.ylabel('Porcentaje')
    plt.title('Comparación de Calidad (Porcentaje Total)')
    plt.xticks(positions_2, calidad_x)

    # Añadir el valor del porcentaje dentro de la barra

    for i, value in enumerate(calidad_y):
        if value>0:
            plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

    for i, value in enumerate(calidad_y_2):
        if value>0:
            plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

    for i, value in enumerate(calidad_y_3):
        if value>0:
            plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

    # Mostrar la gráfica
    plt.show()
    
    plt_auxiliar_4()

    h_1,p_1=Mala_cobertura_Sutel(marks)
    h_2,p_2=Mala_cobertura_Sutel(marks2)
    h_3,p_3=Mala_cobertura_Sutel(marks3)

    total_1 = h_1 + p_1
    total_2 = h_2 + p_2
    total_3 = h_3 + p_3


    calidad_x=np.array(["1-Dentro_Umbral","2-Fuera_Umbral"])
    calidad_y=np.array([h_1,p_1])/ total_1 * 100
    calidad_y_2=np.array([h_2,p_2])/ total_2 * 100
    calidad_y_3=np.array([h_3,p_3])/ total_3 * 100

    # Ancho de las barras
    bar_width = 0.2

    positions_1 = np.arange(len(calidad_x))
    positions_2 = positions_1 + bar_width
    positions_3 = positions_2 + bar_width


    # Crear la gráfica
    plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
    plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
    plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

    # Etiquetas y título
    plt.xlabel('Umbral de cobertura')
    plt.ylabel('Valores')
    plt.title('Comparación de Calidad porcentaje Sutel')
    plt.xticks(positions_2, calidad_x)

    plt.legend()
    # Añadir el valor del porcentaje dentro de la barra

    for i, value in enumerate(calidad_y):
        if value>0:
            plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

    for i, value in enumerate(calidad_y_2):
        if value>0:
            plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

    for i, value in enumerate(calidad_y_3):
        if value>0:
            plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

    # Mostrar la gráfica
    plt.show()
     

    print("Para ICE:")
    Datos_Finales(marks)

    print("Para Liberty:")
    Datos_Finales(marks2)

    print("Para Claro:")
    Datos_Finales(marks3)

    #**********************************************
    
#Main
#Edificio A
funcion(Piso_Uno_ICE, Piso_Uno_Liberty, Piso_Uno_CLARO)
funcion(Piso_Tres_ICE, Piso_Tres_Liberty, Piso_Tres_CLARO)
funcion(Piso_Cuatro_ICE, Piso_Cuatro_Liberty, Piso_Cuatro_CLARO) 
funcion(Piso_Cinco_ICE, Piso_Cinco_Liberty, Piso_Cinco_CLARO) 
funcion(Piso_Seis_ICE, Piso_Seis_Liberty, Piso_Seis_CLARO) 
funcion(Piso_Siete_ICE, Piso_Siete_Liberty, Piso_Siete_CLARO) 

#Edificio B
print("PISO B")
funcion(Piso_Kolbi_B_PB, Piso_Liberty_B_PB, Piso_Claro_B_PB)
funcion(Piso_Kolbi_B_1, Piso_Liberty_B_1, Piso_Claro_B_1)
funcion(Piso_Kolbi_B_3, Piso_Liberty_B_3, Piso_Claro_B_3)

print("PISO C")
#Edificio C
funcion(Piso_Kolbi_C_FARMACIA, Piso_Liberty_C_FARMACIA, Piso_Claro_C_FARMACIA)
funcion(Piso_Kolbi_C_1, Piso_Liberty_C_1, Piso_Claro_C_1)

print("PISO R")
#Edificio R
funcion(Piso_Kolbi_R_1, Piso_Liberty_R_1, Piso_Claro_R_1)
funcion(Piso_Kolbi_R_2, Piso_Liberty_R_2, Piso_Claro_R_2)
funcion(Piso_Kolbi_R_3, Piso_Liberty_R_3, Piso_Claro_R_3)