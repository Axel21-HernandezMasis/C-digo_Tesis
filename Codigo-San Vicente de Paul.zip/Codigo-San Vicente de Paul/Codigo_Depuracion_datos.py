# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import pandas as pd
import glob
import numpy as np
import random
import matplotlib.pyplot as plt


# read text file into pandas DataFrame 
column_names = pd.Series(['Time', 'Longitude', 'Latitude', 'Operador',"Network" , 'NetworkTech', 'Level', "Speed"])
df = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_de_Claro\Edificio_A\Claro_2023.10.14_08.15.48\Claro_2023.10.14_08.15.48.txt", sep=';', decimal=',') 
Piso_Tres = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_de_Claro\Edificio_A\Claro_2023.10.14_08.35.22\Claro_2023.10.14_08.35.22.txt", sep=';', decimal=',')
Piso_Dos = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_de_Claro\Edificio_A\Claro_2023.10.14_08.44.36\Claro_2023.10.14_08.44.36.txt", sep=';', decimal=',') 
Piso_Uno = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_de_Claro\Edificio_A\Claro_2023.10.14_08.53.29\Claro_2023.10.14_08.53.29.txt", sep=';', decimal=',')  
 



m=len(df.index) #fila
a=len(Piso_Uno.index) 
d=len(Piso_Dos.index) 
s=len(Piso_Tres.index)  


    
#Declaring an empty 1D array.
b = []
Piso3_aux=[]
Piso2_aux=[]
Piso1_aux=[]

for j in range(m):
    Filaaux=df.iloc[j,0]
    Filaaux=Filaaux.split()
    b.append(Filaaux)
#print(b)
for j in range(a):
    Filaaux=Piso_Uno.iloc[j,0]
    Filaaux=Filaaux.split()
    Piso1_aux.append(Filaaux)
    
for j in range(d):
    Filaaux=Piso_Dos.iloc[j,0]
    Filaaux=Filaaux.split()
    Piso2_aux.append(Filaaux)
    
for j in range(s):
    Filaaux=Piso_Tres.iloc[j,0]
    Filaaux=Filaaux.split()
    Piso3_aux.append(Filaaux)
    
#Initialize the column.



    
Datos_Claro=pd.DataFrame(b,columns=column_names)
Datos_Claro1=pd.DataFrame(Piso1_aux,columns=column_names)
Datos_Claro2=pd.DataFrame(Piso2_aux,columns=column_names)
Datos_Claro3=pd.DataFrame(Piso3_aux,columns=column_names)

#Creo un entero de datos para comparar


Datos_Claro1.loc[Datos_Claro1["Network"] == "4G", "Red_G"] = 4
Datos_Claro1.loc[Datos_Claro1["Network"] == "3G", "Red_G"] = 3

Datos_Claro2.loc[Datos_Claro2["Network"] == "4G", "Red_G"] = 4
Datos_Claro2.loc[Datos_Claro2["Network"] == "3G", "Red_G"] = 3

Datos_Claro3.loc[Datos_Claro3["Network"] == "4G", "Red_G"] = 4
Datos_Claro3.loc[Datos_Claro3["Network"] == "3G", "Red_G"] = 3



#Remover columnas sin importancia
Datos_Claro.drop(['Time', 'Longitude', 'Latitude','Network','Level' ], axis=1, inplace=True)

Datos_Claro1.drop(['Time', 'Longitude', 'Latitude','Network','Level' ], axis=1, inplace=True)
Datos_Claro2.drop(['Time', 'Longitude', 'Latitude','Network','Level' ], axis=1, inplace=True)
Datos_Claro3.drop(['Time', 'Longitude', 'Latitude','Network','Level' ], axis=1, inplace=True)


Datos_Claro["NetworkTech"]=Datos_Claro["NetworkTech"].astype(float)
Datos_Claro["Speed"]=Datos_Claro["Speed"].astype(float)

Datos_Claro1["NetworkTech"]=Datos_Claro1["NetworkTech"].astype(float)
Datos_Claro1["Speed"]=Datos_Claro1["Speed"].astype(float)

Datos_Claro2["NetworkTech"]=Datos_Claro2["NetworkTech"].astype(float)
Datos_Claro2["Speed"]=Datos_Claro2["Speed"].astype(float)

Datos_Claro3["NetworkTech"]=Datos_Claro3["NetworkTech"].astype(float)
Datos_Claro3["Speed"]=Datos_Claro3["Speed"].astype(float)



#Datos_Claro["NetworkTech"].plot()
#Condicionales

#Datos_Claro.loc[Datos_Claro["NetworkTech"] , "Red_G"] = 3

#display(Datos_Claro)

    
    
def assign_Result_4G(marks):
    
    if marks < -90.0 and marks >= -105.0 :
        result = "Buena" 
    elif marks < -106.0 or marks >= -110.0 :
        result = "Justa"  
    elif  marks < -111.0 or marks >= -119.0 :
        result = "Mala" 
    elif marks < -120.0 :
        result = "Muera"  
    else:
        result = "Excelente"
    return result

def assign_Result_3G(marks):
    
    if marks < -70.0 and marks >= -85.0 :
        result = "Buena" 
    elif marks < -86.0 or marks >= -100.0 :
        result = "Justa"  
    elif  marks < -101.0 or marks >= -109.0 :
        result = "Mala" 
    elif marks < -110.0 :
        result = "Muera"  
    else:
        result = "Excelente"
    return result


 
for i in range(len(Datos_Claro)):
    if Datos_Claro.iloc[i]['Red_G']==4.0:
        Datos_Claro["Calidad"] = Datos_Claro["NetworkTech"].apply(assign_Result_4G)
    else:
        Datos_Claro["Calidad"] = Datos_Claro["NetworkTech"].apply(assign_Result_3G)

for i in range(len(Datos_Claro1)):
    if Datos_Claro1.iloc[i]['Red_G']==4.0:
        Datos_Claro1["Calidad"] = Datos_Claro1["NetworkTech"].apply(assign_Result_4G)
    else:
        Datos_Claro1["Calidad"] = Datos_Claro1["NetworkTech"].apply(assign_Result_3G)
        
for i in range(len(Datos_Claro2)):
    if Datos_Claro2.iloc[i]['Red_G']==4.0:
        Datos_Claro2["Calidad"] = Datos_Claro2["NetworkTech"].apply(assign_Result_4G)
    else:
        Datos_Claro2["Calidad"] = Datos_Claro2["NetworkTech"].apply(assign_Result_3G)
        

for i in range(len(Datos_Claro3)):
    if Datos_Claro3.iloc[i]['Red_G']==4.0:
        Datos_Claro3["Calidad"] = Datos_Claro3["NetworkTech"].apply(assign_Result_4G)
    else:
        Datos_Claro3["Calidad"] = Datos_Claro3["NetworkTech"].apply(assign_Result_3G)
        



display(Datos_Claro)
display(Datos_Claro1)
display(Datos_Claro2)
display(Datos_Claro3)
#Varianza
Varianza=Datos_Claro["NetworkTech"].var(ddof=0)
#Desviación estandar
Desviacion_Estandar=Datos_Claro["NetworkTech"].std()
#Promedio
Promedio=Datos_Claro["NetworkTech"].mean()
print(Varianza)#La variación de parametro
print(Desviacion_Estandar)#Cuanto se desvian los parametros entre sí
print(Promedio)#Promedio de la señal
Datos_Claro["NetworkTech"].plot()


#Seccción para leer todo un 
