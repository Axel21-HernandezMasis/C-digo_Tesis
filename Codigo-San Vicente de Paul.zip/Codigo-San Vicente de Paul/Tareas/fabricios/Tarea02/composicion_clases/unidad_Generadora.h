#ifndef UNIDAD_GENERADORA_H_INCLUDED
#define UNIDAD_GENERADORA_H_INCLUDED

#include "fuente_Generadora.h"

class unidad_generadora: public fuente_generadora {
private:
    string nombre_generador;
    string sitio_ubicacion;
    string potencia_placa;
    void ubicacion(void);
public:
    unidad_generadora(string, string, string, string);
    void despliegue_informacion(void);
};

#endif // UNIDAD_GENERADORA_H_INCLUDED
