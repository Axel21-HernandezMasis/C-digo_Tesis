# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import pandas as pd
import glob
import numpy as np
import random
import matplotlib.pyplot as plt



    
    
#******************************************************************************************
pd.options.display.max_rows = 9999
#Edificio A
#ICE

column_names = pd.Series(['Time', 'Longitude', 'Latitude', 'Operador',"Network" , 'NetworkTech', 'Level', "Speed"])


Piso_Siete_ICE = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_ICE\EDIFICIO_A_PISO_7\ICE_2023.11.25_14.14.57\ICE_2023.11.25_14.14.57.txt", sep=';', decimal=',') 

Piso_Siete_ICE.fillna(0, inplace = True)

Piso_Seis_ICE = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_ICE\EDIFICIO_A_PISO_6\ICE_2023.11.25_14.17.49\ICE_2023.11.25_14.17.49.txt", sep=';', decimal=',') 
Piso_Seis_ICE.fillna(0, inplace = True)

Piso_Cinco_ICE = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_ICE\EDIFICIO_A_PISO_5\ICE_2023.11.25_14.21.18\ICE_2023.11.25_14.21.18.txt", sep=';', decimal=',') 
Piso_Cinco_ICE.fillna(0, inplace = True)

Piso_Cuatro_ICE = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_ICE\EDIFICIO_A_PISO_4\ICE_2023.11.25_14.24.29\ICE_2023.11.25_14.24.29.txt", sep=';', decimal=',') 
Piso_Cuatro_ICE.fillna(0, inplace = True)
#print(df.info())
Piso_Tres_ICE = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_ICE\EDIFICIO_A_PISO_3\ICE_2023.11.25_14.27.50\ICE_2023.11.25_14.27.50.txt", sep=';', decimal=',')
Piso_Tres_ICE.fillna(0, inplace = True)

Piso_Uno_ICE = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_ICE\EDIFICIO_A_PISO_1\ICE_2023.11.25_14.38.49\ICE_2023.11.25_14.38.49.txt", sep=';', decimal=',')  
Piso_Uno_ICE.fillna(0, inplace = True)

#Claro
Piso_Siete_CLARO = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_CLARO\EDIFICIO_A_PISO_7\Claro_2023.11.25_14.14.52\Claro_2023.11.25_14.14.52.txt", sep=';', decimal=',') 
Piso_Siete_CLARO.fillna(0, inplace = True)

Piso_Seis_CLARO = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_CLARO\EDIFICIO_A_PISO_6\Claro_2023.11.25_14.17.43\Claro_2023.11.25_14.17.43.txt", sep=';', decimal=',') 
Piso_Seis_CLARO.fillna(0, inplace = True)

Piso_Cinco_CLARO = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_CLARO\EDIFICIO_A_PISO_5\Claro_2023.11.25_14.21.12\Claro_2023.11.25_14.21.12.txt", sep=';', decimal=',') 
Piso_Cinco_CLARO.fillna(0, inplace = True)

Piso_Cuatro_CLARO = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_CLARO\EDIFICIO_A_PISO_4\Claro_2023.11.25_14.24.22\Claro_2023.11.25_14.24.22.txt", sep=';', decimal=',') 
Piso_Cuatro_CLARO.fillna(0, inplace = True)

Piso_Tres_CLARO = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_CLARO\EDIFICIO_A_PISO_3\Claro_2023.11.25_14.27.55\Claro_2023.11.25_14.27.55.txt", sep=';', decimal=',') 
Piso_Tres_CLARO.fillna(0, inplace = True)

Piso_Uno_CLARO = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_CLARO\EDIFICIO_A_PISO_1\Claro_2023.11.25_14.38.44\Claro_2023.11.25_14.38.44.txt", sep=';', decimal=',') 
Piso_Uno_CLARO.fillna(0, inplace = True)

#Liberty
Piso_Siete_Liberty = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_LIBERTY\EDIFICIO_A_PISO_7\LIBERTY_2023.11.25_13.00.40\LIBERTY_2023.11.25_13.00.40.txt", sep=';', decimal=',') 
Piso_Siete_Liberty.fillna(0, inplace = True)

Piso_Seis_Liberty = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_LIBERTY\EDIFICIO_A_PISO_6\LIBERTY_2023.11.25_13.04.24\LIBERTY_2023.11.25_13.04.24.txt", sep=';', decimal=',') 
Piso_Seis_Liberty.fillna(0, inplace = True)

Piso_Cinco_Liberty = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_LIBERTY\EDIFICIO_A_PISO_5\LIBERTY_2023.11.25_13.07.52\LIBERTY_2023.11.25_13.07.52.txt", sep=';', decimal=',') 
Piso_Cinco_Liberty.fillna(0, inplace = True)

Piso_Cuatro_Liberty = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_LIBERTY\EDIFICIO_A_PISO_4\LIBERTY_2023.11.25_13.11.49\LIBERTY_2023.11.25_13.11.49.txt", sep=';', decimal=',') 
Piso_Cuatro_Liberty.fillna(0, inplace = True)

Piso_Tres_Liberty = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_LIBERTY\EDIFICIO_A_PISO_3\LIBERTY_2023.11.25_13.15.28\LIBERTY_2023.11.25_13.15.28.txt", sep=';', decimal=',') 
Piso_Tres_Liberty.fillna(0, inplace = True)

Piso_Uno_Liberty = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_LIBERTY\EDIFICIO_A_PISO_1\LIBERTY_2023.11.25_13.28.49\LIBERTY_2023.11.25_13.28.49.txt", sep=';', decimal=',') 
Piso_Uno_Liberty.fillna(0, inplace = True)

#******************************************************************************************

#Edificio B

#CLARO

Piso_Claro_B_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_B\Claro_2023.11.04_15.56.11\Claro_2023.11.04_15.56.11.txt", sep=';', decimal=',')
Piso_Claro_B_3.fillna(0, inplace = True)

Piso_Claro_B_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_B\Claro_2023.11.04_15.56.11\Claro_2023.11.04_15.56.11.txt", sep=';', decimal=',')
Piso_Claro_B_1.fillna(0, inplace = True)

Piso_Claro_B_PB = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_San_Vicente_de_Paul\Mediciones_2_4G_Claro_\Edificio_B\Claro_2023.11.04_15.56.11\Claro_2023.11.04_15.56.11.txt", sep=';', decimal=',')
Piso_Claro_B_PB.fillna(0, inplace = True)

#ICE

Piso_Kolbi_B_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_ICE\EDIFICIO_B_PISO_3\ICE_2023.11.25_14.31.43\ICE_2023.11.25_14.31.43.txt", sep=';', decimal=',')
Piso_Kolbi_B_3.fillna(0, inplace = True)

Piso_Kolbi_B_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_ICE\EDIFICIO_B_PISO_1\ICE_2023.11.25_14.42.47\ICE_2023.11.25_14.42.47.txt", sep=';', decimal=',')
Piso_Kolbi_B_1.fillna(0, inplace = True)

Piso_Kolbi_B_PB = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_ICE\EDIFICIO_B_PB\ICE_2023.11.25_14.47.21\ICE_2023.11.25_14.47.21.txt", sep=';', decimal=',')
Piso_Kolbi_B_PB.fillna(0, inplace = True)
#LIBERTY

Piso_Liberty_B_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_LIBERTY\EDIFICIO_B_PISO_3\LIBERTY_2023.11.25_13.23.31\LIBERTY_2023.11.25_13.23.31.txt", sep=';', decimal=',')
Piso_Liberty_B_3.fillna(0, inplace = True)

Piso_Liberty_B_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_LIBERTY\EDIFICIO_B_PISO_1\LIBERTY_2023.11.25_13.34.38\LIBERTY_2023.11.25_13.34.38.txt", sep=';', decimal=',')
Piso_Liberty_B_1.fillna(0, inplace = True)

Piso_Liberty_B_PB = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_LIBERTY\EDIFICIO_B_PB\LIBERTY_2023.11.25_13.40.22\LIBERTY_2023.11.25_13.40.22.txt", sep=';', decimal=',')
Piso_Liberty_B_PB.fillna(0, inplace = True)

#******************************************************************************************
#Edificio C

Piso_Claro_C_FARMACIA = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_CLARO\EDIFICIO_C_FARMACIA\Claro_2023.11.25_14.51.50\Claro_2023.11.25_14.51.50.txt", sep=';', decimal=',')
Piso_Claro_C_FARMACIA.fillna(0, inplace = True)

Piso_Claro_C_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_CLARO\EDIFICIO_C_PISO_1\Claro_2023.11.25_14.53.54\Claro_2023.11.25_14.53.54.txt", sep=';', decimal=',')
Piso_Claro_C_1.fillna(0, inplace = True)

Piso_Kolbi_C_FARMACIA = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_ICE\EDIFICIO_C_FARMACIA\ICE_2023.11.25_14.51.42\ICE_2023.11.25_14.51.42.txt", sep=';', decimal=',')
Piso_Kolbi_C_FARMACIA.fillna(0, inplace = True)

Piso_Kolbi_C_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_ICE\EDIFICIO_C_PISO_1\ICE_2023.11.25_14.54.00\ICE_2023.11.25_14.54.00.txt", sep=';', decimal=',')
Piso_Kolbi_C_1.fillna(0, inplace = True)

Piso_Liberty_C_FARMACIA = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_LIBERTY\EDIFICIO_C_FARMACIA\LIBERTY_2023.11.25_13.42.50\LIBERTY_2023.11.25_13.42.50.txt", sep=';', decimal=',')
Piso_Liberty_C_FARMACIA.fillna(0, inplace = True)

Piso_Liberty_C_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_LIBERTY\EDIFICIO_C_PISO_1\LIBERTY_2023.11.25_13.45.21\LIBERTY_2023.11.25_13.45.21.txt", sep=';', decimal=',')
Piso_Liberty_C_1.fillna(0, inplace = True)


#******************************************************************************************
#Edificio R


#Piso R
Piso_Claro_R_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_CLARO\EDIFICIO_R_PISO_3\Claro_2023.11.25_15.05.03\Claro_2023.11.25_15.05.03.txt", sep=';', decimal=',')
Piso_Claro_R_3.fillna(0, inplace = True)

#Piso 1
Piso_Claro_R_2 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_CLARO\EDIFICIO_R_PISO_2\Claro_2023.11.25_15.06.20\Claro_2023.11.25_15.06.20.txt", sep=';', decimal=',')
Piso_Claro_R_2.fillna(0, inplace = True)
#Piso 2
Piso_Claro_R_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_CLARO\EDIFICIO_R_PISO_1\Claro_2023.11.25_15.08.39\Claro_2023.11.25_15.08.39.txt", sep=';', decimal=',')
Piso_Claro_R_1.fillna(0, inplace = True)

Piso_Kolbi_R_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_ICE\EDIFICIO_R_PISO_3\ICE_2023.11.25_15.05.09\ICE_2023.11.25_15.05.09.txt", sep=';', decimal=',')
Piso_Kolbi_R_3.fillna(0, inplace = True)
#Piso 1
Piso_Kolbi_R_2 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_ICE\EDIFICIO_R_PISO_2\ICE_2023.11.25_15.06.13\ICE_2023.11.25_15.06.13.txt", sep=';', decimal=',')
Piso_Kolbi_R_2.fillna(0, inplace = True)
#Piso 2
Piso_Kolbi_R_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_ICE\EDIFICIO_R_PISO_1\ICE_2023.11.25_15.08.46\ICE_2023.11.25_15.08.46.txt", sep=';', decimal=',')
Piso_Kolbi_R_1.fillna(0, inplace = True)
#Piso D0 E0

Piso_Liberty_R_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_LIBERTY\EDIFICIO_R_PISO_3\LIBERTY_2023.11.25_13.56.49\LIBERTY_2023.11.25_13.56.49.txt", sep=';', decimal=',')
Piso_Liberty_R_3.fillna(0, inplace = True)
#Piso 1
Piso_Liberty_R_2 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_LIBERTY\EDIFICIO_R_PISO_2\LIBERTY_2023.11.25_13.58.30\LIBERTY_2023.11.25_13.58.30.txt", sep=';', decimal=',')
Piso_Liberty_R_2.fillna(0, inplace = True)
#Piso 2
Piso_Liberty_R_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_LIBERTY\EDIFICIO_R_PISO_1\LIBERTY_2023.11.25_14.01.26\LIBERTY_2023.11.25_14.01.26.txt", sep=';', decimal=',')
Piso_Liberty_R_1.fillna(0, inplace = True)

#Piso D0 E0
 



 

#Funciones
def Limpiar(marks):
    b=[]
    m=len(marks.index)
    for j in range(m):
        Filaaux=marks.iloc[j,0]
        Filaaux=Filaaux.split()
        b.append(Filaaux)
    Datos=pd.DataFrame(b,columns=column_names)
    Datos.loc[Datos["Network"] == "4G", "Red_G"] = 4

    Datos.loc[Datos["Network"] == "3G", "Red_G"] = 3

    Datos.drop(Datos[(Datos['Red_G']==3)].index, inplace =True) #Elimina el 3G
    Datos.drop(['Time', 'Longitude', 'Latitude','Network','Level' ], axis=1, inplace=True)
    Datos["NetworkTech"]=Datos["NetworkTech"].astype(float)
    Datos["Speed"]=Datos["Speed"].astype(float)
    
    return Datos

def assign_Result_4G(marks):
    
    if marks <= -60 and marks >= -80 :
        result = "Excelente"    
    elif marks <= -80 and marks >= -90 :
        result = "Buena" 
    elif marks <= -90 and marks >= -95 :
        result = "Mala"  
    elif  marks <= -96 and marks >= -100 :
        result = "Fuera del Umbral"
    elif marks <= -101 :
        result = "Señal Muerta"  
    else:
        result = "Error"
    return result

def assign_Result_3G(marks):
    
    if marks <= -60.0 and marks >= -85.0 :
        result = "Buena" 
    elif marks <= -86.0 and marks >= -100.0 :
        result = "Justa"  
    elif  marks <= -101.0 and marks >= -109.0 :
        result = "Mala" 
        
   
    elif marks <= -110.0 :
        result = "Muera" 
        
  
    else:
        result = "Error"
    return result

def assign_3G_or_4G(marks):
    for i in range(len(marks)):
        if marks.iloc[i]['Red_G']==4.0:
            marks["Calidad_4G"] = marks["NetworkTech"].apply(assign_Result_4G)
            
        elif marks.iloc[i]['Red_G']==3.0:
            marks["Calidad_3G"] = marks["NetworkTech"].apply(assign_Result_3G)
            
             
    return marks

def Mala_cobertura(marks):
    x=0 
    for i in range(len(marks["Calidad_4G"])):
        if marks.iloc[i]["Calidad_4G"]=="Mala":
            x=x+1
        if marks.iloc[i]["Calidad_4G"]=="Muerta":
            x=x+1
    print(""""Se encontraron los siguientes problemas de cobertura:""",x,"""
          respecto a las siguientes mediciones:""",len(marks["Calidad_4G"]))
        

        
def Datos_Finales(marks):
 #   display(marks)
    Varianza=marks["NetworkTech"].var(ddof=0)
    Desviacion_Estandar=marks["NetworkTech"].std()
    Promedio_Cobertura=marks["NetworkTech"].mean()
    Promedio_Velocidad=marks["Speed"].mean()
    print("La varianza de la cobertura es:",Varianza)#La variación de parametro
    print("La Desviacion estandar es:",Desviacion_Estandar)#Cuanto se desvian los parametros entre sí
    print("El promedio de cobertura es",Promedio_Cobertura)#Promedio de la señal
    print("El promedio de ancho de banda",Promedio_Velocidad,"kbps")#Promedio de la señal
    Mala_cobertura(marks)
    # marks["NetworkTech"].plot()
    
    


    
#********************************************************************************

    

print("*******************************************************")
print("Edificio A-Claro")
#Pisol
Piso_Uno_CLARO=Limpiar(Piso_Uno_CLARO)
Piso_Uno_CLARO=assign_3G_or_4G(Piso_Uno_CLARO)
Datos_Finales(Piso_Uno_CLARO)




print("*******************************************************")
print("Edificio A_3-Claro")
#Piso3
Piso_Tres_CLARO=Limpiar(Piso_Tres_CLARO)
Piso_Tres_CLARO=assign_3G_or_4G(Piso_Tres_CLARO)
Datos_Finales(Piso_Tres_CLARO)

plt.show()

print("*******************************************************")
print("Edificio A_4-Claro")
#Piso4
Piso_Cuatro_CLARO=Limpiar(Piso_Cuatro_CLARO)
Piso_Cuatro_CLARO=assign_3G_or_4G(Piso_Cuatro_CLARO)
Datos_Finales(Piso_Cuatro_CLARO)

print("*******************************************************")
print("Edificio A_5-Claro")
#Piso5
Piso_Cinco_CLARO=Limpiar(Piso_Cinco_CLARO)
Piso_Cinco_CLARO=assign_3G_or_4G(Piso_Cinco_CLARO)
Datos_Finales(Piso_Cinco_CLARO)

print("*******************************************************")
print("Edificio A_6-Claro")
#Piso5
Piso_Seis_CLARO=Limpiar(Piso_Seis_CLARO)
Piso_Seis_CLARO=assign_3G_or_4G(Piso_Seis_CLARO)
Datos_Finales(Piso_Seis_CLARO)

print("*******************************************************")
print("Edificio A_7-Claro")
#Piso5
Piso_Siete_CLARO=Limpiar(Piso_Siete_CLARO)
Piso_Siete_CLARO=assign_3G_or_4G(Piso_Siete_CLARO)
Datos_Finales(Piso_Siete_CLARO)


#********************************************************************************
print("*******************************************************")
print("Edificio A_1-ICE ")

Piso_Uno_ICE=Limpiar(Piso_Uno_ICE)
Piso_Uno_ICE=assign_3G_or_4G(Piso_Uno_ICE)
Datos_Finales(Piso_Uno_ICE)



print("*******************************************************")
print("Edificio A_3-ICE ")
#Piso3
Piso_Tres_ICE=Limpiar(Piso_Tres_ICE)
Piso_Tres_ICE=assign_3G_or_4G(Piso_Tres_ICE)
Datos_Finales(Piso_Tres_ICE)

print("*******************************************************")
print("Edificio A_4-ICE ")
#Piso4
Piso_Cuatro_ICE=Limpiar(Piso_Cuatro_ICE)
Piso_Cuatro_ICE=assign_3G_or_4G(Piso_Cuatro_ICE)
Datos_Finales(Piso_Cuatro_ICE)

print("*******************************************************")
print("Edificio A_5-ICE ")
#Piso2
Piso_Cinco_ICE=Limpiar(Piso_Cinco_ICE)
Piso_Cinco_ICE=assign_3G_or_4G(Piso_Cinco_ICE)
Datos_Finales(Piso_Cinco_ICE)

print("*******************************************************")
print("Edificio A_6-ICE ")
#Piso2
Piso_Seis_ICE=Limpiar(Piso_Seis_ICE)
Piso_Seis_ICE=assign_3G_or_4G(Piso_Seis_ICE)
Datos_Finales(Piso_Seis_ICE)

print("*******************************************************")
print("Edificio A_7-ICE ")
#Piso2
Piso_Siete_ICE=Limpiar(Piso_Siete_ICE)
Piso_Siete_ICE=assign_3G_or_4G(Piso_Siete_ICE)
Datos_Finales(Piso_Siete_ICE)


print("*******************************************************")
print("Edificio A_1-Liberty ")

Piso_Uno_Liberty=Limpiar(Piso_Uno_Liberty)
Piso_Uno_Liberty=assign_3G_or_4G(Piso_Uno_Liberty)
Datos_Finales(Piso_Uno_Liberty)


print("*******************************************************")
print("Edificio A_3-Liberty ")
#Piso3
Piso_Tres_Liberty=Limpiar(Piso_Tres_Liberty)
Piso_Tres_Liberty=assign_3G_or_4G(Piso_Tres_Liberty)
Datos_Finales(Piso_Tres_Liberty)


print("*******************************************************")
print("Edificio A_4-Liberty ")
#Piso4
Piso_Cuatro_Liberty=Limpiar(Piso_Cuatro_Liberty)
Piso_Cuatro_Liberty=assign_3G_or_4G(Piso_Cuatro_Liberty)
Datos_Finales(Piso_Cuatro_Liberty)


print("*******************************************************")
print("Edificio A_5-Liberty ")
#Piso2
Piso_Cinco_Liberty=Limpiar(Piso_Cinco_Liberty)
Piso_Cinco_Liberty=assign_3G_or_4G(Piso_Cinco_Liberty)
Datos_Finales(Piso_Cinco_Liberty)

print("*******************************************************")
print("Edificio A_6-Liberty ")
#Piso2
Piso_Seis_Liberty=Limpiar(Piso_Seis_Liberty)
Piso_Seis_Liberty=assign_3G_or_4G(Piso_Seis_Liberty)
Datos_Finales(Piso_Seis_Liberty)

print("*******************************************************")
print("Edificio A_7-Liberty ")
#Piso2
Piso_Siete_Liberty=Limpiar(Piso_Siete_Liberty)
Piso_Siete_Liberty=assign_3G_or_4G(Piso_Siete_Liberty)
Datos_Finales(Piso_Siete_Liberty)



print("*******************************************************")
print("Edificio B_P3-Claro ")

Piso_Claro_B_3=Limpiar(Piso_Claro_B_3)
Piso_Claro_B_3=assign_3G_or_4G(Piso_Claro_B_3)
Datos_Finales(Piso_Claro_B_3)

print("*******************************************************")
print("Edificio B_P1-Claro ")

Piso_Claro_B_1=Limpiar(Piso_Claro_B_1)
Piso_Claro_B_1=assign_3G_or_4G(Piso_Claro_B_1)
Datos_Finales(Piso_Claro_B_1)

print("*******************************************************")
print("Edificio B_PB-Claro ")

Piso_Claro_B_PB=Limpiar(Piso_Claro_B_PB)
Piso_Claro_B_PB=assign_3G_or_4G(Piso_Claro_B_PB)
Datos_Finales(Piso_Claro_B_PB)


print("*******************************************************")
print("Edificio B_P3-Kolbi ")
Piso_Kolbi_B_3=Limpiar(Piso_Kolbi_B_3)
Piso_Kolbi_B_3=assign_3G_or_4G(Piso_Kolbi_B_3)
Datos_Finales(Piso_Kolbi_B_3)

print("*******************************************************")
print("Edificio B_P1-Kolbi ")
Piso_Kolbi_B_1=Limpiar(Piso_Kolbi_B_1)
Piso_Kolbi_B_1=assign_3G_or_4G(Piso_Kolbi_B_1)
Datos_Finales(Piso_Kolbi_B_1)

print("*******************************************************")
print("Edificio B_PB-Kolbi ")
Piso_Kolbi_B_PB=Limpiar(Piso_Kolbi_B_PB)
Piso_Kolbi_B_PB=assign_3G_or_4G(Piso_Kolbi_B_PB)
Datos_Finales(Piso_Kolbi_B_PB)


print("*******************************************************")
print("Edificio B_P3-Liberty ")
Piso_Liberty_B_3=Limpiar(Piso_Liberty_B_3)
Piso_Liberty_B_3=assign_3G_or_4G(Piso_Liberty_B_3)
Datos_Finales(Piso_Liberty_B_3)

print("*******************************************************")
print("Edificio B_P1-Liberty ")
Piso_Liberty_B_1=Limpiar(Piso_Liberty_B_1)
Piso_Liberty_B_1=assign_3G_or_4G(Piso_Liberty_B_1)
Datos_Finales(Piso_Liberty_B_1)

print("*******************************************************")
print("Edificio B_PB-Liberty ")
Piso_Liberty_B_PB=Limpiar(Piso_Liberty_B_PB)
Piso_Liberty_B_PB=assign_3G_or_4G(Piso_Liberty_B_PB)
Datos_Finales(Piso_Liberty_B_PB)



print("*******************************************************")
print("Edificio R_1-Claro ")
Piso_Claro_R_1=Limpiar(Piso_Claro_R_1)
Piso_Claro_R_1=assign_3G_or_4G(Piso_Claro_R_1)
Datos_Finales(Piso_Claro_R_1)

print("*******************************************************")
print("Edificio R_2-Claro ")
Piso_Claro_R_2=Limpiar(Piso_Claro_R_2)
Piso_Claro_R_2=assign_3G_or_4G(Piso_Claro_R_2)
Datos_Finales(Piso_Claro_R_2)

print("*******************************************************")
print("Edificio R_3-Claro ")
Piso_Claro_R_3=Limpiar(Piso_Claro_R_3)
Piso_Claro_R_3=assign_3G_or_4G(Piso_Claro_R_3)
Datos_Finales(Piso_Claro_R_3)


print("*******************************************************")
print("Edificio R_1-ICE ")
Piso_Kolbi_R_1=Limpiar(Piso_Kolbi_R_1)
Piso_Kolbi_R_1=assign_3G_or_4G(Piso_Kolbi_R_1)
Datos_Finales(Piso_Kolbi_R_1)

print("*******************************************************")
print("Edificio R_2-ICE ")
Piso_Kolbi_R_2=Limpiar(Piso_Kolbi_R_2)
Piso_Kolbi_R_2=assign_3G_or_4G(Piso_Kolbi_R_2)
Datos_Finales(Piso_Kolbi_R_2)

print("*******************************************************")
print("Edificio R_3-ICE ")
Piso_Kolbi_R_3=Limpiar(Piso_Kolbi_R_3)
Piso_Kolbi_R_3=assign_3G_or_4G(Piso_Kolbi_R_3)
Datos_Finales(Piso_Kolbi_R_3)



print("*******************************************************")
print("Edificio R_1-Libery ")

Piso_Liberty_R_1=Limpiar(Piso_Liberty_R_1)
Piso_Liberty_R_1=assign_3G_or_4G(Piso_Liberty_R_1)
Datos_Finales(Piso_Liberty_R_1)

print("*******************************************************")
print("Edificio R_2-Libery ")
Piso_Liberty_R_2=Limpiar(Piso_Liberty_R_2)
Piso_Liberty_R_2=assign_3G_or_4G(Piso_Liberty_R_2)
Datos_Finales(Piso_Liberty_R_2)

print("*******************************************************")
print("Edificio R_3-Libery ")
Piso_Liberty_R_3=Limpiar(Piso_Liberty_R_3)
Piso_Liberty_R_3=assign_3G_or_4G(Piso_Liberty_R_3)
Datos_Finales(Piso_Liberty_R_3)


print("*******************************************************")
print("Edificio C_FARMACIA-CLARO ")

Piso_Claro_C_FARMACIA=Limpiar(Piso_Claro_C_FARMACIA)
Piso_Claro_C_FARMACIA=assign_3G_or_4G(Piso_Claro_C_FARMACIA)
Datos_Finales(Piso_Claro_C_FARMACIA)

print("*******************************************************")
print("Edificio C_1-CLARO ")

Piso_Claro_C_1=Limpiar(Piso_Claro_C_1)
Piso_Claro_C_1=assign_3G_or_4G(Piso_Claro_C_1)
Datos_Finales(Piso_Claro_C_1)

print("*******************************************************")
print("Edificio C_FARMACIA-Kolbi ")

Piso_Kolbi_C_FARMACIA=Limpiar(Piso_Kolbi_C_FARMACIA)
Piso_Kolbi_C_FARMACIA=assign_3G_or_4G(Piso_Kolbi_C_FARMACIA)
Datos_Finales(Piso_Kolbi_C_FARMACIA)

print("*******************************************************")
print("Edificio C_1-Kolbi  ")

Piso_Kolbi_C_1=Limpiar(Piso_Kolbi_C_1)
Piso_Kolbi_C_1=assign_3G_or_4G(Piso_Kolbi_C_1)
Datos_Finales(Piso_Kolbi_C_1)

print("*******************************************************")
print("Edificio C_FARMACIA-Liberty ")

Piso_Liberty_C_FARMACIA=Limpiar(Piso_Liberty_C_FARMACIA)
Piso_Liberty_C_FARMACIA=assign_3G_or_4G(Piso_Liberty_C_FARMACIA)
Datos_Finales(Piso_Liberty_C_FARMACIA)

print("*******************************************************")
print("Edificio C_1-Liberty  ")

Piso_Liberty_C_1=Limpiar(Piso_Liberty_C_1)
Piso_Liberty_C_1=assign_3G_or_4G(Piso_Liberty_C_1)
Datos_Finales(Piso_Liberty_C_1)


print("**-----------*Sección de plts*------------**")
 #Seccion Plt
#Piso 1 edificio A
Piso_Uno_CLARO.plot(kind = 'scatter', x = 'NetworkTech', y = 'Speed', color = 'r', label = "Claro")
plt.scatter(Piso_Uno_ICE["NetworkTech"],Piso_Uno_ICE["Speed"], color = 'g',label = "ICE")
plt.scatter(Piso_Uno_Liberty["NetworkTech"],Piso_Uno_Liberty["Speed"], color = 'b',label = "Liberty")

plt.legend()
plt.title("Piso 1 Edificio A")
plt.show()

#Piso 3 edificio A
Piso_Tres_CLARO.plot(kind = 'scatter', x = 'NetworkTech', y = 'Speed', color = 'r', label = "Claro")
plt.scatter(Piso_Tres_ICE["NetworkTech"],Piso_Tres_ICE["Speed"], color = 'g',label = "ICE")
plt.scatter(Piso_Tres_Liberty["NetworkTech"],Piso_Tres_Liberty["Speed"], color = 'b',label = "Liberty")

plt.legend()
plt.title("Piso 3 Edificio A")
plt.show()

#Piso 4 edificio A
Piso_Cuatro_CLARO.plot(kind = 'scatter', x = 'NetworkTech', y = 'Speed', color = 'r', label = "Claro")
plt.scatter(Piso_Cuatro_ICE["NetworkTech"],Piso_Cuatro_ICE["Speed"], color = 'g',label = "ICE")
plt.scatter(Piso_Cuatro_Liberty["NetworkTech"],Piso_Cuatro_Liberty["Speed"], color = 'b',label = "Liberty")

plt.legend()
plt.title("Piso 4 Edificio A")
plt.show()

#Piso 5 edificio A

Piso_Cinco_CLARO.plot(kind = 'scatter', x = 'NetworkTech', y = 'Speed', color = 'r', label = "Claro")
plt.scatter(Piso_Cinco_ICE["NetworkTech"],Piso_Cinco_ICE["Speed"], color = 'g',label = "ICE")
plt.scatter(Piso_Cinco_Liberty["NetworkTech"],Piso_Cinco_Liberty["Speed"], color = 'b',label = "Liberty")

plt.legend()
plt.title("Piso 5 Edificio A")
plt.show()

#Piso 6 edificio A

Piso_Seis_CLARO.plot(kind = 'scatter', x = 'NetworkTech', y = 'Speed', color = 'r', label = "Claro")
plt.scatter(Piso_Seis_ICE["NetworkTech"],Piso_Seis_ICE["Speed"], color = 'g',label = "ICE")
plt.scatter(Piso_Seis_Liberty["NetworkTech"],Piso_Seis_Liberty["Speed"], color = 'b',label = "Liberty")

plt.legend()
plt.title("Piso 6 Edificio A")
plt.show()

#Piso 7 edificio A

Piso_Siete_CLARO.plot(kind = 'scatter', x = 'NetworkTech', y = 'Speed', color = 'r', label = "Claro")
plt.scatter(Piso_Siete_ICE["NetworkTech"],Piso_Siete_ICE["Speed"], color = 'g',label = "ICE")
plt.scatter(Piso_Siete_Liberty["NetworkTech"],Piso_Siete_Liberty["Speed"], color = 'b',label = "Liberty")

plt.legend()
plt.title("Piso 7 Edificio A")
plt.show()

#Piso B edificio 3

Piso_Claro_B_3.plot(kind = 'scatter', x = 'NetworkTech', y = 'Speed', color = 'r', label = "Claro")
plt.scatter(Piso_Kolbi_B_3["NetworkTech"],Piso_Kolbi_B_3["Speed"], color = 'g',label = "ICE")
plt.scatter(Piso_Liberty_B_3["NetworkTech"],Piso_Liberty_B_3["Speed"], color = 'b',label = "Liberty")

plt.legend()
plt.title("Piso 3 Edificio B")
plt.show()

#Piso B edificio 1

Piso_Claro_B_1.plot(kind = 'scatter', x = 'NetworkTech', y = 'Speed', color = 'r', label = "Claro")
plt.scatter(Piso_Kolbi_B_1["NetworkTech"],Piso_Kolbi_B_1["Speed"], color = 'g',label = "ICE")
plt.scatter(Piso_Liberty_B_1["NetworkTech"],Piso_Liberty_B_1["Speed"], color = 'b',label = "Liberty")

plt.legend()
plt.title("Piso 1 Edificio B")
plt.show()

#Piso B edificio PB

Piso_Claro_B_PB.plot(kind = 'scatter', x = 'NetworkTech', y = 'Speed', color = 'r', label = "Claro")
plt.scatter(Piso_Kolbi_B_PB["NetworkTech"],Piso_Kolbi_B_PB["Speed"], color = 'g',label = "ICE")
plt.scatter(Piso_Liberty_B_PB["NetworkTech"],Piso_Liberty_B_PB["Speed"], color = 'b',label = "Liberty")

plt.legend()
plt.title("Piso PB Edificio B")
plt.show()

#Piso Farmacia edificio C

Piso_Claro_C_FARMACIA.plot(kind = 'scatter', x = 'NetworkTech', y = 'Speed', color = 'r', label = "Claro")
plt.scatter(Piso_Kolbi_C_FARMACIA["NetworkTech"],Piso_Kolbi_C_FARMACIA["Speed"], color = 'g',label = "ICE")
plt.scatter(Piso_Liberty_C_FARMACIA["NetworkTech"],Piso_Liberty_C_FARMACIA["Speed"], color = 'b',label = "Liberty")

plt.legend()
plt.title("Piso Farmacia Edificio C")
plt.show()

#Piso 1 edificio C

Piso_Claro_C_1.plot(kind = 'scatter', x = 'NetworkTech', y = 'Speed', color = 'r', label = "Claro")
plt.scatter(Piso_Kolbi_C_1["NetworkTech"],Piso_Kolbi_C_1["Speed"], color = 'g',label = "ICE")
plt.scatter(Piso_Liberty_C_1["NetworkTech"],Piso_Liberty_C_1["Speed"], color = 'b',label = "Liberty")

plt.legend()
plt.title("Piso 1 Edificio C")
plt.show()



#Piso 3 edificio R

Piso_Claro_R_3.plot(kind = 'scatter', x = 'NetworkTech', y = 'Speed', color = 'r', label = "Claro")
plt.scatter(Piso_Kolbi_R_3["NetworkTech"],Piso_Kolbi_R_3["Speed"], color = 'g',label = "ICE")
plt.scatter(Piso_Liberty_R_3["NetworkTech"],Piso_Liberty_R_3["Speed"], color = 'b',label = "Liberty")

plt.legend()
plt.title("Piso 3 Edificio R")
plt.show()


#Piso 2 edificio R

Piso_Claro_R_2.plot(kind = 'scatter', x = 'NetworkTech', y = 'Speed', color = 'r', label = "Claro")
plt.scatter(Piso_Kolbi_R_2["NetworkTech"],Piso_Kolbi_R_2["Speed"], color = 'g',label = "ICE")
plt.scatter(Piso_Liberty_R_2["NetworkTech"],Piso_Liberty_R_2["Speed"], color = 'b',label = "Liberty")

plt.legend()
plt.title("Piso 2 Edificio R")
plt.show()

#Piso 1 edificio R

Piso_Claro_R_1.plot(kind = 'scatter', x = 'NetworkTech', y = 'Speed', color = 'r', label = "Claro")
plt.scatter(Piso_Kolbi_R_1["NetworkTech"],Piso_Kolbi_R_1["Speed"], color = 'g',label = "ICE")
plt.scatter(Piso_Liberty_R_1["NetworkTech"],Piso_Liberty_R_1["Speed"], color = 'b',label = "Liberty")

plt.legend()
plt.title("Piso 1 Edificio R")
plt.show()