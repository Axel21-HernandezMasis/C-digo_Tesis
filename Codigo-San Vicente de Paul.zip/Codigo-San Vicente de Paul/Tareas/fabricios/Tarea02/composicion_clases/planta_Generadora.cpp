#include <iostream>
#include <list>

using namespace std;

#include "unidad_Generadora.h"
#include "fuente_Generadora.h"
#include "planta_Generadora.h"

planta_generadora::planta_generadora(string nombre_p, string sitio_u)
{
    nombre_planta = nombre_p;
    ubicacion_planta = sitio_u;
};

void planta_generadora::insertar_componentes(unidad_generadora unidad_i)
{
    unidades_generadoras.push_back(unidad_i);
};

void planta_generadora::mostrar_componentes(void)
{
    list<unidad_generadora>::iterator first = unidades_generadoras.begin();
    list<unidad_generadora>::iterator last = unidades_generadoras.end();

    for (first = unidades_generadoras.begin(); first != last; ++first){
        first->mostrar_ubicacion();
        first->despliegue_informacion();
    };

};

void planta_generadora::despliegue_informacion(void)
{
    cout << "Nombre de la planta generadora: " << nombre_planta << endl;
    cout << "Ubicacion de la planta generadora: " << ubicacion_planta << "\n" << endl;
};
