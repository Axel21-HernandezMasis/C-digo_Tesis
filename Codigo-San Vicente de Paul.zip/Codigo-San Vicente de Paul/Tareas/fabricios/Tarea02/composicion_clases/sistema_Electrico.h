#ifndef SISTEMA_ELECTRICO_H_INCLUDED
#define SISTEMA_ELECTRICO_H_INCLUDED

#include <list>
#include "planta_Generadora.h"

class Sistema_Electrico{
private:
    list<planta_generadora> plantas_generadoras;
public:
    Sistema_Electrico(void);
    void insertar_datos(planta_generadora);
    void mostrar_datos(void);
};

#endif // SISTEMA_ELECTRICO_H_INCLUDED
