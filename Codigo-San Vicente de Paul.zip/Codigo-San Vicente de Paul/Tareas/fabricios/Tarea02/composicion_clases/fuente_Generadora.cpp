#include <iostream>

using namespace std;

#include "fuente_Generadora.h"

fuente_generadora::fuente_generadora(string nombre_f)
{
    nombre_fuente = nombre_f;
};

void fuente_generadora::mostrar_ubicacion(void)
{
    ubicacion();
};

void fuente_generadora::despliegue_informacion(void)
{
    cout << "Nombre de la fuente generadora: " << nombre_fuente << "\n" <<  endl;
};
