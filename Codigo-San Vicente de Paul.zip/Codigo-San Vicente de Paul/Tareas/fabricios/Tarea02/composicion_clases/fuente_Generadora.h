#ifndef FUENTE_GENERADORA_H_INCLUDED
#define FUENTE_GENERADORA_H_INCLUDED

class fuente_generadora{
private:
    string nombre_fuente;
    virtual void ubicacion(void)=0;
public:
    fuente_generadora(string);
    void mostrar_ubicacion(void);
    void despliegue_informacion(void);
};

#endif // FUENTE_GENERADORA_H_INCLUDED
