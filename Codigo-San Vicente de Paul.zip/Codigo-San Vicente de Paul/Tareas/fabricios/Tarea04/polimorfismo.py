'''
Tarea 04

Fabricio Solano Rojas B77447
'''

import sys
from abc import  ABCMeta, abstractmethod
from contextlib import contextmanager

# --------------------------------- Parte I ---------------------------------

'''
++++++++++++++++++++++
+ CLASS USUARIO BASE
++++++++++++++++++++++
'''
class UsuarioBase(metaclass = ABCMeta):
    def __init__(self,propietario, MontoDisponible=0.0):
        self.__propietario = propietario
        self.__MontoDisponible = MontoDisponible
    
    # Métodos polimórficos.
    @abstractmethod
    def AplicarInversion(self):
        pass

    @abstractmethod
    def AsignarOperacion(self):
        pass

    @abstractmethod
    def Print(self):
        pass
    
    @abstractmethod
    def CapturaInformacion(self):
        pass

    def Aplicar(self):
        self.AplicarInversion()
        
    def Asignar(self):
        self.AsignarOperacion()
        
    def __str__(self):
        salida="Propietario: %s\nMontoDisponible: %f\n" % (self.__propietario,
                                                            self.__MontoDisponible)
        return salida+self.Print()
      
    def Captura(self):
        self.CapturaInformacion()
         
    @property
    def propietario(self):
        return self.__propietario
    
    @propietario.setter
    def propietario(self, propietario):
       self.__propietario = propietario
        
    #@property
    def obtener_MontoDisponible(self):
       return self.__MontoDisponible
    
    #@MontoDisponible.setter
    def modificar_MontoDisponible(self, MontoDisponible):
        self.__MontoDisponible = MontoDisponible
        
    # Decorador
    MontoDisponible = property(obtener_MontoDisponible, modificar_MontoDisponible)
        
'''
++++++++++++++++++++++
+ CLASS USUARIO AHORRO
++++++++++++++++++++++
'''
class UsuarioAhorro(UsuarioBase):
    def __init__(self,propietario,MontoDisponible=100.0,Porcentaje=1):
        UsuarioBase.__init__(self, propietario, MontoDisponible)
        self.__Porcentaje = Porcentaje
        self.__MontoAhorro = 0.0
         
    def AplicarInversion(self):
        ahorro = self.MontoDisponible*(self.Porcentaje/100)
        if (self.MontoDisponible - ahorro) >= 0:
            self.__MontoAhorro += ahorro
            self.MontoDisponible -= ahorro
        else:
            print("Monto disponible insuficiente")
        

    def AsignarOperacion(self):
        pass
    
    def Print(self):
        salida = "Porcentaje ahorro: %f\nMontoAhorro: %f\n" % (self.Porcentaje, self.MontoAhorro)
        return salida
      
    def CapturaInformacion(self):
        self.propietario = input("Nombre del propietario:")
        self.MontoDisponible = float(input("MontoDispobile:"))
        self.Porcentaje = float(input("Porcentaje ahorro:"))
    
    @property
    def Porcentaje(self):
        return self.__Porcentaje
    
    @Porcentaje.setter
    def Porcentaje(self,NuevoPorcentaje):
        self.__Porcentaje = NuevoPorcentaje   

    @property
    def MontoAhorro(self):
        return self.__MontoAhorro

'''
++++++++++++++++++++++++++
+ CLASS USUARIO TASA CERO
++++++++++++++++++++++++++
'''
class UsuarioTasaCero(UsuarioBase):
    def __init__(self,propietario,MontoDisponible=100.0):
        UsuarioBase.__init__(self, propietario, MontoDisponible)
        self.__MontoConsumoMes = 0.0
        self.__Plazo = 0
        self.__OperaciónVigente = False

         
    def AplicarInversion(self):
        if self.__OperaciónVigente == True:
            if self.__Plazo > 0:
                if (self.MontoDisponible - self.MontoConsumoMes) >= 0:
                    self.MontoDisponible -= self.MontoConsumoMes
                    self.__Plazo -= 1
                    if self.__Plazo == 0:
                        self.__MontoConsumoMes = 0.0
                        self.__OperaciónVigente = False
                        
                else:
                   print("Fondos insuficientes para pagar cuota de Tasa Cero") 
                
    def AsignarOperacion(self):
        if self.Plazo != 0 and self.MontoConsumoMes != 0.0 and self.__OperaciónVigente == False:
            self.__OperaciónVigente = True
        else:
            print("Error: No se tiene el plazo de nueva operación de Tasa Cero")
    
    def Print(self):
        if self.__OperaciónVigente == False:
            return "No hay operación Tasa Cero vigente"
        else:
            salida = "Plazo: %i\nMonto Consumo por mes: %f\n" % (self.Plazo, self.MontoConsumoMes)
            return salida
              
    def CapturaInformacion(self):
        self.propietario = input("Nombre del propietario:")
        self.MontoDisponible = float(input("MontoDispobile:"))
        self.Plazo = int(input("Plazo:"))
        self.MontoConsumoMes = int(input("Monto Consumo por mes:"))
    
    @property
    def Plazo(self):
        return self.__Plazo
    
    @Plazo.setter
    def Plazo(self,NuevoPlazo):
        if self.__OperaciónVigente == False:
            self.__Plazo = NuevoPlazo
        else:
            print("Hay una operación en proceso")
            
    @property
    def MontoConsumoMes(self):
        return self.__MontoConsumoMes
    
    @MontoConsumoMes.setter
    def MontoConsumoMes(self,NuevoMontoConsumoMes):
        if self.__OperaciónVigente == False:
            self.__MontoConsumoMes = NuevoMontoConsumoMes
        else:
            print("Hay una operación en proceso")
        
'''
+++++++++++++++++++++++++++
+ CLASS SERVICIO PUBLICO
+++++++++++++++++++++++++++
'''
class ServicioPublico(object):
    def __init__(self,EmpresaServicioPublico):
        self.__EmpresaServicioPublico = EmpresaServicioPublico
        self.__CargoAutomatico = 0.0
        self.__OperacionVigente = False
    
    @property
    def EmpresaServicioPublico(self):
        return self.__EmpresaServicioPublico
    
    @EmpresaServicioPublico.setter
    def EmpresaServicioPublico(self,EmpresaServicioPublico):
        self.__EmpresaServicioPublico = EmpresaServicioPublico   
       
    @property
    def CargoAutomatico(self):
        return self.__CargoAutomatico 
    
    @CargoAutomatico.setter
    def CargoAutomatico(self,CargoAutomatico):
        self.__CargoAutomatico = CargoAutomatico   

    @property
    def OperacionVigente(self):
        return self.__OperacionVigente
    
    @OperacionVigente.setter
    def OperacionVigente(self,OperacionVigente):
        self.__OperacionVigente = OperacionVigente
           
    def __str__(self):
        salida = "Empresa: %s\nCargo automático: %f\n" % (self.EmpresaServicioPublico, self.CargoAutomatico)
        return salida
      
    def CapturaInformacion(self):
        self.EmpresaServicioPublico = input("Nombre de empresa:")
        self.CargoAutomatico = float(input("Cargo automático:"))
        
'''
++++++++++++++++++++++++++++++++++
+ CLASS USUARIO SERVICIO PUBLICO
++++++++++++++++++++++++++++++++++
'''   
class UsuarioPagoServicios(UsuarioBase):
    def __init__(self,propietario,MontoDisponible=100.0):
         UsuarioBase.__init__(self, propietario, MontoDisponible)
         self.__Servicios = []
         
    def AplicarInversion(self):
        for i in range(len(self.Servicios)):
            if (self.MontoDisponible - self.Servicios[i].CargoAutomatico) >= 0:
                self.MontoDisponible -= self.Servicios[i].CargoAutomatico
                self.Servicios[i].CargoAutomatico = 0.0
                self.Servicios[i].OperacionVigente = False
            else:
                print("Monto disponible insuficiente")
                 
    def AsignarOperacion(self):
        for i in range(len(self.Servicios)):
            if self.Servicios[i].OperacionVigente == False:
                self.Servicios[i].OperacionVigente = True
            else: 
                print("Existe una operación vigente, no se puede asignar una nueva operación")
    
    def Print(self):
        salida = ""
        for i in range(len(self.Servicios)):
            if self.Servicios[i].OperacionVigente == True:
                salida = salida + str(self.Servicios[i]) + "Saldo pendiente\n"
            else:
                salida = salida + str(self.Servicios[i]) + "No hay saldo pendiente\n"
        return salida
    
    def CapturaInformacion(self):
        self.propietario = input("Nombre del propietario:")
        self.MontoDisponible = float(input("Monto Disponible:"))
        
    @property
    def Servicios(self):
        return self.__Servicios
    
    @Servicios.setter
    def Servicios(self,NuevoServicio):
        self.__Servicios = NuevoServicio
        
# --------------------------------- Parte II ---------------------------------
'''
++++++++++++++++++++++++++++++++++
+ CLASS AGENCIA BANCARIA
++++++++++++++++++++++++++++++++++
'''   
        
class agenciabancaria:
    def __init__(self):
        self.__usuarios = list()
        
    def __menuServiciosP(self):
        print(" ==================================================== ")
        print(" [a] Ingresar servicio")
        print(" [b] Mostrar servicios")
        print(" [c] Eliminar servicio")
        print(" [d] Regresar")
        print(" ==================================================== ")
        return input("> ")
    
    def __AgregarServiciosP(self):
        lista = list()
        respuesta = ""
        while respuesta != "d":
            respuesta = self.__menuServiciosP()
            if respuesta == "a":
                print("Agregando servicio público")
                servicio_publico = ServicioPublico("")
                servicio_publico.CapturaInformacion()
                lista.append(servicio_publico)
                
            elif respuesta == "b":
                print("Mostrando todos los servicios públicos agregados")
                for i in range(len(lista)):
                    print(lista[i])
                input("Digite cualquier tecla para continuar") 
            
            elif respuesta == "c":
                print("Se ha borrado la lista de servicios públicos")
                lista.clear()
                input("Digite cualquier tecla para continuar") 
                
        return lista
    
    def __menuPrincipal(self):
        print(" ==================================================== ")
        print(" [1] Agregar UsuarioAhorro")
        print(" [2] Agregar UsuarioTasaCero")
        print(" [3] Agregar UsuarioPagosServicios")
        print(" [4] Mostrar lista de usuarios")
        print(" [5] Asignar Fondos")
        print(" [6] Asignar Operaciones")
        print(" [7] Procesar Inversiones")
        print(" [8] Salir")
        print(" ==================================================== ")
        return input("> ")
    
    def __mostrarLista(self):
        for i in range(len(self.__usuarios)):
            print(self.__usuarios[i])
            print("")
            
    def RUN(self):
        respuesta = ""
        while respuesta != "8":
            respuesta = self.__menuPrincipal()
            if respuesta == "1":
                print("Agregando UsuarioAhorro")
                usuario_ahorro = UsuarioAhorro("")
                usuario_ahorro.Captura()
                self.__usuarios.append(usuario_ahorro)
                
            elif respuesta == "2":
                print("Agregando  UsuarioTasaCero")
                usuario_tasa_cero = UsuarioTasaCero("")
                usuario_tasa_cero.Captura()
                self.__usuarios.append(usuario_tasa_cero)
            
            elif respuesta == "3":
                print("Agregando UsuarioPagosServicios")
                usuario_pago_servicios = UsuarioPagoServicios("")
                usuario_pago_servicios.Captura()
                serviciosp = self.__AgregarServiciosP()
                usuario_pago_servicios.Servicios = serviciosp
                self.__usuarios.append(usuario_pago_servicios)
                
            elif respuesta == "4":
                print("Ver todos los usuarios")
                self.__mostrarLista()
                input("Digite cualquier tecla para continuar")
                
            elif respuesta == "5":
                print("Ver todos los usuarios")
                for i in range(len(self.__usuarios)):
                    print(str(i) + ". " + self.__usuarios[i].propietario)
                usuario_seleccionado = int(input("Seleccione por su número el usuario que desea modificar su monto disponible:"))
                monto_disponible = float(input("Monto disponible:"))
                self.__usuarios[usuario_seleccionado].MontoDisponible = monto_disponible
                input("Digite cualquier tecla para continuar")
                
            elif respuesta == "6":
                print("Asignando operaciones....")
                for i in range(len(self.__usuarios)):
                    self.__usuarios[i].Asignar()
            
            elif respuesta == "7":
                print("Procesando inversiones....")
                for i in range(len(self.__usuarios)):
                    self.__usuarios[i].Aplicar()
                
            elif respuesta == "8":
                print("Borrando lista de todas con todos los usuarios")
                self.__usuarios.clear()

def RUN():
  TestingUsuarios = agenciabancaria()
  TestingUsuarios.RUN()

#RUN()

# --------------------------------- Parte III ---------------------------------
 
@contextmanager
def custom_redirection(fileobj_in,fileobj_out):
    old_in = sys.stdin
    old_out = sys.stdout
    sys.stdin = fileobj_in
    sys.stdout = fileobj_out
    try:
        yield fileobj_in
    finally:
        sys.stdin =  old_in
        sys.stdout = old_out
   
if __name__ == '__main__':
    with open('python_output.txt', 'w',encoding = 'utf8') as outputs:
      with open('Entrada.txt', 'r',encoding = 'utf8') as inputs :
        with custom_redirection(inputs, outputs):
            print('Programa con I/O redirigido inicia...\n++++++++++++++++++++++++++++++++++++++++\n')
            RUN()
            print('Programa con I/O redirigido termina \n++++++++++++++++++++++++++++++++++++++++\n')
print('Este mensaje sale por stdout')

print("Archivo de entrada de datos...")
with open('Entrada.txt', 'r',encoding = 'utf8') as myfile:
  data = myfile.read()
  print(data)
  
print("Archivo de salida de ejecución...")
with open('python_output.txt', 'r',encoding = 'utf8') as myfile:
  data = myfile.read()
  print(data)    
