#include <iostream>
#include <list>

using namespace std;

#include "sistema_Electrico.h"
#include "planta_Generadora.h"

Sistema_Electrico::Sistema_Electrico(void)
{
};

void Sistema_Electrico::insertar_datos(planta_generadora planta_i)
{
    plantas_generadoras.push_back(planta_i);
};

void Sistema_Electrico::mostrar_datos(void)
{
    list<planta_generadora>::iterator first = plantas_generadoras.begin();
    list<planta_generadora>::iterator last = plantas_generadoras.end();

    for (first = plantas_generadoras.begin(); first != last; ++first){
        printf("-----------------------------------------------------\n");
        first->despliegue_informacion();
        first->mostrar_componentes();
    };

};
