// ===============================
// Fabricio Solano Rojas B77447
// ===============================

#ifndef METODOH_H_INCLUDED
#define METODOH_H_INCLUDED

// Se define la clase padre con todas las variables comunes con las clases hijas
class _base{
public:
  _base(float, float);
  int iterador;
  float xi;
  float error_aceptado;
  float xi_xi;
  float ultimo_xi;
  float fxi;
  float _fxi;
  float xi_1;
};//______________________________________

// Clase hija que resuelve la ecuaci�n de un polinomio
class _polinomio : public _base {
public:
  _polinomio(float, float);
  float resolverEcuacionP(float);
  float resolverDerivadaP(float);
  void metodoNewton(void);
};//______________________________________

// Clase hija que resuelve la ecuaci�n de un exponencial
class _exponencial : public _base {
public:
  _exponencial(float, float);
  float resolverEcuacionE(float);
  float resolverDerivadaE(float);
  void metodoNewton(void);
};//______________________________________

// Clase hija que resuelve la ecuaci�n de un seno
class _seno : public _base {
public:
  _seno(float, float);
  float resolverEcuacionS(float);
  float resolverDerivadaS(float);
  void metodoNewton(void);
};//______________________________________
#endif // METODOH_H_INCLUDED
