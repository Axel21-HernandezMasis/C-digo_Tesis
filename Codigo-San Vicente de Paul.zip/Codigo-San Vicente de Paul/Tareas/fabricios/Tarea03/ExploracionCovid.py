'''
Tarea 03, parte 3

Fabricio Solano Rojas B77447
'''

import pandas as pd
import matplotlib.pyplot as plt

# ------------------------------ Punto a ------------------------------
print("------------------------------ Punto a ------------------------------")
def CargarArchivo():
    datosCovid = pd.read_csv('time_series_covid19_confirmed_ready.csv')

    return datosCovid
    
DF = CargarArchivo()
print(DF, "\n")

# ------------------------------ Punto b ------------------------------
print("------------------------------ Punto b ------------------------------")
def ChangeIndex(DF):
    DF_Index = DF.set_index('fechas')
    
    return DF_Index

datos_Covid = ChangeIndex(DF)
print("Conversión de la columna fecha en index:\n", datos_Covid, "\n")

# ------------------------------ Punto c ------------------------------
print("------------------------------ Punto c ------------------------------")
def DatosPaises(datos_Covid):
    return datos_Covid.loc['2020-09-01':'2020-09-25', ['Panama','Uruguay','Costa.Rica', 'Spain']]

print("Datos de los países Panama, Uruguay, Costa Rica y España, para las fechas del 01/09/2020 al 25/09/2020:")
print(DatosPaises(datos_Covid))

# ------------------------------ Punto d ------------------------------
# Gráfico que muestra los valores de Costa Rica en todo el periodo de la pandemia
def GraficoCostaRica(DF):
    DF.plot(x='fechas', y='Costa.Rica')
    ax = plt.gca()
    ax.set_xticks(ax.get_xticks()[::2]) # Cambiar cantidad de datos que se muestran en eje x
    plt.show()

GraficoCostaRica(DF)

# ------------------------------ Punto e ------------------------------
def GraficoPaises(DF):
    datos_Covid2 = DF.iloc[222:247] # Seleccionar periodo de fechas del 01/09/2020 al 25/09/2020

    fig, ax = plt.subplots() # Se crea un gráfico
    datos_Covid2.plot(x='fechas', y='Spain', ax=ax, marker='p', color='b', markerfacecolor='white', markeredgecolor='c', label='España')
    datos_Covid2.plot(x='fechas', y='Italy', ax=ax, marker='p', color='r', markerfacecolor='white', markeredgecolor='k', label='Italia')
    datos_Covid2.plot(x='fechas', y='France', ax=ax, marker='p', color='g', markerfacecolor='white', markeredgecolor='y', label='Francia')
    plt.legend()
    plt.show()
    
GraficoPaises(DF)