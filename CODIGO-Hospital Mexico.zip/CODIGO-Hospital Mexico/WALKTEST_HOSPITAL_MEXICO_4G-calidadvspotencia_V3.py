# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import pandas as pd
import glob
import numpy as np
import random
import matplotlib.pyplot as plt



    
    
#******************************************************************************************
pd.options.display.max_rows = 9999
#Edificio A
#ICE

column_names = pd.Series(['Time', 'Longitude', 'Latitude', 'Operador',"Network" , 'NetworkTech', 'Level', "Speed"])


Piso_Siete_ICE = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_ICE\EDIFICIO_A_PISO_7\ICE_2023.11.25_14.14.57\ICE_2023.11.25_14.14.57.txt", sep=';', decimal=',') 

Piso_Siete_ICE.fillna(0, inplace = True)

Piso_Seis_ICE = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_ICE\EDIFICIO_A_PISO_6\ICE_2023.11.25_14.17.49\ICE_2023.11.25_14.17.49.txt", sep=';', decimal=',') 
Piso_Seis_ICE.fillna(0, inplace = True)

Piso_Cinco_ICE = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_ICE\EDIFICIO_A_PISO_5\ICE_2023.11.25_14.21.18\ICE_2023.11.25_14.21.18.txt", sep=';', decimal=',') 
Piso_Cinco_ICE.fillna(0, inplace = True)

Piso_Cuatro_ICE = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_ICE\EDIFICIO_A_PISO_4\ICE_2023.11.25_14.24.29\ICE_2023.11.25_14.24.29.txt", sep=';', decimal=',') 
Piso_Cuatro_ICE.fillna(0, inplace = True)
#print(df.info())
Piso_Tres_ICE = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_ICE\EDIFICIO_A_PISO_3\ICE_2023.11.25_14.27.50\ICE_2023.11.25_14.27.50.txt", sep=';', decimal=',')
Piso_Tres_ICE.fillna(0, inplace = True)

Piso_Uno_ICE = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_ICE\EDIFICIO_A_PISO_1\ICE_2023.11.25_14.38.49\ICE_2023.11.25_14.38.49.txt", sep=';', decimal=',')  
Piso_Uno_ICE.fillna(0, inplace = True)

#Claro
Piso_Siete_CLARO = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_CLARO\EDIFICIO_A_PISO_7\Claro_2023.11.25_14.14.52\Claro_2023.11.25_14.14.52.txt", sep=';', decimal=',') 
Piso_Siete_CLARO.fillna(0, inplace = True)

Piso_Seis_CLARO = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_CLARO\EDIFICIO_A_PISO_6\Claro_2023.11.25_14.17.43\Claro_2023.11.25_14.17.43.txt", sep=';', decimal=',') 
Piso_Seis_CLARO.fillna(0, inplace = True)

Piso_Cinco_CLARO = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_CLARO\EDIFICIO_A_PISO_5\Claro_2023.11.25_14.21.12\Claro_2023.11.25_14.21.12.txt", sep=';', decimal=',') 
Piso_Cinco_CLARO.fillna(0, inplace = True)

Piso_Cuatro_CLARO = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_CLARO\EDIFICIO_A_PISO_4\Claro_2023.11.25_14.24.22\Claro_2023.11.25_14.24.22.txt", sep=';', decimal=',') 
Piso_Cuatro_CLARO.fillna(0, inplace = True)

Piso_Tres_CLARO = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_CLARO\EDIFICIO_A_PISO_3\Claro_2023.11.25_14.27.55\Claro_2023.11.25_14.27.55.txt", sep=';', decimal=',') 
Piso_Tres_CLARO.fillna(0, inplace = True)

Piso_Uno_CLARO = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_CLARO\EDIFICIO_A_PISO_1\Claro_2023.11.25_14.38.44\Claro_2023.11.25_14.38.44.txt", sep=';', decimal=',') 
Piso_Uno_CLARO.fillna(0, inplace = True)

#Liberty
Piso_Siete_Liberty = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_LIBERTY\EDIFICIO_A_PISO_7\LIBERTY_2023.11.25_13.00.40\LIBERTY_2023.11.25_13.00.40.txt", sep=';', decimal=',') 
Piso_Siete_Liberty.fillna(0, inplace = True)

Piso_Seis_Liberty = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_LIBERTY\EDIFICIO_A_PISO_6\LIBERTY_2023.11.25_13.04.24\LIBERTY_2023.11.25_13.04.24.txt", sep=';', decimal=',') 
Piso_Seis_Liberty.fillna(0, inplace = True)

Piso_Cinco_Liberty = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_LIBERTY\EDIFICIO_A_PISO_5\LIBERTY_2023.11.25_13.07.52\LIBERTY_2023.11.25_13.07.52.txt", sep=';', decimal=',') 
Piso_Cinco_Liberty.fillna(0, inplace = True)

Piso_Cuatro_Liberty = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_LIBERTY\EDIFICIO_A_PISO_4\LIBERTY_2023.11.25_13.11.49\LIBERTY_2023.11.25_13.11.49.txt", sep=';', decimal=',') 
Piso_Cuatro_Liberty.fillna(0, inplace = True)

Piso_Tres_Liberty = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_LIBERTY\EDIFICIO_A_PISO_3\LIBERTY_2023.11.25_13.15.28\LIBERTY_2023.11.25_13.15.28.txt", sep=';', decimal=',') 
Piso_Tres_Liberty.fillna(0, inplace = True)

Piso_Uno_Liberty = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_LIBERTY\EDIFICIO_A_PISO_1\LIBERTY_2023.11.25_13.28.49\LIBERTY_2023.11.25_13.28.49.txt", sep=';', decimal=',') 
Piso_Uno_Liberty.fillna(0, inplace = True)

#******************************************************************************************

#Edificio B

#CLARO

Piso_Claro_B_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_CLARO\EDIFICIO_B_PISO_3\Claro_2023.11.25_14.31.37\Claro_2023.11.25_14.31.37.txt", sep=';', decimal=',')
Piso_Claro_B_3.fillna(0, inplace = True)

Piso_Claro_B_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_CLARO\EDIFICIO_B_PISO_1\Claro_2023.11.25_14.42.53\Claro_2023.11.25_14.42.53.txt", sep=';', decimal=',')
Piso_Claro_B_1.fillna(0, inplace = True)

Piso_Claro_B_PB = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_CLARO\EDIFICIO_B_PB\Claro_2023.11.25_14.47.14\Claro_2023.11.25_14.47.14.txt", sep=';', decimal=',')
Piso_Claro_B_PB.fillna(0, inplace = True)

#ICE

Piso_Kolbi_B_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_ICE\EDIFICIO_B_PISO_3\ICE_2023.11.25_14.31.43\ICE_2023.11.25_14.31.43.txt", sep=';', decimal=',')
Piso_Kolbi_B_3.fillna(0, inplace = True)

Piso_Kolbi_B_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_ICE\EDIFICIO_B_PISO_1\ICE_2023.11.25_14.42.47\ICE_2023.11.25_14.42.47.txt", sep=';', decimal=',')
Piso_Kolbi_B_1.fillna(0, inplace = True)

Piso_Kolbi_B_PB = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_ICE\EDIFICIO_B_PB\ICE_2023.11.25_14.47.21\ICE_2023.11.25_14.47.21.txt", sep=';', decimal=',')
Piso_Kolbi_B_PB.fillna(0, inplace = True)
#LIBERTY

Piso_Liberty_B_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_LIBERTY\EDIFICIO_B_PISO_3\LIBERTY_2023.11.25_13.23.31\LIBERTY_2023.11.25_13.23.31.txt", sep=';', decimal=',')
Piso_Liberty_B_3.fillna(0, inplace = True)

Piso_Liberty_B_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_LIBERTY\EDIFICIO_B_PISO_1\LIBERTY_2023.11.25_13.34.38\LIBERTY_2023.11.25_13.34.38.txt", sep=';', decimal=',')
Piso_Liberty_B_1.fillna(0, inplace = True)

Piso_Liberty_B_PB = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_LIBERTY\EDIFICIO_B_PB\LIBERTY_2023.11.25_13.40.22\LIBERTY_2023.11.25_13.40.22.txt", sep=';', decimal=',')
Piso_Liberty_B_PB.fillna(0, inplace = True)

#******************************************************************************************
#Edificio C

Piso_Claro_C_FARMACIA = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_CLARO\EDIFICIO_C_FARMACIA\Claro_2023.11.25_14.51.50\Claro_2023.11.25_14.51.50.txt", sep=';', decimal=',')
Piso_Claro_C_FARMACIA.fillna(0, inplace = True)

Piso_Claro_C_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_CLARO\EDIFICIO_C_PISO_1\Claro_2023.11.25_14.53.54\Claro_2023.11.25_14.53.54.txt", sep=';', decimal=',')
Piso_Claro_C_1.fillna(0, inplace = True)

Piso_Kolbi_C_FARMACIA = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_ICE\EDIFICIO_C_FARMACIA\ICE_2023.11.25_14.51.42\ICE_2023.11.25_14.51.42.txt", sep=';', decimal=',')
Piso_Kolbi_C_FARMACIA.fillna(0, inplace = True)

Piso_Kolbi_C_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_ICE\EDIFICIO_C_PISO_1\ICE_2023.11.25_14.54.00\ICE_2023.11.25_14.54.00.txt", sep=';', decimal=',')
Piso_Kolbi_C_1.fillna(0, inplace = True)

Piso_Liberty_C_FARMACIA = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_LIBERTY\EDIFICIO_C_FARMACIA\LIBERTY_2023.11.25_13.42.50\LIBERTY_2023.11.25_13.42.50.txt", sep=';', decimal=',')
Piso_Liberty_C_FARMACIA.fillna(0, inplace = True)

Piso_Liberty_C_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_LIBERTY\EDIFICIO_C_PISO_1\LIBERTY_2023.11.25_13.45.21\LIBERTY_2023.11.25_13.45.21.txt", sep=';', decimal=',')
Piso_Liberty_C_1.fillna(0, inplace = True)


#******************************************************************************************
#Edificio R


#Piso R
Piso_Claro_R_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_CLARO\EDIFICIO_R_PISO_3\Claro_2023.11.25_15.05.03\Claro_2023.11.25_15.05.03.txt", sep=';', decimal=',')
Piso_Claro_R_3.fillna(0, inplace = True)

#Piso 1
Piso_Claro_R_2 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_CLARO\EDIFICIO_R_PISO_2\Claro_2023.11.25_15.06.20\Claro_2023.11.25_15.06.20.txt", sep=';', decimal=',')
Piso_Claro_R_2.fillna(0, inplace = True)
#Piso 2
Piso_Claro_R_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_CLARO\EDIFICIO_R_PISO_1\Claro_2023.11.25_15.08.39\Claro_2023.11.25_15.08.39.txt", sep=';', decimal=',')
Piso_Claro_R_1.fillna(0, inplace = True)

Piso_Kolbi_R_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_ICE\EDIFICIO_R_PISO_3\ICE_2023.11.25_15.05.09\ICE_2023.11.25_15.05.09.txt", sep=';', decimal=',')
Piso_Kolbi_R_3.fillna(0, inplace = True)
#Piso 1
Piso_Kolbi_R_2 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_ICE\EDIFICIO_R_PISO_2\ICE_2023.11.25_15.06.13\ICE_2023.11.25_15.06.13.txt", sep=';', decimal=',')
Piso_Kolbi_R_2.fillna(0, inplace = True)
#Piso 2
Piso_Kolbi_R_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_ICE\EDIFICIO_R_PISO_1\ICE_2023.11.25_15.08.46\ICE_2023.11.25_15.08.46.txt", sep=';', decimal=',')
Piso_Kolbi_R_1.fillna(0, inplace = True)
#Piso D0 E0

Piso_Liberty_R_3 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_LIBERTY\EDIFICIO_R_PISO_3\LIBERTY_2023.11.25_13.56.49\LIBERTY_2023.11.25_13.56.49.txt", sep=';', decimal=',')
Piso_Liberty_R_3.fillna(0, inplace = True)
#Piso 1
Piso_Liberty_R_2 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_LIBERTY\EDIFICIO_R_PISO_2\LIBERTY_2023.11.25_13.58.30\LIBERTY_2023.11.25_13.58.30.txt", sep=';', decimal=',')
Piso_Liberty_R_2.fillna(0, inplace = True)
#Piso 2
Piso_Liberty_R_1 = pd.read_csv(r"C:\Users\abrah\Documents\Axel_Interno\Axel_Interno\Tesis\Banco_de_Preubas\Hospital_Mexico\MEDICIONES_4G_LIBERTY\EDIFICIO_R_PISO_1\LIBERTY_2023.11.25_14.01.26\LIBERTY_2023.11.25_14.01.26.txt", sep=';', decimal=',')
Piso_Liberty_R_1.fillna(0, inplace = True)

#Piso D0 E0
#
 



 

#Funciones


def Limpiar(marks):
    b=[]
    m=len(marks.index)
    for j in range(m):
        Filaaux=marks.iloc[j,0]
        Filaaux=Filaaux.split()
        b.append(Filaaux)
    Datos=pd.DataFrame(b,columns=column_names)
    Datos.loc[Datos["Network"] == "4G", "Red_G"] = 4

    Datos.loc[Datos["Network"] == "3G", "Red_G"] = 3

    Datos.drop(Datos[(Datos['Red_G']==3)].index, inplace =True) #Elimina el 3G
    Datos.drop(['Time', 'Longitude', 'Latitude','Network','Level' ], axis=1, inplace=True)
    Datos["NetworkTech"]=Datos["NetworkTech"].astype(float)
    Datos["Speed"]=Datos["Speed"].astype(float)
    
   
    
    return Datos



def assign_Result_4G(marks):
    
    if marks <= -44 and marks >= -80 :
        result = "1-Excelente"
    elif marks <= -80 and marks >= -90 :
        result = "2-Buena" 
    elif marks <= -90 and marks >= -100 :
        result = "3-Justa"  
    elif  marks <= -100 and marks >= -110 :
        result = "4-Mala"
    elif marks <= -111 :
        result = "5-Muerta"  
    else:
        result = "6-Error"
    return result



def assign_Result_3G(marks):
    
    if marks <= -60.0 and marks >= -85.0 :
        result = "1-Excelente" 
    elif marks <= -86.0 and marks >= -100.0 :
        result = "2-Buena"  
    elif  marks <= -101.0 and marks >= -109.0 :
        result = "3-Justa" 
        
   
    elif marks <= -110.0 :
        result = "4-Mala" 
        
  
    else:
        result = "5-Muerta"
    return result

def assign_Umbral_4G(marks):
    
    if marks <= -44 and marks >= -95 :
        result = "1-Dentro_Umbral"
    elif marks <= -96:
        result = "2-Fuera_Umbral" 
     
    else:
        result = "6-Error"
    return result

def assign_3G_or_4G(marks):
    for i in range(len(marks)):
        if marks.iloc[i]['Red_G']==4.0:
            marks["Calidad_4G"] = marks["NetworkTech"].apply(assign_Result_4G)
            marks["Umbral"] = marks["NetworkTech"].apply(assign_Umbral_4G)
 
           
            
        elif marks.iloc[i]['Red_G']==3.0:
            marks["Calidad_3G"] = marks["NetworkTech"].apply(assign_Result_3G)
            
    marks=marks.sort_values("Calidad_4G")
    marks.head()        
    return marks

def Mala_cobertura(marks):

    x=0 
    y=0
    z=0 
    a=0 
    b=0 
    
    for i in range(len(marks["Calidad_4G"])):
        if marks.iloc[i]["Calidad_4G"]=="1-Excelente":
            a=a+1
        if marks.iloc[i]["Calidad_4G"]=="2-Buena":
            b=b+1
        if marks.iloc[i]["Calidad_4G"]=="3-Justa":
            x=x+1
        if marks.iloc[i]["Calidad_4G"]=="4-Mala":
            y=y+1
        if marks.iloc[i]["Calidad_4G"]=="5-Muerta":
            z=z+1
        
        

   # print("Se encontraron :""",a,"""datos de calidad
     #         Excelente respecto a la muestra de datos 
    #          de:""",len(marks["Calidad_4G"]))
 #   print("Se encontraron :""",b,""" datos de calidad 
    #          Buena respecto a la muestra de datos 
     #         de:""",len(marks["Calidad_4G"]))
  #  print("Se encontraron :""",x,""" datos de calidad 
    #          Justa respecto a la muestra de datos 
     #         de:""",len(marks["Calidad_4G"]))
  #  print("Se encontraron :""",y,""" datos de calidad 
     #         Mala respecto a la muestra de datos 
      #        de:""",len(marks["Calidad_4G"]))
  #  print("Se encontraron :""",z,"""datos de calidad 
     #         Muerta respecto a la muestra de datos 
      #        de:""",len(marks["Calidad_4G"]))
             
    return a,b,x,y,z


        
def Datos_Finales(marks):
 #   display(marks)
    Varianza=marks["NetworkTech"].var(ddof=0)
    Desviacion_Estandar=marks["NetworkTech"].std()
    Promedio_Cobertura=marks["NetworkTech"].mean()
#    Promedio_Velocidad=marks["Speed"].mean()
    print("La varianza de la cobertura es:",Varianza)#La variación de parametro
    print("La Desviacion estandar es:",Desviacion_Estandar)#Cuanto se desvian los parametros entre sí
    print("El promedio de cobertura es",Promedio_Cobertura)#Promedio de la señal
#    print("El promedio de ancho de banda",Promedio_Velocidad,"kbps")#Promedio de la señal
    
    
    # marks["NetworkTech"].plot()
    
    

def plt_auxiliar(): 
    plt.plot(["1-Excelente", "1-Excelente"],
         [-70, -125],
         color='black', linestyle='')
    plt.plot(["2-Buena", "2-Buena"],
         [-70, -125],
         color='black', linestyle='')
    plt.plot(["3-Justa", "3-Justa"],
         [-70, -125],
         color='black', linestyle='')
    plt.plot(["4-Mala", "4-Mala"],
         [-70, -125],
         color='black', linestyle='')
    plt.plot(["5-Muerta", "5-Muerta"],
         [-70, -125],
         color='black', linestyle='')

def plt_auxiliar_2():     
    plt.plot(["1-Excelente", "5-Muerta"],
         [-80, -80],
         color='black', linestyle='--')
    plt.plot(["1-Excelente", "5-Muerta"],
         [-90, -90],
         color='black', linestyle='--')
    plt.plot(["1-Excelente", "5-Muerta"],
         [-100, -100],
         color='black', linestyle='--')    
    plt.plot(["1-Excelente", "5-Muerta"],
         [-110, -110],
         color='black', linestyle='--')

def plt_auxiliar_3():
    plt.plot(["1-Excelente", "1-Excelente"],
         [0, 100],color='black', linestyle='')
    
def plt_auxiliar_4():
    plt.plot(["1-Excelente", "1-Excelente"],
         [0, 120],color='black', linestyle='')
    
    
#********************************************************************************#
def Mala_cobertura_Sutel(marks):

    p=0 
    h=0

    
    for i in range(len(marks["Calidad_4G"])):
        if marks.iloc[i]["Umbral"]=="1-Dentro_Umbral":
            p=p+1
        if marks.iloc[i]["Umbral"]=="2-Fuera_Umbral":
            h=h+1

    return p,h
        
        

#********************************************************************************

#Pisol
Piso_Uno_CLARO=Limpiar(Piso_Uno_CLARO)
Piso_Uno_CLARO=assign_3G_or_4G(Piso_Uno_CLARO)

#Piso3
Piso_Tres_CLARO=Limpiar(Piso_Tres_CLARO)
Piso_Tres_CLARO=assign_3G_or_4G(Piso_Tres_CLARO)




#Piso4
Piso_Cuatro_CLARO=Limpiar(Piso_Cuatro_CLARO)
Piso_Cuatro_CLARO=assign_3G_or_4G(Piso_Cuatro_CLARO)


#Piso5
Piso_Cinco_CLARO=Limpiar(Piso_Cinco_CLARO)
Piso_Cinco_CLARO=assign_3G_or_4G(Piso_Cinco_CLARO)

#Piso5
Piso_Seis_CLARO=Limpiar(Piso_Seis_CLARO)
Piso_Seis_CLARO=assign_3G_or_4G(Piso_Seis_CLARO)

#Piso5
Piso_Siete_CLARO=Limpiar(Piso_Siete_CLARO)
Piso_Siete_CLARO=assign_3G_or_4G(Piso_Siete_CLARO)


Piso_Uno_ICE=Limpiar(Piso_Uno_ICE)
Piso_Uno_ICE=assign_3G_or_4G(Piso_Uno_ICE)

Piso_Tres_ICE=Limpiar(Piso_Tres_ICE)
Piso_Tres_ICE=assign_3G_or_4G(Piso_Tres_ICE)

Piso_Cuatro_ICE=Limpiar(Piso_Cuatro_ICE)
Piso_Cuatro_ICE=assign_3G_or_4G(Piso_Cuatro_ICE)

Piso_Cinco_ICE=Limpiar(Piso_Cinco_ICE)
Piso_Cinco_ICE=assign_3G_or_4G(Piso_Cinco_ICE)

Piso_Seis_ICE=Limpiar(Piso_Seis_ICE)
Piso_Seis_ICE=assign_3G_or_4G(Piso_Seis_ICE)

Piso_Siete_ICE=Limpiar(Piso_Siete_ICE)
Piso_Siete_ICE=assign_3G_or_4G(Piso_Siete_ICE)

Piso_Uno_Liberty=Limpiar(Piso_Uno_Liberty)
Piso_Uno_Liberty=assign_3G_or_4G(Piso_Uno_Liberty)
Piso_Tres_Liberty=Limpiar(Piso_Tres_Liberty)
Piso_Tres_Liberty=assign_3G_or_4G(Piso_Tres_Liberty)
Piso_Cuatro_Liberty=Limpiar(Piso_Cuatro_Liberty)
Piso_Cuatro_Liberty=assign_3G_or_4G(Piso_Cuatro_Liberty)
Piso_Cinco_Liberty=Limpiar(Piso_Cinco_Liberty)
Piso_Cinco_Liberty=assign_3G_or_4G(Piso_Cinco_Liberty)
Piso_Seis_Liberty=Limpiar(Piso_Seis_Liberty)
Piso_Seis_Liberty=assign_3G_or_4G(Piso_Seis_Liberty)
Piso_Siete_Liberty=Limpiar(Piso_Siete_Liberty)
Piso_Siete_Liberty=assign_3G_or_4G(Piso_Siete_Liberty)

Piso_Claro_B_3=Limpiar(Piso_Claro_B_3)
Piso_Claro_B_3=assign_3G_or_4G(Piso_Claro_B_3)

Piso_Claro_B_1=Limpiar(Piso_Claro_B_1)
Piso_Claro_B_1=assign_3G_or_4G(Piso_Claro_B_1)

Piso_Claro_B_PB=Limpiar(Piso_Claro_B_PB)
Piso_Claro_B_PB=assign_3G_or_4G(Piso_Claro_B_PB)

Piso_Kolbi_B_3=Limpiar(Piso_Kolbi_B_3)
Piso_Kolbi_B_3=assign_3G_or_4G(Piso_Kolbi_B_3)
Piso_Kolbi_B_1=Limpiar(Piso_Kolbi_B_1)
Piso_Kolbi_B_1=assign_3G_or_4G(Piso_Kolbi_B_1)
Piso_Kolbi_B_PB=Limpiar(Piso_Kolbi_B_PB)
Piso_Kolbi_B_PB=assign_3G_or_4G(Piso_Kolbi_B_PB)
Piso_Liberty_B_3=Limpiar(Piso_Liberty_B_3)
Piso_Liberty_B_3=assign_3G_or_4G(Piso_Liberty_B_3)
Piso_Liberty_B_1=Limpiar(Piso_Liberty_B_1)
Piso_Liberty_B_1=assign_3G_or_4G(Piso_Liberty_B_1)
Piso_Liberty_B_PB=Limpiar(Piso_Liberty_B_PB)
Piso_Liberty_B_PB=assign_3G_or_4G(Piso_Liberty_B_PB)
Piso_Claro_R_1=Limpiar(Piso_Claro_R_1)
Piso_Claro_R_1=assign_3G_or_4G(Piso_Claro_R_1)
Piso_Claro_R_2=Limpiar(Piso_Claro_R_2)
Piso_Claro_R_2=assign_3G_or_4G(Piso_Claro_R_2)
Piso_Claro_R_3=Limpiar(Piso_Claro_R_3)
Piso_Claro_R_3=assign_3G_or_4G(Piso_Claro_R_3)
Piso_Kolbi_R_1=Limpiar(Piso_Kolbi_R_1)
Piso_Kolbi_R_1=assign_3G_or_4G(Piso_Kolbi_R_1)
Piso_Kolbi_R_2=Limpiar(Piso_Kolbi_R_2)
Piso_Kolbi_R_2=assign_3G_or_4G(Piso_Kolbi_R_2)
Piso_Kolbi_R_3=Limpiar(Piso_Kolbi_R_3)
Piso_Kolbi_R_3=assign_3G_or_4G(Piso_Kolbi_R_3)
Piso_Liberty_R_1=Limpiar(Piso_Liberty_R_1)
Piso_Liberty_R_1=assign_3G_or_4G(Piso_Liberty_R_1)
Piso_Liberty_R_2=Limpiar(Piso_Liberty_R_2)
Piso_Liberty_R_2=assign_3G_or_4G(Piso_Liberty_R_2)
Piso_Liberty_R_3=Limpiar(Piso_Liberty_R_3)
Piso_Liberty_R_3=assign_3G_or_4G(Piso_Liberty_R_3)
Piso_Claro_C_FARMACIA=Limpiar(Piso_Claro_C_FARMACIA)
Piso_Claro_C_FARMACIA=assign_3G_or_4G(Piso_Claro_C_FARMACIA)
Piso_Claro_C_1=Limpiar(Piso_Claro_C_1)
Piso_Claro_C_1=assign_3G_or_4G(Piso_Claro_C_1)
Piso_Kolbi_C_FARMACIA=Limpiar(Piso_Kolbi_C_FARMACIA)
Piso_Kolbi_C_FARMACIA=assign_3G_or_4G(Piso_Kolbi_C_FARMACIA)
Piso_Kolbi_C_1=Limpiar(Piso_Kolbi_C_1)
Piso_Kolbi_C_1=assign_3G_or_4G(Piso_Kolbi_C_1)
Piso_Liberty_C_FARMACIA=Limpiar(Piso_Liberty_C_FARMACIA)
Piso_Liberty_C_FARMACIA=assign_3G_or_4G(Piso_Liberty_C_FARMACIA) 
Piso_Liberty_C_1=Limpiar(Piso_Liberty_C_1)
Piso_Liberty_C_1=assign_3G_or_4G(Piso_Liberty_C_1)


print("**-----------*Sección de plts*------------**")
 #Seccion Plt
#Piso 1 edificio A
# Crear el gráfico de dispersión

def funcion(marks, marks2, marks3):
    plt_auxiliar()
    plt_auxiliar_2()
    
    plt.scatter(marks2["Calidad_4G"], marks2["NetworkTech"], color='b', label="Liberty")
    plt.scatter(marks["Calidad_4G"],marks["NetworkTech"], color = 'g',label = "ICE")
    plt.scatter(marks3["Calidad_4G"],marks3["NetworkTech"], color = 'r',label = "Claro")
    plt.legend(loc='upper right')
    plt.title("Edificio")
    plt.show()
    
    plt_auxiliar_3()
    a_1,b_1,x_1,y_1,z_1=Mala_cobertura(marks)
    a_2,b_2,x_2,y_2,z_2=Mala_cobertura(marks2)
    a_3,b_3,x_3,y_3,z_3=Mala_cobertura(marks3)

    total_1 = a_1 + b_1 + x_1 + y_1 + z_1
    total_2 = a_2 + b_2 + x_2 + y_2 + z_2
    total_3 = a_3 + b_3 + x_3 + y_3 + z_3

    calidad_x=np.array(["1-Excelente","2-Buena","3-Justa","4-Mala","5-Muerta"])
    calidad_y=np.array([a_1,b_1,x_1,y_1,z_1])/ total_1 * 100
    calidad_y_2=np.array([a_2,b_2,x_2,y_2,z_2])/ total_2 * 100
    calidad_y_3=np.array([a_3,b_3,x_3,y_3,z_3])/ total_3 * 100
    
    # Ancho de las barras
    bar_width = 0.2

    positions_1 = np.arange(len(calidad_x))
    positions_2 = positions_1 + bar_width + 0.05
    positions_3 = positions_2 + bar_width + 0.05

    # Crear la gráfica
    plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
    plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
    plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')
    
    # Etiquetas y título
    plt.xlabel('Calidad')
    plt.ylabel('Porcentaje')
    plt.title('Comparación de Calidad (Porcentaje Total)')
    plt.xticks(positions_2, calidad_x)

    # Añadir el valor del porcentaje dentro de la barra

    for i, value in enumerate(calidad_y):
        if value>0:
            plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

    for i, value in enumerate(calidad_y_2):
        if value>0:
            plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

    for i, value in enumerate(calidad_y_3):
        if value>0:
            plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

    # Mostrar la gráfica
    plt.show()
    
    plt_auxiliar_4()

    h_1,p_1=Mala_cobertura_Sutel(marks)
    h_2,p_2=Mala_cobertura_Sutel(marks2)
    h_3,p_3=Mala_cobertura_Sutel(marks3)

    total_1 = h_1 + p_1
    total_2 = h_2 + p_2
    total_3 = h_3 + p_3


    calidad_x=np.array(["1-Dentro_Umbral","2-Fuera_Umbral"])
    calidad_y=np.array([h_1,p_1])/ total_1 * 100
    calidad_y_2=np.array([h_2,p_2])/ total_2 * 100
    calidad_y_3=np.array([h_3,p_3])/ total_3 * 100

    # Ancho de las barras
    bar_width = 0.2

    positions_1 = np.arange(len(calidad_x))
    positions_2 = positions_1 + bar_width
    positions_3 = positions_2 + bar_width


    # Crear la gráfica
    plt.bar(positions_1, calidad_y, color="g", width=bar_width, label='ICE')
    plt.bar(positions_2, calidad_y_2, color="b", width=bar_width, alpha=0.7, label='Liberty')
    plt.bar(positions_3, calidad_y_3, color="r", width=bar_width, alpha=0.7, label='Claro')

    # Etiquetas y título
    plt.xlabel('Umbral de cobertura')
    plt.ylabel('Valores')
    plt.title('Comparación de Calidad porcentaje Sutel')
    plt.xticks(positions_2, calidad_x)

    plt.legend()
    # Añadir el valor del porcentaje dentro de la barra

    for i, value in enumerate(calidad_y):
        if value>0:
            plt.text(positions_1[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

    for i, value in enumerate(calidad_y_2):
        if value>0:
            plt.text(positions_2[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

    for i, value in enumerate(calidad_y_3):
        if value>0:
            plt.text(positions_3[i], value + 1.5, f'{value:.2f}%', ha='center', va='bottom')

    # Mostrar la gráfica
    plt.show()
     

    print("Para ICE:")
    Datos_Finales(marks)

    print("Para Liberty:")
    Datos_Finales(marks2)

    print("Para Claro:")
    Datos_Finales(marks3)

    #**********************************************
    
#Main
#vOY A EXPORTAR LOS DATOS A EXCEL
#Edificio A
print("EDIFICIO A-PISO 1")
A_1=funcion(Piso_Uno_ICE, Piso_Uno_Liberty, Piso_Uno_CLARO)

print("EDIFICIO A-PISO 3")
A_3=funcion(Piso_Tres_ICE, Piso_Tres_Liberty, Piso_Tres_CLARO)

print("EDIFICIO A-PISO 4")
A_4=funcion(Piso_Cuatro_ICE, Piso_Cuatro_Liberty, Piso_Cuatro_CLARO) 

print("EDIFICIO A-PISO 5")
A_5=funcion(Piso_Cinco_ICE, Piso_Cinco_Liberty, Piso_Cinco_CLARO) 

print("EDIFICIO A-PISO 6")
A_6=funcion(Piso_Seis_ICE, Piso_Seis_Liberty, Piso_Seis_CLARO) 

print("EDIFICIO A-PISO 7")
A_7=funcion(Piso_Siete_ICE, Piso_Siete_Liberty, Piso_Siete_CLARO) 

#Edificio B
print("EDIFICIO B-PISO PB")
B_0=funcion(Piso_Kolbi_B_PB, Piso_Liberty_B_PB, Piso_Claro_B_PB)
print("EDIFICIO B-PISO 1")
B_1=funcion(Piso_Kolbi_B_1, Piso_Liberty_B_1, Piso_Claro_B_1)
print("EDIFICIO B-PISO 3")
B_3=funcion(Piso_Kolbi_B_3, Piso_Liberty_B_3, Piso_Claro_B_3)


#Edificio C
print("EDIFICIO C-PISO FARMACIA")
C_0=funcion(Piso_Kolbi_C_FARMACIA, Piso_Liberty_C_FARMACIA, Piso_Claro_C_FARMACIA)
print("EDIFICIO C-PISO 1")
C_1=funcion(Piso_Kolbi_C_1, Piso_Liberty_C_1, Piso_Claro_C_1)

#Edificio R
print("EDIFICIO R-PISO 1")
R_1=funcion(Piso_Kolbi_R_1, Piso_Liberty_R_1, Piso_Claro_R_1)

print("EDIFICIO R-PISO 2")
R_2=funcion(Piso_Kolbi_R_2, Piso_Liberty_R_2, Piso_Claro_R_2)

print("EDIFICIO R-PISO 3")
R_3=funcion(Piso_Kolbi_R_3, Piso_Liberty_R_3, Piso_Claro_R_3)

 
