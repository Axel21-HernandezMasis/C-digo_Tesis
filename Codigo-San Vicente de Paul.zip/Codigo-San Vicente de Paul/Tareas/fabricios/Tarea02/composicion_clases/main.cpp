#include <iostream>
#include <stdlib.h>
#include <iostream>

using namespace std;

#include "unidad_Generadora.h"
#include "planta_Generadora.h"
#include "sistema_Electrico.h"

Sistema_Electrico APP_load()
{
    // --------------------------------------------------------------------------------------
    planta_generadora planta_1 = planta_generadora("Planta1", "Alajuela");

    unidad_generadora unidad_11 = unidad_generadora("Unidad1", "Grecia", "10MW", "Hidroelectrica");
    unidad_generadora unidad_12 = unidad_generadora("Unidad2", "Bajo Rodriguez", "20MW", "Hidroelectrica");
    unidad_generadora unidad_13 = unidad_generadora("Unidad3", "Zarcero", "30MW", "Hidroelectrica");

    planta_1.insertar_componentes(unidad_11);
    planta_1.insertar_componentes(unidad_12);
    planta_1.insertar_componentes(unidad_13);

    // --------------------------------------------------------------------------------------
    planta_generadora planta_2 = planta_generadora("Planta2", "San Jose");

    unidad_generadora unidad_21 = unidad_generadora("Unidad1", "Desamparados", "10MW", "Solar");
    unidad_generadora unidad_22 = unidad_generadora("Unidad2", "Santa Ana", "20MW", "Eolica");
    unidad_generadora unidad_23 = unidad_generadora("Unidad3", "San Pedro", "30MW", "Solar");

    planta_2.insertar_componentes(unidad_21);
    planta_2.insertar_componentes(unidad_22);
    planta_2.insertar_componentes(unidad_23);

    // --------------------------------------------------------------------------------------
    planta_generadora planta_3 = planta_generadora("Planta3", "Cartago");

    unidad_generadora unidad_31 = unidad_generadora("Unidad1", "Cachi", "10MW", "Hidroelectrica");
    unidad_generadora unidad_32 = unidad_generadora("Unidad2", "Paraiso", "30MW", "Eolica");

    planta_3.insertar_componentes(unidad_31);
    planta_3.insertar_componentes(unidad_32);

    // --------------------------------------------------------------------------------------
    planta_generadora planta_4 = planta_generadora("Planta4", "Heredia");

    unidad_generadora unidad_41 = unidad_generadora("Unidad1", "Santo Domingo", "10MW", "Hidroelectrica");
    unidad_generadora unidad_42 = unidad_generadora("Unidad2", "Belen", "20MW", "Eolica");
    unidad_generadora unidad_43 = unidad_generadora("Unidad3", "Barva", "30MW", "Hidroelectrica");

    planta_4.insertar_componentes(unidad_41);
    planta_4.insertar_componentes(unidad_42);
    planta_4.insertar_componentes(unidad_43);

    // --------------------------------------------------------------------------------------
    planta_generadora planta_5 = planta_generadora("Planta5", "Guanacaste");

    unidad_generadora unidad_51 = unidad_generadora("Unidad1", "Miravalles", "10MW", "Geotermica");
    unidad_generadora unidad_52 = unidad_generadora("Unidad2", "Nicoya", "20MW", "Termica");
    unidad_generadora unidad_53 = unidad_generadora("Unidad3", "Santa Cruz", "30MW", "Termica");

    planta_5.insertar_componentes(unidad_51);
    planta_5.insertar_componentes(unidad_52);
    planta_5.insertar_componentes(unidad_53);

    // --------------------------------------------------------------------------------------
    planta_generadora planta_6 = planta_generadora("Planta6", "Limon");

    unidad_generadora unidad_61 = unidad_generadora("Unidad1", "Matina", "20MW", "Hidroelectrica");
    unidad_generadora unidad_62 = unidad_generadora("Unidad2", "Talamanca", "20MW", "Hidroelectrica");

    planta_6.insertar_componentes(unidad_61);
    planta_6.insertar_componentes(unidad_62);

    // --------------------------------------------------------------------------------------
    planta_generadora planta_7 = planta_generadora("Planta7", "Puntarenas");

    unidad_generadora unidad_71 = unidad_generadora("Unidad1", "Buenos Aires", "30MW", "Hidroelectrica");

    planta_7.insertar_componentes(unidad_71);

    // --------------------------------------------------------------------------------------
    Sistema_Electrico SistemaElectrico;
    SistemaElectrico.insertar_datos(planta_1);
    SistemaElectrico.insertar_datos(planta_2);
    SistemaElectrico.insertar_datos(planta_3);
    SistemaElectrico.insertar_datos(planta_4);
    SistemaElectrico.insertar_datos(planta_5);
    SistemaElectrico.insertar_datos(planta_6);
    SistemaElectrico.insertar_datos(planta_7);


    return SistemaElectrico;
};

void ShowAll(Sistema_Electrico SistemaElectrico)
{
    SistemaElectrico.mostrar_datos();
};


int main()
{
    ShowAll(APP_load());
    return 0;
}
